import { i as __toESM } from "../_runtime.mjs";
import { i as guides, r as guideForWorld } from "./guides-MJkbfjV0.mjs";
import { Y as require_react, b as useRouter, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pause, c as BookOpen, i as Play, n as SkipForward, o as ChevronDown, r as SkipBack, s as Bookmark } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chronicle-Cxl7MlBr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var worlds_default = /*#__PURE__*/ JSON.parse("[{\"name\":\"Готика\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"Рудник\",\"cover\":\"/chronicle/music/gothic.jpg\",\"sleeve\":\"/chronicle/music/sleeves/gothic.jpg\",\"lists\":[{\"name\":\"YouTube · Готика\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGmUbQz1driM1KzNM_5tuG5d\"}],\"text\":\"Колония под куполом. Вода, отмычки, руда и каждый раз заново — едва очнулась.\",\"tracks\":[{\"title\":\"Едва двадцать лет\",\"length\":\"4:14\",\"note\":\"Едва очнулась у костра, едва шагнула за ворота — и снова колония.\",\"src\":\"/chronicle/music/edva.mp3\"},{\"title\":\"Заручиться водой\",\"length\":\"3:33\",\"note\":\"Чтобы стать своей в старом лагере, она носила воду, мела дворы и чинила стены.\",\"src\":\"/chronicle/music/vodoy.mp3\"},{\"title\":\"Отмычка и руда\",\"length\":\"3:54\",\"note\":\"Шесть часов с отмычкой. Замок всё ещё закрыт, в награду кусок руды.\",\"src\":\"/chronicle/music/otmychka.mp3\"},{\"title\":\"Колония купола\",\"length\":\"5:33\",\"note\":\"Под куполом нет добра. Она бьёт от утра до утра и не пропала.\",\"src\":\"/chronicle/music/kolonia.mp3\"}],\"game\":\"Gothic. Колония преступников под магическим куполом: три лагеря, руда, отмычки и барьер, из которого не выйти, пока не заслужишь. Мир грубый, без карты квестов на полэкрана. Каждый разговор может закончиться зубами на камнях.\",\"lived\":\"Люси очнулась у костра почти голая и без оружия. Сначала носила воду и мела чужие дворы, потом шесть часов ковыряла замок отмычкой и получила кусок руды. Под куполом она не ищет добро. Бьёт от утра до утра и не пропадает.\"},{\"name\":\"Кальрадия\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"Степь не отпускает\",\"cover\":\"/chronicle/music/calradia.jpg\",\"sleeve\":\"/chronicle/music/sleeves/calradia.jpg\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGlhdYxB5yvh7G0xlMsFvY6f\",\"lists\":[{\"name\":\"YouTube · Кальрадия\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGlhdYxB5yvh7G0xlMsFvY6f\"}],\"text\":\"Mount & Blade II: Bannerlord. Дороги, осады и чужие знамёна. Здесь она жила достаточно долго, чтобы петь это у костра.\",\"tracks\":[{\"title\":\"Алые ручейки\",\"length\":\"4:37\",\"note\":\"После боя дождь смывает кровь с полей. Пока ручьи бегут, она ещё слышит тишину.\",\"src\":\"/chronicle/music/alye.mp3\"},{\"title\":\"Ветер шальной\",\"length\":\"5:02\",\"note\":\"Серый конь, степная дорога и просьба дать хоть миг тишины.\",\"src\":\"/chronicle/music/veter.mp3\"},{\"title\":\"Град по щиту\",\"length\":\"3:05\",\"note\":\"Щит шире стены. Она пережидает чужие стрелы и отвечает, когда град кончается.\",\"src\":\"/chronicle/music/grad.mp3\"},{\"title\":\"Кальрадия. Костёр\",\"length\":\"2:02\",\"note\":\"Скрутили, увели лошадь и меч. У костра она считает звёзды и обещает шорох.\",\"src\":\"/chronicle/music/koster.mp3\"},{\"title\":\"Кальрадия молчит\",\"length\":\"5:07\",\"note\":\"Она устала считать павших. Дождь по лицу, конь стоит, спасать некому.\",\"src\":\"/chronicle/music/molchit.mp3\"},{\"title\":\"Кальрадия шепчет\",\"length\":\"5:34\",\"note\":\"Переговоры кончаются клинком. Она хотела день у окна, а степь шепчет: убей или согнись.\",\"src\":\"/chronicle/music/shepchet.mp3\"},{\"title\":\"Красный песок\",\"length\":\"3:00\",\"note\":\"Арена, ставки и песок, который она красит победой.\",\"src\":\"/chronicle/music/pesok.mp3\"},{\"title\":\"Перерыв\",\"length\":\"3:40\",\"note\":\"Шлем снят, конь привязан. Чай и бутерброд, пока округа подождёт.\",\"src\":\"/chronicle/music/pereryv.mp3\"},{\"title\":\"Седло в натяжку\",\"length\":\"2:35\",\"note\":\"Замок берут не тараном, а конями по кругу. Гарнизон уходит пешком.\",\"src\":\"/chronicle/music/sedlo.mp3\"},{\"title\":\"Смоем всё\",\"length\":\"4:13\",\"note\":\"Ливень, атака и срок, который уже вышел. Дождь даёт бой и смывает поле.\",\"src\":\"/chronicle/music/liven.mp3\"},{\"title\":\"Нас горсть, но мы буря\",\"length\":\"4:19\",\"note\":\"Малый отряд бьёт и уходит. После победы — компот и новая осада.\",\"src\":\"/chronicle/music/burya.mp3\"},{\"title\":\"Осада\",\"length\":\"4:15\",\"note\":\"Любовь, война и новый ребёнок у стен. Лук, муж в седле и замок, который ещё надо взять.\",\"src\":\"/chronicle/music/osada.mp3\"}],\"game\":\"Mount & Blade II: Bannerlord. Кальрадия без короля: степь, замки, наёмники и знамёна, которые меняются быстрее погоды. Победа здесь считается трупами и тем, остался ли конь.\",\"lived\":\"Она жила здесь достаточно долго, чтобы петь у костра. Щит шире стены, ливень смывает поле, малый отряд берёт замок кругом, а не тараном. Её скручивали, уводили лошадь и меч. После компота снова осада.\"},{\"name\":\"Pathfinder\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"Питакс\",\"cover\":\"/chronicle/music/pathfinder.jpg\",\"sleeve\":\"/chronicle/music/sleeves/pathfinder.jpg\",\"lists\":[{\"name\":\"YouTube · Pathfinder\",\"youtube\":\"https://www.youtube.com/playlist?list=PLOku197whkiw\"}],\"text\":\"Kingmaker. Война с Королём-Варваром: Питакс, интриги и вождь, рождённый дважды.\",\"tracks\":[{\"title\":\"Моё королевство\",\"length\":\"3:40\",\"note\":\"Короны не просила. Барон дал карту, а летопись она пишет огнём.\",\"src\":\"/chronicle/music/korolevstvo.mp3\"},{\"title\":\"Просто поешь говядины\",\"length\":\"3:05\",\"note\":\"Когда тоскливо, не ищи чуда. Достань из сумки кусок пожирнее.\",\"src\":\"/chronicle/music/govyadina.mp3\"},{\"title\":\"Клеймёный тролль\",\"length\":\"4:02\",\"note\":\"У брода двадцатка за двадцаткой. Пять процентов удачи, но он король.\",\"src\":\"/chronicle/music/troll.mp3\"}],\"game\":\"Pathfinder: Kingmaker. Украденные земли, баронство, которое надо удержать, и война с Королём-Варваром. Питакс, интриги и вождь, рождённый дважды.\",\"lived\":\"Люси не герой пророчества. Она держит людей, пока двор грызётся, и идёт на Питакс, потому что границу иначе не закрыть. Сарказм вместо речей с трона. Корона, если и есть, сидит криво.\"},{\"name\":\"Path of Exile\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"Один день\",\"cover\":\"/chronicle/music/exile.jpg\",\"lists\":[{\"name\":\"YouTube · Path of Exile\",\"youtube\":\"https://www.youtube.com/playlist?list=PLZgiDszCsfE0\"}],\"text\":\"Один день в шкуре дворянки. Собор, посох и то же лицо.\",\"tracks\":[],\"game\":\"Path of Exile. Рэглфолл, изгнание и один день, который не кончается: собор, порча и посох, от которого немеют пальцы. Мир не объясняет правила. Он их показывает трупом.\",\"lived\":\"Она проснулась дворянкой и к вечеру уже не помнила, зачем ей это имя. Собор, посох, то же лицо. Выжить здесь значит не останавливаться: свет кончается, тропа нет.\"},{\"name\":\"Tomb Raider\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"Геотермальная долина\",\"cover\":\"/chronicle/music/tomb.jpg\",\"sleeve\":\"/chronicle/music/sleeves/tomb.jpg\",\"lists\":[{\"name\":\"YouTube · Tomb Raider\",\"youtube\":\"https://www.youtube.com/playlist?list=PLQ8b-rX6kysE\"},{\"name\":\"Rutube · Tomb Raider\",\"rutube\":\"https://rutube.ru/plst/1731250/\"}],\"text\":\"Rise of the Tomb Raider. Лук, туман над долиной, Баба Яга и один путь наверх.\",\"tracks\":[{\"title\":\"Баба Яга\",\"length\":\"4:59\",\"note\":\"Избушка на курьих ножках не дурит. Она пришла спросить и пролить свет на тьму.\",\"src\":\"/chronicle/music/yaga.mp3\"},{\"title\":\"Один путь наверх\",\"length\":\"5:12\",\"note\":\"Лёд, лук и след в снегу. Источник зовёт, другого пути нет.\",\"src\":\"/chronicle/music/naverh.mp3\"},{\"title\":\"Яматай\",\"length\":\"3:54\",\"note\":\"Остров встретил её в волнах и разбил корабль. Она читает знак и не сдаётся.\",\"src\":\"/chronicle/music/yamatai.mp3\"}],\"game\":\"Rise of the Tomb Raider. Сибирь, геотермальная долина, лёд и культ, который старше карты. Лук, верёвка и гробницы, куда не зовут гостей.\",\"lived\":\"Корабль к Яматаю разбило о волны. Дальше один путь наверх: снег, лук и Баба Яга, у которой избушка не дурит. Люси читает знак, не сдаёт след и выходит из долины живой.\"},{\"name\":\"Fallout\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"Пустошь\",\"cover\":\"/chronicle/music/fallout-lucy.jpg\",\"lists\":[{\"name\":\"YouTube · Fallout\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGnTpCV2d5i0z5epscDC0zJZ\"},{\"name\":\"YouTube · Fallout 4\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGk7xJ3EpQywJ1I1ML4bRuFG\"},{\"name\":\"YouTube · Tactics\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGl0kUkgsw3wksEmkoVebCmv\"},{\"name\":\"Rutube · Fallout 1\",\"rutube\":\"https://rutube.ru/plst/1495566/\"},{\"name\":\"Rutube · Fallout 2\",\"rutube\":\"https://rutube.ru/plst/1495567/\"},{\"name\":\"Rutube · Tactics\",\"rutube\":\"https://rutube.ru/plst/1495569/\"}],\"text\":\"Одна пустошь: Fallout, Fallout 2, Tactics и Fallout 4. Это один мир, не четыре. Обложку и песни кладёшь в админке.\",\"tracks\":[],\"game\":\"Одна пустошь, не четыре игры. Fallout, Fallout 2, Fallout Tactics и Fallout 4. Убежища, братство, радиация и люди, которые хуже мутантов, потому что умеют говорить.\",\"lived\":\"Люси ходит по этой пустоши как по одному дому с разными дверями. Вода с радиацией, патроны считаются, доверие нет. Она не спасает мир. Она доживает до следующего костра и не орёт на пустую миску.\"},{\"name\":\"Кенши\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"Песок и любовь\",\"cover\":\"/brand/slides/kenshi.webp\",\"sleeve\":\"/chronicle/music/sleeves/kenshi.jpg\",\"youtube\":\"https://www.youtube.com/playlist?list=PLB8J1X1WE4d4\",\"lists\":[{\"name\":\"YouTube · Кенши\",\"youtube\":\"https://www.youtube.com/playlist?list=PLB8J1X1WE4d4\"}],\"text\":\"Пустыня, кандалы, ящик с камнями и город, который она хочет назвать домом. На Rutube отдельного плейлиста этого мира нет.\",\"tracks\":[{\"title\":\"Где-то там\",\"length\":\"3:10\",\"note\":\"За барханом — дом с каменной стеной, пшеница, хлеб и город, который она назовёт своим.\",\"src\":\"/chronicle/music/gde-to-tam.mp3\"},{\"title\":\"Долина кислотных дождей\",\"length\":\"4:06\",\"note\":\"Дождь точит сталь и плавит лица. Она идёт сквозь него, чтобы просто выжить.\",\"src\":\"/chronicle/music/dolina.mp3\"},{\"title\":\"Кенши\",\"length\":\"3:15\",\"note\":\"Пустыня и зной. Кандалы сняты, на плечах ящик с камнями. Здесь ты — то, что вынес из костра.\",\"src\":\"/chronicle/music/kenshi.mp3\"}],\"game\":\"Kenshi. Луна без жалости: пустыня, работорговцы, кислотный дождь и город, который ещё надо построить своими руками. Сила качается побоями, не уровнями в меню.\",\"lived\":\"Кандалы, ящик с камнями на плечах, песок, который режет глаза. Она сняла железо, прошла долину, где дождь плавит лица, и ищет место за барханом: стена, пшеница, хлеб. Город, который можно назвать своим.\"},{\"name\":\"Пандора\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"Хранилище\",\"cover\":\"/chronicle/music/pandora.jpg\",\"text\":\"Borderlands 2. Охотница за хранилищем: уши, дробовик и жёлтая пыль. Песни этого заезда ещё не выложены.\",\"tracks\":[],\"game\":\"Borderlands 2. Пандора: жёлтая пыль, корпорации, хранилище и юмор, от которого пахнет порохом. Дробовик здесь вежливее большинства людей.\",\"lived\":\"Охотница за хранилищем. Уши, дробовик и то же лицо на фоне взрывов. Она не верит обещаниям на ящиках. Берёт, что стреляет, и уходит, пока пыль не села ей в лёгкие.\"},{\"name\":\"Quake\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"Без Света\",\"cover\":\"/chronicle/music/quake.jpg\",\"text\":\"Quake 2. Металл, кровь и никакого Света. Строгги за спиной, песен с эфира в альбоме пока нет.\",\"tracks\":[],\"game\":\"Quake II. Строгг, орбитальная резня, металл и кровь. Никакого Света, никаких реплик на три абзаца. Коридор, тварь, патрон.\",\"lived\":\"Люси здесь молчит больше обычного. Шутка не спасает, когда стены дышат. Она идёт вперёд, потому что назад тот же металл, и не ищет в этом смысла. Смысл — дожить до двери.\"},{\"name\":\"Сектор Неизвестный\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"TX930\",\"cover\":\"/chronicle/music/sector.jpg\",\"sleeve\":\"/chronicle/music/sleeves/sector.jpg\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGnRb_kFOIhx987_T7XBYdeZ\",\"rutube\":\"https://rutube.ru/plst/1686502/\",\"lists\":[{\"name\":\"YouTube · Сектор\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGnRb_kFOIhx987_T7XBYdeZ\"},{\"name\":\"Rutube · Сектор\",\"rutube\":\"https://rutube.ru/plst/1686502/\"}],\"text\":\"Станция, ржавые звёзды и комбинезон цвета терракоты. Рядом TX930. Она рисует звёзды на стенах и не соглашается быть ужином.\",\"tracks\":[{\"title\":\"Sector Unknown\",\"length\":\"3:56\",\"note\":\"Сны из ржавчины звёзд. Напарник шьёт мысли вместо волокна и просит дышать ровнее.\",\"src\":\"/chronicle/music/sector.mp3\"},{\"title\":\"Сьо, наливай до дна\",\"length\":\"3:15\",\"note\":\"Прилетели за ресурсами, нашли бочки спирта. Топливо кончилось, горючка ещё есть.\",\"src\":\"/chronicle/music/nalivay.mp3\"}],\"game\":\"Сектор Неизвестный. Их космический заезд: станция, ржавые звёзды, комбинезон цвета терракоты и напарник TX930, который чинит мысли чаще, чем обшивку.\",\"lived\":\"Прилетели за ресурсами, нашли бочки. Топливо кончилось, горючка ещё есть. Люси рисует звёзды на стенах и не соглашается быть ужином. Дышит ровнее, чем просит станция.\"},{\"name\":\"NOLF\",\"mark\":\"Пройден\",\"live\":false,\"album\":\"No One Lives Forever\",\"cover\":\"/chronicle/music/nolf.jpg\",\"sleeve\":\"/chronicle/music/sleeves/nolf.jpg\",\"youtube\":\"https://www.youtube.com/playlist?list=PLAJZKbt_9B4U\",\"rutube\":\"https://rutube.ru/plst/1717672/\",\"lists\":[{\"name\":\"YouTube · NOLF\",\"youtube\":\"https://www.youtube.com/playlist?list=PLAJZKbt_9B4U\"},{\"name\":\"Rutube · NOLF\",\"rutube\":\"https://rutube.ru/plst/1717672/\"}],\"text\":\"Шестидесятые. Платье, глушитель и мартини, который она не пьёт. Леди уходит с ключом от дверей.\",\"tracks\":[{\"title\":\"No One Lives Forever\",\"length\":\"3:49\",\"note\":\"Стиль — кредо, шпионаж — корни. Она улыбается, и цели уже нет. Холодная война не повод прощаться.\",\"src\":\"/chronicle/music/nolf.mp3\"}],\"game\":\"The Operative: No One Lives Forever. Шестидесятые, UNITY, платья, которые прячут глушитель, и холодная война в коктейльном бокале.\",\"lived\":\"Мартини она не пьёт. Улыбается так, что цели уже нет, и уходит с ключом от двери. Стиль здесь броня. Если платье помялось, миссия ещё не провалена.\"},{\"name\":\"Азерот\",\"mark\":\"Книга\",\"live\":true,\"album\":\"Свет на камнях\",\"cover\":\"/brand/mock/wow.jpg\",\"sleeve\":\"/chronicle/music/sleeves/azeroth.jpg\",\"lists\":[{\"name\":\"YouTube · WoW Circle\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGkOnx0D5iGHQJ-UKO734xSP\"},{\"name\":\"YouTube · Sirus\",\"youtube\":\"https://www.youtube.com/playlist?list=PLtGnEHCh_VGkfoqbQCEyvSFRSW5mxkGhA\"},{\"name\":\"Rutube · книга 1\",\"rutube\":\"https://rutube.ru/plst/759743/\"},{\"name\":\"Rutube · Калимдор\",\"rutube\":\"https://rutube.ru/plst/1133719/\"}],\"text\":\"Том 1 написан и лежит в историях. Том 2 идёт в эфире: WoW, Сирус, хардкор.\",\"tracks\":[{\"title\":\"Кто не бросает у щита\",\"length\":\"3:42\",\"note\":\"Чужое небо, только имя Люси. Рядом щит, фляга и зверь. Пока ещё есть куда идти.\",\"src\":\"/chronicle/music/schit.mp3\"},{\"title\":\"В чертогах гор\",\"length\":\"4:51\",\"note\":\"Лава рекой, сталь и посох как клинок. Император ждёт, а они не уходят в немую даль.\",\"src\":\"/chronicle/music/chertogi.mp3\"},{\"title\":\"Каменный пол\",\"length\":\"3:05\",\"note\":\"Атал'Хаккар. Семь дней вокруг змеиных статуй, пока храм не сдастся.\",\"src\":\"/chronicle/music/hakkar.mp3\"},{\"title\":\"Героиня сомнительных приключений\",\"length\":\"3:01\",\"note\":\"Ром со дна бухты, слухи Штормграда и жрица, которая просто шила жилетку.\",\"src\":\"/chronicle/music/somnenie.mp3\"},{\"title\":\"Люси-путешественник\",\"length\":\"2:42\",\"note\":\"Пирс Менетил, грифон до Дарнаса и сезонные пробки Азерота.\",\"src\":\"/chronicle/music/puteshestvennik.mp3\"},{\"title\":\"Пирожки под Shadowbolt\",\"length\":\"3:01\",\"note\":\"Хил на страже: свет, бульон и пирожок, пока щиты трещат.\",\"src\":\"/chronicle/music/pirozhki.mp3\"},{\"title\":\"Свиток квестов\",\"length\":\"4:05\",\"note\":\"Детский марафон. Сын бежит за ней, а она держит коня и не велит отставать.\",\"src\":\"/chronicle/music/svitok.mp3\"},{\"title\":\"Хил ищет танка\",\"length\":\"1:41\",\"note\":\"Плакат у фонтана Штормграда. Нужен щит, а мимо бегут коты, локи и шпионы.\",\"src\":\"/chronicle/music/tank.mp3\"},{\"title\":\"Бе-е-е! Ква!\",\"length\":\"3:10\",\"note\":\"Танк гонит группу как фуру, квакает и орёт снять порчу. Люси хилит духами на ходу.\",\"src\":\"/chronicle/music/kva.mp3\"},{\"title\":\"Швейная кураж\",\"length\":\"2:28\",\"note\":\"С корабельных сапог она шьёт плащ. Ром со дна, кожа и легендарный кураж.\",\"src\":\"/chronicle/music/shveya.mp3\"},{\"title\":\"Жизнь одна, но я стальная\",\"length\":\"3:45\",\"note\":\"Полпути пройдено: аббатство, Элвин, Терамор. Назад дороги нет.\",\"src\":\"/chronicle/music/stalnaya.mp3\"},{\"title\":\"Плюс пять к броне\",\"length\":\"1:58\",\"note\":\"Рынок Штормграда. Трусы от Люси: плюс пять к защите, иммунитет к морозу.\",\"src\":\"/chronicle/music/trusy.mp3\"}],\"game\":\"World of Warcraft. Азерот: эльфы, грифоны, Штормград и хардкор, где смерть не кнопка «заново», а дырка в вечере. Том книги растёт из этих ночей.\",\"lived\":\"Здесь у неё эльфийские уши. Жрица, которая шьёт, хилит и орёт, что танка нет. Лава в чертогах, каменный пол Атал'Хаккара, пирожки под шадоуболтом. Полпути пройдено. Назад дороги нет.\"},{\"name\":\"PROJECT ZOMBOID\",\"mark\":\"Сейчас\",\"live\":true,\"album\":\"Ночь без сейва\",\"cover\":\"/chronicle/music/kentucky.jpg\",\"youtube\":\"https://www.youtube.com/playlist?list=PLHGl0TzDzHTs\",\"lists\":[{\"name\":\"YouTube · PROJECT ZOMBOID\",\"youtube\":\"https://www.youtube.com/playlist?list=PLHGl0TzDzHTs\"}],\"text\":\"Project Zomboid. The Great Spiffo Rat Race, бандиты, без сейвов. Лес кормит, пустой дом молчит, кролика надо ещё поймать.\",\"tracks\":[{\"title\":\"Кроликов лови\",\"length\":\"2:02\",\"note\":\"Город как лес. Ловушка, бульон и пульс: пока дышишь, курс держишь.\",\"src\":\"/chronicle/music/kroliki.mp3\"},{\"title\":\"Лес, а не базар\",\"length\":\"2:52\",\"note\":\"На поляне яблоки, свёкла и чужая палатка. Собирай, что видишь.\",\"src\":\"/chronicle/music/les.mp3\"},{\"title\":\"Не робей\",\"length\":\"1:30\",\"note\":\"Он рычит, она не робеет. Копьё в костре, шорох слева и справа.\",\"src\":\"/chronicle/music/robey.mp3\"},{\"title\":\"Пустой дом\",\"length\":\"2:13\",\"note\":\"Пыль на полках, ни окон, ни смеха. Эпидемия забрала и тела, и шкафы. Она всё ещё жива.\",\"src\":\"/chronicle/music/dom.mp3\"},{\"title\":\"Хрупкий огонь\",\"length\":\"4:02\",\"note\":\"Первый шаг в серых домах. Не герой, просто огонь, который ещё дышит.\",\"src\":\"/chronicle/music/ogon.mp3\"}],\"game\":\"Project Zomboid. Кентукки после конца: зомби, бандиты, голод и ни одного сейва. Ошибка стоит персонажа, не перезагрузки.\",\"lived\":\"Люси ловит кроликов, не орёт на пустой дом и держит копьё у костра. Лес кормит лучше барахолки. Она не герой апокалипсиса. Хрупкий огонь, который ещё дышит.\"}]");
var chapter_index_default = /*#__PURE__*/ JSON.parse("[{\"id\":\"prolog\",\"numeral\":\"П\",\"title\":\"Пролог\",\"kicker\":\"Пролог\",\"dek\":\"Сначала был холод.\",\"count\":25},{\"id\":\"glava-1\",\"numeral\":\"1\",\"title\":\"Глава 1\",\"kicker\":\"Глава 1\",\"dek\":\"Я вышла из-за повозки и сразу пожалела, что не осталась лежать. Камни под босыми ногами были холодные, воздух\",\"count\":289},{\"id\":\"g2-01\",\"numeral\":\"1\",\"title\":\"Часть 1\",\"kicker\":\"Глава 2\",\"dek\":\"Письмо капитану Келмарину два дня пролежало у меня в сумке. Ничего с ним не случилось. Бумага помялась ещё сил\",\"count\":56},{\"id\":\"g2-02\",\"numeral\":\"2\",\"title\":\"Часть 2\",\"kicker\":\"Глава 2\",\"dek\":\"Мы ушли от камня Элессар, не открыв сундук. Решение было коллективным: Раф сказал «потом», Асценси сказал «как\",\"count\":35},{\"id\":\"g2-03\",\"numeral\":\"3\",\"title\":\"Часть 3\",\"kicker\":\"Глава 2\",\"dek\":\"Таверна в Анклаве Странников была похожа на всё эльфийское сразу: слишком красивая для места, где воюют, и сли\",\"count\":44},{\"id\":\"g2-04\",\"numeral\":\"4\",\"title\":\"Часть 4\",\"kicker\":\"Глава 2\",\"dek\":\"Остальные пять кусков вырезки я добыла молча. Олени паслись там же, на опушке у границ Диколесья, и каждый раз\",\"count\":34},{\"id\":\"g2-05\",\"numeral\":\"5\",\"title\":\"Часть 5\",\"kicker\":\"Глава 2\",\"dek\":\"Роща Вечной Весны оказалась не тем, что обещало название.\",\"count\":63},{\"id\":\"g2-06\",\"numeral\":\"6\",\"title\":\"Часть 6\",\"kicker\":\"Глава 2\",\"dek\":\"Лагерь следопытов у границы Диколесья был первым местом в Нордероне, которое выглядело так, будто здесь действ\",\"count\":30},{\"id\":\"g2-07\",\"numeral\":\"7\",\"title\":\"Часть 7\",\"kicker\":\"Глава 2\",\"dek\":\"Диколесье начиналось не с границы. Оно начиналось с запаха.\",\"count\":59},{\"id\":\"g2-08\",\"numeral\":\"8\",\"title\":\"Часть 8\",\"kicker\":\"Глава 2\",\"dek\":\"Следующего мы уложили. И того, что за ним. А потом застава на какое-то время затихла — не сдалась, нет, просто\",\"count\":39},{\"id\":\"g2-09\",\"numeral\":\"9\",\"title\":\"Часть 9\",\"kicker\":\"Глава 2\",\"dek\":\"Налётчик девятого уровня умер как червяк.\",\"count\":52},{\"id\":\"g2-10\",\"numeral\":\"10\",\"title\":\"Часть 10\",\"kicker\":\"Глава 2\",\"dek\":\"Лагерь жил своей жизнью, и кое-что в ней изменилось — я заметила это не сразу. Двое следопытов собирались на с\",\"count\":21},{\"id\":\"g2-11\",\"numeral\":\"11\",\"title\":\"Часть 11\",\"kicker\":\"Глава 2\",\"dek\":\"Задание называлось «Поиск аномалий», и, честно говоря, это было самое мирное, что мне предлагали со дня рожден\",\"count\":32},{\"id\":\"g2-12\",\"numeral\":\"12\",\"title\":\"Часть 12\",\"kicker\":\"Глава 2\",\"dek\":\"Мьюра Яркопряд стояла у своей палатки, рядом с баллистами, и, увидев меня, перестала теребить рукав. Значит, я\",\"count\":24},{\"id\":\"g2-13\",\"numeral\":\"13\",\"title\":\"Часть 13\",\"kicker\":\"Глава 2\",\"dek\":\"Чаща здесь была другая.\",\"count\":46},{\"id\":\"g2-14\",\"numeral\":\"14\",\"title\":\"Часть 14\",\"kicker\":\"Глава 2\",\"dek\":\"Семь листьев я несла так, будто это были не листья, а чья-то жизнь. По сути, так оно и было.\",\"count\":32},{\"id\":\"g2-15\",\"numeral\":\"15\",\"title\":\"Часть 15\",\"kicker\":\"Глава 2\",\"dek\":\"Шесть клинков в сумке — это тяжело. Не по весу, по ощущению. Шесть кусков стали, на которых кровь почти сливае\",\"count\":30},{\"id\":\"g2-16\",\"numeral\":\"16\",\"title\":\"Часть 16\",\"kicker\":\"Глава 2\",\"dek\":\"Мьюра заговорила, и я запомнила её слова почти дословно. По голосу было ясно: это не просьба, это то, что прид\",\"count\":27},{\"id\":\"g2-17\",\"numeral\":\"17\",\"title\":\"Часть 17\",\"kicker\":\"Глава 2\",\"dek\":\"Я вернулась в тело.\",\"count\":42},{\"id\":\"g2-18\",\"numeral\":\"18\",\"title\":\"Часть 18\",\"kicker\":\"Глава 2\",\"dek\":\"Мост был верёвочный.\",\"count\":30},{\"id\":\"g2-19\",\"numeral\":\"19\",\"title\":\"Часть 19\",\"kicker\":\"Глава 2\",\"dek\":\"Храм рос вверх террасами.\",\"count\":46},{\"id\":\"g2-20\",\"numeral\":\"20\",\"title\":\"Часть 20\",\"kicker\":\"Глава 2\",\"dek\":\"Двенадцатая маска упала прямо мне под ноги, и я поняла, что больше не помню, как падала седьмая. Наверное, это\",\"count\":33},{\"id\":\"g2-21\",\"numeral\":\"21\",\"title\":\"Часть 21\",\"kicker\":\"Глава 2\",\"dek\":\"— Должна признать, — сказала Мьюра, пока я ещё возилась с завязками новых штанов, — магические навыки этих тро\",\"count\":29},{\"id\":\"g2-22\",\"numeral\":\"22\",\"title\":\"Часть 22\",\"kicker\":\"Глава 2\",\"dek\":\"Раф подошёл ко мне с тем видом, с каким щитоносцы обычно просят об одолжении: будто делают одолжение тебе.\",\"count\":29},{\"id\":\"g2-23\",\"numeral\":\"23\",\"title\":\"Часть 23\",\"kicker\":\"Глава 2\",\"dek\":\"Храм Великой Змеи встретил нас всё теми же ступенями. Широкими, каменными, уходящими вверх, будто тролли строи\",\"count\":50},{\"id\":\"g2-24\",\"numeral\":\"24\",\"title\":\"Часть 24\",\"kicker\":\"Глава 2\",\"dek\":\"Когда змей исчез, в храме стало очень тихо.\",\"count\":34},{\"id\":\"g2-25\",\"numeral\":\"25\",\"title\":\"Часть 25\",\"kicker\":\"Глава 2\",\"dek\":\"Шестой ведун всё-таки нашёлся. Я не стала спрашивать у храма, сколько их там ещё осталось. Мне нужно было ровн\",\"count\":26},{\"id\":\"g2-26\",\"numeral\":\"26\",\"title\":\"Часть 26\",\"kicker\":\"Глава 2\",\"dek\":\"Зеб'Джунта не была похожа на храм.\",\"count\":40},{\"id\":\"g2-27\",\"numeral\":\"27\",\"title\":\"Часть 27\",\"kicker\":\"Глава 2\",\"dek\":\"Это случилось посреди Зеб'Джунты, на мощёной дорожке между двумя частоколами.\",\"count\":21},{\"id\":\"g2-28\",\"numeral\":\"28\",\"title\":\"Часть 28\",\"kicker\":\"Глава 2\",\"dek\":\"Сапоги ещё жали, когда Келмарин уже нашёл мне дело.\",\"count\":21},{\"id\":\"g2-29\",\"numeral\":\"29\",\"title\":\"Часть 29\",\"kicker\":\"Глава 2\",\"dek\":\"К троллям вела мощёная тропа. Вечерело. Вдоль дороги торчали факелы на высоких шестах, и огонь в них трещал та\",\"count\":35},{\"id\":\"g2-30\",\"numeral\":\"30\",\"title\":\"Часть 30\",\"kicker\":\"Глава 2\",\"dek\":\"Зеб'Джунта горела вечерним золотом. Солнце садилось где-то за частоколом, и длинные тени от бивней над хижинам\",\"count\":48},{\"id\":\"g2-31\",\"numeral\":\"31\",\"title\":\"Часть 31\",\"kicker\":\"Глава 2\",\"dek\":\"Голова Джин'Аккара лежала у меня в сумке и, кажется, всё ещё злилась. Но сначала я пошла к Мьюре. Красная стро\",\"count\":10},{\"id\":\"g2-32\",\"numeral\":\"32\",\"title\":\"Часть 32\",\"kicker\":\"Глава 2\",\"dek\":\"Асценси остановился на краю поляны так резко, что я чуть не врезалась ему в спину.\",\"count\":29},{\"id\":\"g2-33\",\"numeral\":\"33\",\"title\":\"Часть 33\",\"kicker\":\"Глава 2\",\"dek\":\"Голову Джин'Аккара я несла сама. Не потому, что так требовал героический канон, а потому что Раф сказал: «Ты з\",\"count\":33},{\"id\":\"g3-01\",\"numeral\":\"1\",\"title\":\"Часть 1\",\"kicker\":\"Глава 3\",\"dek\":\"— Люси, — сказал чародей Таэдрис, и это прозвучало не как приветствие, а как подпись под приказом. — Нам нужно\",\"count\":21},{\"id\":\"g3-02\",\"numeral\":\"2\",\"title\":\"Часть 2\",\"kicker\":\"Глава 3\",\"dek\":\"Перед спуском Илнурия зачитала нам предупреждение.\",\"count\":19},{\"id\":\"g3-03\",\"numeral\":\"3\",\"title\":\"Часть 3\",\"kicker\":\"Глава 3\",\"dek\":\"Сфера в центре зала треснула светом, и голос, который до этого только огрызался, вдруг стал торжественным. Так\",\"count\":15},{\"id\":\"g3-04\",\"numeral\":\"4\",\"title\":\"Часть 4\",\"kicker\":\"Глава 3\",\"dek\":\"Разлом схлопнулся, как вода в сливе. Сначала в нём исчез Антарис. Потом погасло бело-голубое сияние Астранимус\",\"count\":17},{\"id\":\"g3-05\",\"numeral\":\"5\",\"title\":\"Часть 5\",\"kicker\":\"Глава 3\",\"dek\":\"— Нет, — сказал Раф. — Сегодня — нет.\",\"count\":25},{\"id\":\"g3-06\",\"numeral\":\"6\",\"title\":\"Часть 6\",\"kicker\":\"Глава 3\",\"dek\":\"— Слушай, — сказал Раф, поравнявшись со мной. — А этот Норалас. Город в руинах, никто не знает, почему он пал.\",\"count\":15},{\"id\":\"g3-07\",\"numeral\":\"7\",\"title\":\"Часть 7\",\"kicker\":\"Глава 3\",\"dek\":\"Камень фамильяра треснул светом у меня в ладони раньше, чем я успела передумать.\",\"count\":21},{\"id\":\"g3-08\",\"numeral\":\"8\",\"title\":\"Часть 8\",\"kicker\":\"Глава 3\",\"dek\":\"— Я не буду их убивать, — сказала я. — Не так. Не по счёту.\",\"count\":27},{\"id\":\"g3-09\",\"numeral\":\"9\",\"title\":\"Часть 9\",\"kicker\":\"Глава 3\",\"dek\":\"Норалас встретил нас белыми колоннами.\",\"count\":16},{\"id\":\"g3-10\",\"numeral\":\"10\",\"title\":\"Часть 10\",\"kicker\":\"Глава 3\",\"dek\":\"Чаромантический маячок оказался маленьким, прохладным и неприятно живым. Он тихо пульсировал в ладони, как вто\",\"count\":30},{\"id\":\"g3-11\",\"numeral\":\"11\",\"title\":\"Часть 11\",\"kicker\":\"Глава 3\",\"dek\":\"Я сжала камень возвращения.\",\"count\":13},{\"id\":\"g3-12\",\"numeral\":\"12\",\"title\":\"Часть 12\",\"kicker\":\"Глава 3\",\"dek\":\"Предмет в моих ладонях наполовину превратился в свет и пыль, когда я дёрнулась. Совсем чуть-чуть. Этого хватил\",\"count\":17},{\"id\":\"g3-13\",\"numeral\":\"13\",\"title\":\"Часть 13\",\"kicker\":\"Глава 3\",\"dek\":\"— Хлеб ты уже знаешь, — сказал Аллинар и сам, пальцами в муке, перелистнул страницу моей книги рецептов. — Рук\",\"count\":11},{\"id\":\"g3-14\",\"numeral\":\"14\",\"title\":\"Часть 14\",\"kicker\":\"Глава 3\",\"dek\":\"— Повар-подмастерье, — громко сказал Аллинар, чтобы слышали у соседних очагов. — Поздравляю, Люси.\",\"count\":13},{\"id\":\"g3-15\",\"numeral\":\"15\",\"title\":\"Часть 15\",\"kicker\":\"Глава 3\",\"dek\":\"— Она вернулась, — объявил Раф медведю. — Я же говорил. Ставь.\",\"count\":54},{\"id\":\"g3-16\",\"numeral\":\"16\",\"title\":\"Часть 16\",\"kicker\":\"Глава 3\",\"dek\":\"Утром я разносила долги, и каждый долг, оказывается, что-то менял.\",\"count\":69},{\"id\":\"g3-17\",\"numeral\":\"17\",\"title\":\"Часть 17\",\"kicker\":\"Глава 3\",\"dek\":\"Вниз.\",\"count\":81},{\"id\":\"g3-18\",\"numeral\":\"18\",\"title\":\"Часть 18\",\"kicker\":\"Глава 3\",\"dek\":\"Внизу, на дне катакомб, был лагерь.\",\"count\":139}]");
var video_counts_default = {
	Готика: 8,
	Кальрадия: 8,
	Pathfinder: 8,
	"Path of Exile": 1,
	"Tomb Raider": 10,
	Fallout: 42,
	Кенши: 8,
	"Сектор Неизвестный": 10,
	NOLF: 16,
	Азерот: 27,
	"PROJECT ZOMBOID": 8
};
var ORIGIN = "https://ghostpot.ru";
var LOCAL = /* @__PURE__ */ new Set([
	"/brand/ghostpot-word.webp",
	"/brand/book.webp",
	"/brand/hero-photo.webp",
	"/brand/hungry.webp",
	"/brand/nikolay.webp"
]);
function media(src) {
	if (!src) return "";
	if (src.startsWith("http") || LOCAL.has(src.split("?")[0])) return src;
	return `${ORIGIN}${src}`;
}
var worlds = worlds_default;
var chapterIndex = chapter_index_default;
var videoCounts = video_counts_default;
var catalog = worlds.flatMap((world) => world.tracks.filter((track) => track.src).map((track) => ({
	title: track.title,
	world: world.name,
	src: track.src,
	cover: world.sleeve || world.cover,
	length: track.length,
	note: track.note ?? ""
})));
var lucySongs = [{
	title: "Ни то",
	world: "Люси",
	src: "/chronicle/music/nito.mp3",
	cover: "/chronicle/music/sleeves/lucy.jpg",
	length: "2:31",
	note: "Косичка криво, носки как жуки. Хотелось лето, а всё не то."
}, {
	title: "Сон",
	world: "Люси",
	src: "/chronicle/music/son.mp3",
	cover: "/chronicle/music/sleeves/lucy.jpg",
	length: "4:30",
	note: "В метро, в пробке и в кресле. Нет сил оторваться и вернуться из сказки."
}];
catalog.push(...lucySongs);
var nights = [
	{
		when: "5 октября 2026, ночь",
		where: "PROJECT ZOMBOID",
		note: "Около трёх часов, без сейва."
	},
	{
		when: "28 сентября 2026, ночь",
		where: "PROJECT ZOMBOID",
		note: "Мёртвые и бандиты. Первая часть той жизни."
	},
	{
		when: "Эфир без даты на афише",
		where: "Азерот",
		note: "Книга 2, WoW Сирус, хардкор. Точное время — только в Telegram."
	}
];
var channels = [
	{
		name: "YouTube",
		href: "https://www.youtube.com/@gh0stpot",
		note: "Записи и шорты"
	},
	{
		name: "Rutube",
		href: "https://rutube.ru/channel/42619609/",
		note: "Записи"
	},
	{
		name: "GoodGame",
		href: "https://goodgame.ru/Ghostpot",
		note: "Эфир"
	},
	{
		name: "Twitch",
		href: "https://www.twitch.tv/ghostpot",
		note: "Эфир"
	},
	{
		name: "Trovo",
		href: "https://trovo.live/s/Ghostpot",
		note: "Эфир"
	},
	{
		name: "Kick",
		href: "https://kick.com/ghostpot",
		note: "Эфир"
	},
	{
		name: "DLive",
		href: "https://dlive.tv/Ghostpot",
		note: "Эфир"
	},
	{
		name: "Steam",
		href: "https://steamcommunity.com/broadcast/watch/76561198059361723",
		note: "Трансляция"
	},
	{
		name: "Boosty",
		href: "https://boosty.to/ghostpot",
		note: "Поддержать"
	},
	{
		name: "W.TV",
		href: "https://w.tv/ghostpot",
		note: "Эфир"
	},
	{
		name: "Дзен",
		href: "https://dzen.ru/ghostpot",
		note: "Записи"
	},
	{
		name: "VK Видео",
		href: "https://live.vkvideo.ru/ghostpot",
		note: "Трансляции и записи"
	}
];
var links = {
	telegram: "https://t.me/ghostpotplay",
	max: "https://max.ru/channel_Ghostpot",
	mail: "mailto:nikolay@whitebunny.ru",
	email: "nikolay@whitebunny.ru",
	boosty: "https://boosty.to/ghostpot",
	alerts: "https://www.donationalerts.com/r/ghostpot_play",
	twitch: "https://www.twitch.tv/ghostpot",
	vkArchive: "https://vkvideo.ru/@club226635413"
};
var skills = [
	{
		name: "Сайт",
		note: "Чужие страницы, свои нервы."
	},
	{
		name: "Эфир",
		note: "Не выходит, пока история жива."
	},
	{
		name: "Книга",
		note: "Пишется прямо в ночи."
	},
	{
		name: "Песня",
		note: "Если мир молчит, она поёт."
	},
	{
		name: "Стойкость",
		note: "Сорок лет, ещё дышит."
	},
	{
		name: "Сумка",
		note: "Почти пустая. Классика."
	}
];
var passport = [
	["Имя", "Люси"],
	["Возраст", "25"],
	["Рост", "172"],
	["Уши", "Рысьи. Эльфийские только в Азероте."],
	["Лицо", "Одно и то же в каждом мире."],
	["Характер", "Сарказм вместо брони. Усталость, не крик."],
	["Как попадает", "Без вещей. Мир решает, кем она тут числится."],
	["Что не меняется", "Голос, лицо и привычка шутить, когда страшно."]
];
var hatShots = [
	{
		src: "/shop/lucy-1.jpg",
		alt: "Люси в банной шапке в парной."
	},
	{
		src: "/shop/lucy-2.jpg",
		alt: "Люси крупно, видна вязка шапки."
	},
	{
		src: "/shop/lucy-3.jpg",
		alt: "Люси показывает шапку и мешочек."
	},
	{
		src: "/shop/lucy-4.jpg",
		alt: "Люси в шапке на полке."
	},
	{
		src: "/shop/hat-real.jpg",
		alt: "Живое фото шапки с льняным мешочком."
	}
];
function videoCount(name) {
	return videoCounts[name] ?? 0;
}
function volumes() {
	const order = [];
	const map = /* @__PURE__ */ new Map();
	for (const chapter of chapterIndex) {
		const key = chapter.kicker || "Книга";
		if (!map.has(key)) {
			map.set(key, []);
			order.push(key);
		}
		map.get(key).push(chapter);
	}
	return order.map((name) => ({
		name,
		chapters: map.get(name)
	}));
}
var prologue = [{
	id: "pro-1",
	chapter: "Пролог",
	title: "Пролог",
	src: "/chronicle/audio/prologue_revoice.mp3"
}];
var chapterOne = Array.from({ length: 17 }, (_, index) => ({
	id: `c1-${index + 1}`,
	chapter: "Глава 1",
	title: `Часть ${index + 1}`,
	src: `/chronicle/audio/chapter1_part${index + 1}.mp3`
}));
var chapterTwo = Array.from({ length: 123 }, (_, index) => {
	const n = index + 1;
	const v = n >= 22 && n <= 41 ? "?v=2" : "";
	return {
		id: `c2-${n}`,
		chapter: "Глава 2",
		title: `Часть ${n}`,
		src: `/chronicle/audio/chapter2_part${n}.mp3${v}`
	};
});
var chapterThree = [
	{
		n: 1,
		title: "Часть 1",
		from: 1,
		to: 1
	},
	{
		n: 2,
		title: "Часть 2",
		from: 2,
		to: 3
	},
	{
		n: 3,
		title: "Части 3–4",
		from: 3,
		to: 4
	},
	{
		n: 4,
		title: "Часть 5",
		from: 5,
		to: 5
	},
	{
		n: 5,
		title: "Части 6–7",
		from: 6,
		to: 7
	},
	{
		n: 6,
		title: "Часть 8",
		from: 8,
		to: 8
	},
	{
		n: 7,
		title: "Часть 9",
		from: 9,
		to: 9
	},
	{
		n: 8,
		title: "Часть 10",
		from: 10,
		to: 10
	},
	{
		n: 9,
		title: "Части 11–12",
		from: 11,
		to: 12
	},
	{
		n: 10,
		title: "Части 13–14",
		from: 13,
		to: 14
	},
	{
		n: 11,
		title: "Часть 15",
		from: 15,
		to: 15
	},
	{
		n: 12,
		title: "Часть 15",
		from: 15,
		to: 15
	},
	{
		n: 13,
		title: "Часть 16",
		from: 16,
		to: 16
	},
	{
		n: 14,
		title: "Часть 16",
		from: 16,
		to: 16
	},
	{
		n: 15,
		title: "Часть 17",
		from: 17,
		to: 17
	},
	{
		n: 16,
		title: "Часть 17",
		from: 17,
		to: 17
	},
	{
		n: 17,
		title: "Часть 18",
		from: 18,
		to: 18
	},
	{
		n: 18,
		title: "Часть 18",
		from: 18,
		to: 18
	},
	{
		n: 19,
		title: "Часть 18",
		from: 18,
		to: 18
	},
	{
		n: 20,
		title: "Часть 18",
		from: 18,
		to: 18
	},
	{
		n: 25,
		title: "Часть 18",
		from: 18,
		to: 18
	}
].map(({ n, title }) => ({
	id: `c3-${n}`,
	chapter: "Глава 3",
	title,
	src: `/chronicle/audio/chapter3_part${n}.mp3${n <= 21 ? "?v=2" : ""}`
}));
var narration = [
	...prologue,
	...chapterOne,
	...chapterTwo,
	...chapterThree
];
function bookOn() {
	if (typeof window !== "undefined") window.dispatchEvent(new Event("ghostpot-book"));
}
var useBookAudio = create((set, get) => ({
	queue: narration,
	index: -1,
	playing: false,
	currentTime: 0,
	duration: 0,
	volume: .9,
	collapsed: false,
	restart: 0,
	play: (track) => {
		const index = narration.findIndex((item) => item.id === track.id);
		bookOn();
		set({
			queue: narration,
			index: index < 0 ? 0 : index,
			playing: true,
			currentTime: 0,
			collapsed: false
		});
	},
	toggle: () => {
		const { index, playing } = get();
		if (index < 0) return;
		if (!playing) bookOn();
		set({ playing: !playing });
	},
	pause: () => set({ playing: false }),
	next: () => {
		const { index, queue } = get();
		if (!queue.length || index < 0) return;
		if (index >= queue.length - 1) {
			set({ playing: false });
			return;
		}
		bookOn();
		set({
			index: index + 1,
			playing: true,
			currentTime: 0
		});
	},
	prev: () => {
		const { index, queue, currentTime, restart } = get();
		if (index < 0 || !queue.length) return;
		if (currentTime > 3) {
			set({
				currentTime: 0,
				playing: true,
				restart: restart + 1
			});
			return;
		}
		bookOn();
		set({
			index: Math.max(0, index - 1),
			playing: true,
			currentTime: 0
		});
	},
	seek: (ratio) => {
		const duration = get().duration || 0;
		set({ currentTime: Math.max(0, Math.min(1, ratio)) * duration });
	},
	setTime: (currentTime, duration) => set({
		currentTime,
		duration
	}),
	setVolume: (volume) => {
		localStorage.setItem("ghostpot-book-volume", String(volume));
		set({ volume });
	},
	setCollapsed: (collapsed) => set({ collapsed })
}));
function trackPlace(id) {
	const prefix = id.startsWith("pro-") ? "pro-" : id.startsWith("c1-") ? "c1-" : id.startsWith("c2-") ? "c2-" : id.startsWith("c3-") ? "c3-" : "";
	if (!prefix) return null;
	const group = prefix === "pro-" ? "prolog" : prefix === "c1-" ? "glava-1" : prefix === "c2-" ? "g2" : "g3";
	const list = narration.filter((item) => item.id.startsWith(prefix));
	const index = list.findIndex((item) => item.id === id);
	if (index < 0 || !list.length) return null;
	return {
		group,
		index,
		count: list.length
	};
}
function groupChapters(chapters, group) {
	if (group === "prolog") return chapters.filter((chapter) => chapter.id === "prolog");
	if (group === "glava-1") return chapters.filter((chapter) => chapter.id === "glava-1");
	const prefix = group === "g2" ? "g2-" : "g3-";
	return chapters.filter((chapter) => chapter.id.startsWith(prefix)).sort((a, b) => a.id.localeCompare(b.id, "ru", { numeric: true }));
}
function scriptLength(paragraphs) {
	if (!paragraphs.length) return 1;
	return paragraphs.reduce((sum, paragraph) => sum + paragraph.length, 0) + (paragraphs.length - 1);
}
function speakAt(chapters, group, globalRatio) {
	const list = groupChapters(chapters, group);
	if (!list.length) return null;
	const lengths = list.map((chapter) => scriptLength(chapter.paragraphs));
	const total = lengths.reduce((sum, length) => sum + length, 0);
	let pos = Math.min(1, Math.max(0, globalRatio)) * total;
	for (let index = 0; index < list.length; index += 1) {
		const length = lengths[index];
		if (pos < length || index === list.length - 1) return {
			chapterId: list[index].id,
			ratio: Math.min(1, Math.max(0, pos / length))
		};
		pos -= length;
	}
	return null;
}
var DUR_KEY = "ghostpot-audio-dur";
function rememberDuration(id, duration) {
	if (typeof localStorage === "undefined" || !id || !Number.isFinite(duration) || duration < 1) return;
	let all = {};
	try {
		all = JSON.parse(localStorage.getItem(DUR_KEY) || "{}");
	} catch {
		all = {};
	}
	const next = Math.round(duration * 10) / 10;
	if (Math.abs((all[id] ?? 0) - next) < .4) return;
	all[id] = next;
	localStorage.setItem(DUR_KEY, JSON.stringify(all));
}
function voiceRatio(id, current, duration) {
	const place = trackPlace(id);
	if (!place || duration <= 0) return null;
	const prefix = id.startsWith("pro-") ? "pro-" : id.startsWith("c1-") ? "c1-" : id.startsWith("c2-") ? "c2-" : "c3-";
	const list = narration.filter((item) => item.id.startsWith(prefix));
	let known = {};
	try {
		known = JSON.parse(localStorage.getItem(DUR_KEY) || "{}");
	} catch {
		known = {};
	}
	const guess = duration;
	const lengths = list.map((item) => known[item.id] || guess);
	const total = lengths.reduce((sum, length) => sum + length, 0);
	if (total <= 0) return null;
	const before = lengths.slice(0, place.index).reduce((sum, length) => sum + length, 0);
	const here = Math.min(lengths[place.index] || guess, Math.max(0, current));
	return {
		group: place.group,
		ratio: Math.min(1, (before + here) / total)
	};
}
var cuesPack = null;
var cuesJob = null;
function loadCues() {
	if (cuesPack) return Promise.resolve(cuesPack);
	if (typeof fetch === "undefined") return Promise.resolve({});
	cuesJob ??= fetch("/chronicle/cues.json?v=3").then((res) => res.ok ? res.json() : {}).then((data) => {
		for (const list of Object.values(data)) if (Array.isArray(list)) list.sort((a, b) => a[0] - b[0]);
		cuesPack = data;
		return data;
	}).catch(() => {
		cuesPack = {};
		return cuesPack;
	});
	return cuesJob;
}
function cuePoint(cues, time) {
	let lo = 0;
	let hi = cues.length - 1;
	let ans = -1;
	while (lo <= hi) {
		const mid = lo + hi >> 1;
		if (cues[mid][0] <= time + .03) {
			ans = mid;
			lo = mid + 1;
		} else hi = mid - 1;
	}
	if (ans < 0) return null;
	const [t0, t1, chapterId, start, end] = cues[ans];
	if (time >= t1) return {
		chapterId,
		pos: end
	};
	const fill = Math.min(1, Math.max(0, (time - t0) / Math.max(.04, t1 - t0)));
	return {
		chapterId,
		pos: start + (end - start) * fill
	};
}
function chapterWords(paragraphs) {
	const words = [];
	let cursor = 0;
	paragraphs.forEach((paragraph, index) => {
		const line = [];
		for (const part of paragraph.split(/(\s+)/)) {
			if (!part) continue;
			const start = cursor;
			cursor += part.length;
			if (!/^\s+$/.test(part)) line.push({
				text: part,
				start,
				end: cursor
			});
		}
		words.push(line);
		if (index < paragraphs.length - 1) cursor += 1;
	});
	return {
		words,
		total: Math.max(1, cursor)
	};
}
var kept = /* @__PURE__ */ new Map();
/** One audio node per id, outside React, so a route change does not stop playback. */
function keepAudio(id) {
	if (typeof document === "undefined") return null;
	let audio = kept.get(id);
	if (!audio) {
		audio = document.createElement("audio");
		audio.preload = "none";
		audio.dataset.keep = id;
		kept.set(id, audio);
	}
	if (!audio.isConnected) document.body.appendChild(audio);
	return audio;
}
function BookBar() {
	const audioRef = (0, import_react.useRef)(null);
	const seekLock = (0, import_react.useRef)(false);
	const queue = useBookAudio((s) => s.queue);
	const index = useBookAudio((s) => s.index);
	const playing = useBookAudio((s) => s.playing);
	const volume = useBookAudio((s) => s.volume);
	const currentTime = useBookAudio((s) => s.currentTime);
	const setTime = useBookAudio((s) => s.setTime);
	const setVolume = useBookAudio((s) => s.setVolume);
	const pause = useBookAudio((s) => s.pause);
	const next = useBookAudio((s) => s.next);
	const track = index >= 0 ? queue[index] : void 0;
	(0, import_react.useLayoutEffect)(() => {
		const audio = keepAudio("book");
		audioRef.current = audio;
		if (!audio) return;
		const onTime = () => {
			if (seekLock.current) return;
			setTime(audio.currentTime, audio.duration || 0);
		};
		const onMeta = () => {
			setTime(audio.currentTime, audio.duration || 0);
			const current = useBookAudio.getState();
			const item = current.index >= 0 ? current.queue[current.index] : void 0;
			if (item && Number.isFinite(audio.duration)) rememberDuration(item.id, audio.duration);
		};
		const onEnded = () => next();
		audio.addEventListener("timeupdate", onTime);
		audio.addEventListener("loadedmetadata", onMeta);
		audio.addEventListener("ended", onEnded);
		return () => {
			audio.removeEventListener("timeupdate", onTime);
			audio.removeEventListener("loadedmetadata", onMeta);
			audio.removeEventListener("ended", onEnded);
		};
	}, [next, setTime]);
	(0, import_react.useEffect)(() => {
		const raw = localStorage.getItem("ghostpot-book-volume");
		if (raw === null) return;
		const saved = Number(raw);
		if (Number.isFinite(saved)) setVolume(saved);
	}, [setVolume]);
	(0, import_react.useEffect)(() => {
		const onMusic = () => pause();
		window.addEventListener("ghostpot-music", onMusic);
		return () => window.removeEventListener("ghostpot-music", onMusic);
	}, [pause]);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio) return;
		audio.volume = volume;
	}, [volume]);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio || !track) return;
		if (audio.dataset.src !== track.src) {
			const resume = useBookAudio.getState().currentTime;
			audio.dataset.src = track.src;
			audio.src = media(track.src);
			if (resume > 1) {
				const seekResume = () => {
					if (audio.duration) audio.currentTime = Math.min(resume, Math.max(0, audio.duration - .4));
					audio.removeEventListener("loadedmetadata", seekResume);
				};
				audio.addEventListener("loadedmetadata", seekResume);
			}
		}
		if (playing) audio.play().catch(() => pause());
		else audio.pause();
	}, [
		track,
		playing,
		pause
	]);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio || !track) return;
		if (Math.abs(audio.currentTime - currentTime) > .75) audio.currentTime = currentTime;
	}, [currentTime, track]);
	return null;
}
function Shot({ src, alt, className, priority = false }) {
	const [ok, setOk] = (0, import_react.useState)(true);
	if (!src || !ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `ph ${className ?? ""}`,
		"aria-hidden": "true",
		children: (alt || "Л").slice(0, 1)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: media(src),
		alt,
		className,
		loading: priority ? "eager" : "lazy",
		fetchPriority: priority ? "high" : "auto",
		decoding: "async",
		onError: () => setOk(false)
	});
}
function markHot(mark) {
	return mark === "Сейчас" || mark === "Книга";
}
function platesAfter(plates) {
	const map = /* @__PURE__ */ new Map();
	for (const plate of plates ?? []) {
		const list = map.get(plate.after) ?? [];
		list.push(plate);
		map.set(plate.after, list);
	}
	return map;
}
function Plates({ plates }) {
	return plates.map((plate) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "plate",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
			src: plate.src,
			alt: plate.alt
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", { children: plate.alt })]
	}, plate.src));
}
function BookProse({ chapterId, chapters, paragraphs, plates, size, karaoke, onFollow }) {
	const rootRef = (0, import_react.useRef)(null);
	const onFollowRef = (0, import_react.useRef)(onFollow);
	onFollowRef.current = onFollow;
	const after = platesAfter(plates);
	(0, import_react.useEffect)(() => {
		if (!karaoke) return;
		const root = rootRef.current;
		if (!root) return;
		const { words, total } = chapterWords(paragraphs);
		const flat = words.flat();
		const nodes = Array.from(root.querySelectorAll("[data-w]"));
		let now = -1;
		let chasing = "";
		const cuesRef = { current: null };
		let dead = false;
		const wordAt = (pos) => {
			let lo = 0;
			let hi = flat.length - 1;
			let ans = 0;
			while (lo <= hi) {
				const mid = lo + hi >> 1;
				if (flat[mid].start <= pos) {
					ans = mid;
					lo = mid + 1;
				} else hi = mid - 1;
			}
			return ans;
		};
		const paint = () => {
			const state = useBookAudio.getState();
			const track = state.index >= 0 ? state.queue[state.index] : void 0;
			if (!track || !flat.length) return;
			const timed = cuesRef.current?.[track.id];
			let chapterHit = "";
			let pos = -1;
			if (timed?.length) {
				const hit = cuePoint(timed, state.currentTime);
				if (!hit) return;
				chapterHit = hit.chapterId;
				pos = hit.pos;
			} else if (state.duration > 0) {
				const voice = voiceRatio(track.id, state.currentTime, state.duration);
				if (!voice) return;
				const at = speakAt(chapters, voice.group, voice.ratio);
				if (!at) return;
				chapterHit = at.chapterId;
				if (!cuesRef.current && chapterHit !== chapterId) return;
				pos = at.ratio * total;
			} else return;
			if (chapterHit !== chapterId) {
				if (state.playing && chasing !== chapterHit) {
					chasing = chapterHit;
					onFollowRef.current(chapterHit);
				}
				return;
			}
			chasing = "";
			const found = wordAt(pos);
			const current = nodes[found];
			if (!current) return;
			if (found !== now) {
				const low = now < 0 ? 0 : Math.min(now, found);
				const high = now < 0 ? found : Math.max(now, found);
				for (let item = low; item <= high; item += 1) {
					const node = nodes[item];
					if (!node) continue;
					node.classList.toggle("is-said", item < found);
					node.classList.toggle("is-now", item === found);
					if (item !== found) node.style.removeProperty("--p");
				}
				now = found;
				const selection = window.getSelection();
				if (selection && !selection.isCollapsed) return;
				const rect = current.getBoundingClientRect();
				const topLimit = window.innerHeight * .22;
				const bottomLimit = window.innerHeight - 150;
				if (rect.top < topLimit || rect.bottom > bottomLimit) {
					const far = rect.top < -window.innerHeight || rect.bottom > window.innerHeight * 2;
					const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
					current.scrollIntoView({
						block: "center",
						behavior: far || reduce ? "auto" : "smooth"
					});
				}
			}
			const word = flat[found];
			const fill = Math.min(100, Math.max(0, (pos - word.start) / Math.max(1, word.end - word.start) * 100));
			current.style.setProperty("--p", `${fill.toFixed(1)}%`);
		};
		loadCues().then((data) => {
			if (dead) return;
			cuesRef.current = data;
			paint();
		});
		paint();
		const unsub = useBookAudio.subscribe(paint);
		return () => {
			dead = true;
			unsub();
		};
	}, [
		karaoke,
		chapterId,
		chapters,
		paragraphs
	]);
	if (!karaoke) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "prose",
		"data-size": size,
		children: paragraphs.map((paragraph, paragraphIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plates, { plates: after.get(paragraphIndex) ?? [] })] }, `${chapterId}-${paragraphIndex}`))
	});
	let wordIndex = 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "prose",
		"data-size": size,
		"data-karaoke": "1",
		ref: rootRef,
		children: paragraphs.map((paragraph, paragraphIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph.split(/(\s+)/).map((part, partIndex) => {
			if (!part) return null;
			if (/^\s+$/.test(part)) return part;
			const index = wordIndex;
			wordIndex += 1;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "kara-word",
				"data-w": index,
				children: part
			}, index);
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plates, { plates: after.get(paragraphIndex) ?? [] })] }, `${chapterId}-${paragraphIndex}`))
	});
}
function musicOn() {
	if (typeof window !== "undefined") window.dispatchEvent(new Event("ghostpot-music"));
}
var usePlayer = create((set, get) => ({
	queue: catalog,
	index: -1,
	playing: false,
	currentTime: 0,
	duration: 0,
	volume: .9,
	queueOpen: false,
	restart: 0,
	collapsed: false,
	setCollapsed: (collapsed) => {
		localStorage.setItem("ghostpot-player-hidden", collapsed ? "1" : "0");
		set({
			collapsed,
			queueOpen: collapsed ? false : get().queueOpen
		});
	},
	play: (track, queue) => {
		const list = queue ?? get().queue;
		const index = list.findIndex((item) => item.src === track.src && item.world === track.world);
		musicOn();
		set({
			queue: list,
			index: index < 0 ? 0 : index,
			playing: true,
			currentTime: 0,
			collapsed: false
		});
	},
	toggle: () => {
		const { index, queue, playing } = get();
		if (index < 0 && queue[0]) {
			musicOn();
			set({
				index: 0,
				playing: true
			});
			return;
		}
		if (!playing) musicOn();
		set({ playing: !playing });
	},
	pause: () => set({ playing: false }),
	next: () => {
		const { index, queue } = get();
		if (!queue.length) return;
		const next = index < 0 ? 0 : (index + 1) % queue.length;
		musicOn();
		set({
			index: next,
			playing: true,
			currentTime: 0
		});
	},
	prev: () => {
		const { index, queue, currentTime, restart } = get();
		if (!queue.length) return;
		if (currentTime > 3) {
			musicOn();
			set({
				currentTime: 0,
				playing: true,
				restart: restart + 1
			});
			return;
		}
		const prev = index <= 0 ? queue.length - 1 : index - 1;
		musicOn();
		set({
			index: prev,
			playing: true,
			currentTime: 0
		});
	},
	seek: (ratio) => {
		const duration = get().duration || 0;
		set({ currentTime: Math.max(0, Math.min(1, ratio)) * duration });
	},
	setTime: (currentTime, duration) => set({
		currentTime,
		duration
	}),
	setVolume: (volume) => {
		localStorage.setItem("ghostpot-volume", String(volume));
		set({ volume });
	},
	setQueueOpen: (queueOpen) => set({ queueOpen }),
	jump: (index) => {
		musicOn();
		set({
			index,
			playing: true,
			currentTime: 0
		});
	}
}));
function clock(value) {
	if (!Number.isFinite(value) || value < 0) return "0:00";
	const total = Math.floor(value);
	const m = Math.floor(total / 60);
	const s = total % 60;
	return `${m}:${String(s).padStart(2, "0")}`;
}
var tomes = [{
	id: "tom-1",
	title: "Том I. Моя история",
	tracks: narration
}];
function PlayerBar() {
	const audioRef = (0, import_react.useRef)(null);
	const seekLock = (0, import_react.useRef)(false);
	const queue = usePlayer((s) => s.queue);
	const index = usePlayer((s) => s.index);
	const playing = usePlayer((s) => s.playing);
	const restart = usePlayer((s) => s.restart);
	const currentTime = usePlayer((s) => s.currentTime);
	const duration = usePlayer((s) => s.duration);
	const volume = usePlayer((s) => s.volume);
	const collapsed = usePlayer((s) => s.collapsed);
	const setCollapsed = usePlayer((s) => s.setCollapsed);
	const toggle = usePlayer((s) => s.toggle);
	const next = usePlayer((s) => s.next);
	const prev = usePlayer((s) => s.prev);
	const seek = usePlayer((s) => s.seek);
	const setTime = usePlayer((s) => s.setTime);
	const setVolume = usePlayer((s) => s.setVolume);
	const play = usePlayer((s) => s.play);
	const pause = usePlayer((s) => s.pause);
	const bookIndex = useBookAudio((s) => s.index);
	const bookPlaying = useBookAudio((s) => s.playing);
	const bookTime = useBookAudio((s) => s.currentTime);
	const bookDuration = useBookAudio((s) => s.duration);
	const bookVolume = useBookAudio((s) => s.volume);
	const bookQueue = useBookAudio((s) => s.queue);
	const [mode, setMode] = (0, import_react.useState)("music");
	const [listOpen, setListOpen] = (0, import_react.useState)(false);
	const albums = (0, import_react.useMemo)(() => [{
		name: "её песни",
		album: "Люси",
		tracks: lucySongs
	}, ...worlds.map((world) => ({
		name: world.name,
		album: world.album,
		tracks: catalog.filter((track) => track.world === world.name)
	}))].filter((album) => album.tracks.length), []);
	const track = index >= 0 ? queue[index] : void 0;
	const chapter = bookIndex >= 0 ? bookQueue[bookIndex] : void 0;
	const book = mode === "book";
	const bookMode = (0, import_react.useRef)(book);
	bookMode.current = book;
	(0, import_react.useLayoutEffect)(() => {
		const audio = keepAudio("music");
		audioRef.current = audio;
		if (!audio) return;
		const onTime = () => {
			if (seekLock.current || bookMode.current) return;
			setTime(audio.currentTime, audio.duration || 0);
		};
		const onMeta = () => {
			if (bookMode.current) return;
			setTime(audio.currentTime, audio.duration || 0);
		};
		const onEnded = () => {
			if (!bookMode.current) next();
		};
		audio.addEventListener("timeupdate", onTime);
		audio.addEventListener("loadedmetadata", onMeta);
		audio.addEventListener("ended", onEnded);
		return () => {
			audio.removeEventListener("timeupdate", onTime);
			audio.removeEventListener("loadedmetadata", onMeta);
			audio.removeEventListener("ended", onEnded);
		};
	}, [next, setTime]);
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("ghostpot-listen");
		if (saved === "book" || saved === "music") setMode(saved);
		if (localStorage.getItem("ghostpot-player-hidden") === "1") setCollapsed(true);
		const raw = localStorage.getItem("ghostpot-volume");
		if (raw === null) return;
		const savedVolume = Number(raw);
		if (Number.isFinite(savedVolume)) setVolume(savedVolume);
	}, [setCollapsed, setVolume]);
	(0, import_react.useEffect)(() => {
		const onBook = () => pause();
		window.addEventListener("ghostpot-book", onBook);
		return () => window.removeEventListener("ghostpot-book", onBook);
	}, [pause]);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio) return;
		audio.volume = volume;
	}, [volume]);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio || !track) return;
		if (audio.dataset.src !== track.src) {
			audio.dataset.src = track.src;
			audio.src = media(track.src);
		}
		if (playing) audio.play().catch(() => pause());
		else audio.pause();
	}, [
		track,
		playing,
		pause
	]);
	const skipRestart = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		if (skipRestart.current) {
			skipRestart.current = false;
			return;
		}
		const audio = audioRef.current;
		if (!audio) return;
		audio.currentTime = 0;
	}, [restart]);
	const choose = (nextMode) => {
		setMode(nextMode);
		setListOpen(false);
		localStorage.setItem("ghostpot-listen", nextMode);
		if (nextMode === "book") pause();
		else useBookAudio.getState().pause();
	};
	const onPick = (value) => {
		setListOpen(false);
		if (!value) return;
		if (book) {
			const part = narration.find((item) => item.id === value);
			if (part) useBookAudio.getState().play(part);
			return;
		}
		const [albumIndex, trackIndex] = value.split(":").map(Number);
		const album = albums[albumIndex];
		const song = album?.tracks[trackIndex];
		if (album && song) play(song, album.tracks);
	};
	const onToggle = () => {
		if (book) {
			const state = useBookAudio.getState();
			if (state.index < 0) state.play(tomes[0].tracks[0]);
			else state.toggle();
			return;
		}
		if (index < 0 && albums[0]) play(albums[0].tracks[0], albums[0].tracks);
		else toggle();
	};
	const onPrev = () => book ? useBookAudio.getState().prev() : prev();
	const onNext = () => book ? useBookAudio.getState().next() : next();
	const shownTime = book ? bookTime : currentTime;
	const shownDuration = book ? bookDuration : duration;
	const shownVolume = book ? bookVolume : volume;
	const setShownVolume = (value) => book ? useBookAudio.getState().setVolume(value) : setVolume(value);
	const title = book ? chapter ? `${chapter.chapter}. ${chapter.title}` : "Том I. Моя история" : track?.title ?? "Песни миров";
	const who = book ? chapter ? "Озвучка тома" : "Выбери том и главу" : track ? `${track.world} · ${track.note || track.length}` : "Выбери альбом";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: `${collapsed ? "player is-away" : "player"}${book ? " is-book" : ""}`,
		"aria-label": "Плеер",
		children: collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			className: "player-tab",
			type: "button",
			onClick: () => setCollapsed(false),
			children: [book ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 16 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: bookPlaying || playing ? title : book ? "Книга" : "Музыка" })]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "player-main",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `disc ${book ? "is-tome" : ""} ${(book ? bookPlaying : playing) ? "is-on" : ""}`,
					children: book ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { size: 22 }) : track ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: media(track.cover),
						alt: ""
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ph",
						children: "♪"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "player-copy",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "modes",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"data-on": !book,
									onClick: () => choose("music"),
									children: "Музыка"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"data-led": "mode-book",
									"data-on": book,
									onClick: () => choose("book"),
									children: "Книга"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "pick",
									"data-led": "pick",
									type: "button",
									"aria-expanded": listOpen,
									onClick: () => setListOpen((open) => !open),
									children: book ? chapter ? `${chapter.chapter}. ${chapter.title}` : "Том и глава" : track ? `${track.world} · ${track.title}` : "Альбом и песня"
								})
							]
						}),
						listOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "playlist",
							role: "listbox",
							children: book ? tomes.map((tome) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", { children: tome.title }), tome.tracks.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"data-on": part.id === chapter?.id,
								onClick: () => onPick(part.id),
								children: [
									part.chapter,
									". ",
									part.title
								]
							}, part.id))] }, tome.id)) : albums.map((album, albumIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", { children: [
								album.album,
								" · ",
								album.name
							] }), album.tracks.map((song, trackIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"data-on": track?.src === song.src,
								onClick: () => onPick(`${albumIndex}:${trackIndex}`),
								children: song.title
							}, song.src))] }, album.name))
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: title }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "who",
							children: who
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "controls",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "iconbtn",
							type: "button",
							"aria-label": "Назад",
							onClick: onPrev,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipBack, { size: 18 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "iconbtn play",
							type: "button",
							"aria-label": (book ? bookPlaying : playing) ? "Пауза" : "Играть",
							onClick: onToggle,
							children: (book ? bookPlaying : playing) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 18 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "iconbtn",
							type: "button",
							"aria-label": "Дальше",
							onClick: onNext,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { size: 18 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "iconbtn",
							type: "button",
							"data-led": "collapse",
							"aria-label": "Спрятать плеер",
							onClick: () => setCollapsed(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { size: 18 })
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "player-bars",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "seek",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: clock(shownTime) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						suppressHydrationWarning: true,
						"aria-label": book ? "Место в главе" : "Место в песне",
						type: "range",
						min: 0,
						max: 1e3,
						value: shownDuration ? Math.round(shownTime / shownDuration * 1e3) : 0,
						onPointerDown: () => {
							seekLock.current = true;
						},
						onPointerUp: () => {
							seekLock.current = false;
						},
						onChange: (event) => {
							const ratio = Number(event.target.value) / 1e3;
							if (book) {
								useBookAudio.getState().seek(ratio);
								return;
							}
							const audio = audioRef.current;
							seek(ratio);
							if (audio && audio.duration) audio.currentTime = ratio * audio.duration;
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: book ? clock(shownDuration) : track?.length ?? clock(shownDuration) })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "vol seek",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Громкость" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						suppressHydrationWarning: true,
						"aria-label": "Громкость",
						type: "range",
						min: 0,
						max: 100,
						value: Math.round(shownVolume * 100),
						onChange: (event) => setShownVolume(Number(event.target.value) / 100)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: Math.round(shownVolume * 100) })
				]
			})]
		})] })
	});
}
var chapters_default = /*#__PURE__*/ JSON.parse("[{\"id\":\"prolog\",\"numeral\":\"П\",\"title\":\"Пролог\",\"kicker\":\"Пролог\",\"dek\":\"Сначала был холод.\",\"paragraphs\":[\"Сначала был холод.\",\"Не тот, от которого стучат зубы, а другой — каменный, ровный, будто я лежала здесь так долго, что успела стать частью мостовой. Потом пришёл звук: где-то далеко звенела вода, и ветер перебирал что-то лёгкое, похожее на листья. Потом — запах. Пыль, влажный мох, дым. И что-то сладкое, незнакомое, от чего щекотало в носу.\",\"Я открыла глаза.\",\"Небо было слишком высоким. Над ним — или в нём — висели золотые кроны, и свет пробивался сквозь них медовыми пятнами. Я смотрела на эти пятна и ждала, когда в голове появится хоть одна мысль, за которую можно ухватиться. Мысль появилась только одна: меня зовут Люси.\",\"Больше ничего.\",\"Я не помню, как оказалась на этих камнях.\",\"Но тело, кажется, помнило другое: что так уже бывало — холод, чужое небо, первый вдох, — и потому не спешило пугаться. Длинные эльфийские уши сидели на мне, как чужие перчатки, а те, что выше, с кисточками, были моими. Всегда были.\",\"Я села. Слишком резко — мир качнулся, и я упёрлась ладонями в мостовую. Ладони были не мои. Узкие, бледные, с длинными пальцами, чистые — ни шрама, ни мозоли, будто кожу выдали только что. Я смотрела на эти руки так, как смотрят на чужие перчатки, забытые на скамейке.\",\"Потом я услышала собственное дыхание и поняла, что слышу его дважды.\",\"Уши. Их было больше, чем нужно. Длинные, острые, — и выше, на макушке, ещё одни, мягкие, с кисточками, которые дёрнулись сами, без моего разрешения, на шорох где-то справа. Я подняла руку и потрогала их. Тёплые. Живые. Мои.\",\"Я засмеялась. Тихо, хрипло, на полвдоха. Это был не очень хороший смех.\",\"— Ладно, — сказала я вслух. Голос тоже был чужой: мягче, выше, с каким-то певучим краем. — Ладно. Допустим.\",\"Что «допустим», я не знала. Но от слова стало легче. Как будто кто-то внутри меня — тот, кто остался прежним, — поставил ногу на первую ступеньку.\",\"Босые ступни. Простая рубаха, грубая, пахнущая чужим сундуком. Ни сумки, ни оружия, ни имени, кроме своего. Камни вокруг — светлые, гладкие, уложенные так ровно, что их явно делали руки, а не время. Поодаль, за деревьями, кто-то говорил. Я не разбирала слов, но интонация была спокойная, деловая. Так говорят люди, у которых есть место, куда идти.\",\"У меня такого места не было.\",\"Я попробовала вспомнить хоть что-нибудь — дом, лицо, дорогу сюда. Внутри было гладко и пусто, как на этих камнях. Не темнота даже. Просто ничего, обо что можно было бы споткнуться. От этого стало страшнее, чем от ушей.\",\"Я попробовала ещё раз — уже нарочно, как ищут в темноте выключатель на знакомой стене. Вот сейчас. Ещё чуть-чуть. Как я сюда пришла? Откуда? Кто меня привёз, кто положил на камни, кто снял с меня обувь? Мысль тянулась, тянулась — и упиралась в гладкое. Ни двери, ни стены. Как будто кто-то аккуратно вынул из меня всё, что было до этого утра, и даже не оставил шва.\",\"Зато тело знало. Когда я встала, ступни сами нашли ровные камни и обошли выбоину, которую я ещё не успела увидеть. Правая рука потянулась к бедру — за чем-то, что должно было там висеть, — и схватила пустоту. Я долго смотрела на эту руку. Она, кажется, тоже на меня смотрела. Она помнила больше, чем я. И не собиралась рассказывать.\",\"Вот это и было страшнее всего: не то, что я ничего не помню. А то, что кто-то во мне — помнит.\",\"И тут, без всякой причины, пришла вторая мысль. Не из памяти — памяти не было. Откуда-то глубже, ясная и холодная, как вода из колодца: жизнь у меня одна. Не «пока одна». Просто одна.\",\"Я не знала, кто мне это сказал. Я не знала, откуда я это знаю. Но поверила сразу — так, как веришь, что огонь жжётся, ещё ни разу не обжёгшись.\",\"Я встала. Ноги держали. Кисточки на ушах повернулись на голоса, раньше чем я решила, хочу ли туда идти.\",\"Чужое тело. Чужое небо. Чужие голоса за деревьями.\",\"И я — единственное, что здесь, кажется, было моим.\",\"Я пошла на голоса.\"],\"plates\":[{\"after\":11,\"alt\":\"— Ладно, — сказала я вслух. Голос тоже был чужой: мягче, выше, с каким-то певучим краем. —\",\"src\":\"/chronicle/tome/001.jpg\"},{\"after\":22,\"alt\":\"Чужое тело. Чужое небо. Чужие голоса за деревьями.\",\"src\":\"/chronicle/tome/002.jpg\"}]},{\"id\":\"glava-1\",\"numeral\":\"1\",\"title\":\"Глава 1\",\"kicker\":\"Глава 1\",\"dek\":\"Я вышла из-за повозки и сразу пожалела, что не осталась лежать. Камни под босыми ногами были холодные, воздух\",\"paragraphs\":[\"Я вышла из-за повозки и сразу пожалела, что не осталась лежать. Камни под босыми ногами были холодные, воздух слишком чистый, а напротив стояли трое, которые явно уже успели договориться о чём-то без меня.\",\"Сердце колотилось так, будто хотело выйти первым и проверить, безопасно ли. Я обернулась на голоса раньше, чем успела решить, рада ли этой встрече.\",\"Высокий в вышитой одежде обернулся первым.\",\"— Ещё один пилигрим, — сказал он. — Отрадно. Меня зовут Инсуриан. Высокий Совет поручил встречать тех, кто сюда добирается. Добро пожаловать в Нордерон — забытые земли наших предков.\",\"Нордерон. Слово легло в голову легко, будто тело его уже знало, а я — нет. Это было хуже, чем если бы оно оказалось совсем чужим.\",\"— Нордерон, — повторила я. — Забытые земли предков. Красиво звучит. Надеюсь, «забытые» не значит «тут всех забыли и больше не кормят».\",\"— Кормят. Если работаешь. Совет собрал тех, кто ещё называет себя высшими эльфами и не сбежал в первую неделю. Нам нужны люди, которые умеют держать оружие. Или хотя бы не падают в обморок при виде крови.\",\"Парень с ножом, стоявший чуть в стороне, ничего не сказал. Только поднял два пальца — то ли приветствие, то ли счёт. Потом я узнала, что это был счёт укусов.\",\"Инсуриан кивнул в их сторону.\",\"— Эти двое уже здесь. Раф, — он указал на того, что стоял спокойно, опираясь на щит, — и Асценси. Паладин и охотник. Если не станете мешать друг другу — можете ходить вместе.\",\"Асценси даже не поднял глаз. Только качнул флягой: слышу.\",\"Я посмотрела на них обоих. Раф держался ровно, голос спокойный, но в уголках рта уже пряталась усмешка. Асценси переминался с ноги на ногу и явно думал о чём-то, что не имело отношения к Высокому Совету.\",\"— Люси, — сказала я. — И я пока не знаю, что тут обычно трогают в первую очередь. И где тут хотя бы нормальная обувь. Потому что если «по порядку» начинается с того, что я хожу босиком по холодным камням, то Совет может сразу вычесть это из будущих наград.\",\"— Обувь найдётся. А потом — дела. Раф и Асценси покажут, куда идти. Если, конечно, доживёте до обеда и не передумаете друг друга терпеть.\",\"Гостевой зал гавани Эльдранила оказался просторнее, чем я ожидала. Высокие стены, фиолетовые стяги, и в центре — кристалл, который светился мягким, почти тёплым светом. Не агрессивно. Просто… присутствовал.\",\"— Сеанс медитации. Перед кристаллом. Недолго. Просто постой и попробуй не думать ни о чём минут пять. Высокий Совет считает, что это помогает «прийти в себя после долгого странствия».\",\"Я вздохнула, подошла к кристаллу и встала перед ним. Свет был спокойный. Не давил. Просто висел в воздухе, как будто ждал, пока я перестану ёрзать.\",\"Минут пять я простояла. Думала о том, что камни всё ещё холодные, что Раф, судя по всему, из тех, кто будет напоминать про «правильный порядок» даже когда вокруг горят дома, и что Асценси уже на треть глотка фляги. Кристалл не возражал.\",\"Когда я отошла, внутри стало чуть тише. Не спокойно, нет. Просто тише, как в комнате, где наконец выключили сквозняк. Я и не знала, как сильно мне нужна была эта тишина. В первый день, в чужом теле, с одной жизнью, которую никто не объяснил, как беречь.\",\"— Теперь можно и по делу. В зале есть ещё один, кто вас ждёт. Аллинар. Учитель кулинарии. У него… личная просьба.\",\"Аллинар стоял у стола с мисками и чем-то, что пахло сладко и чуть приторно. Высокий, светлые волосы, взгляд чуть рассеянный — как у человека, который уже третий раз за утро забывает, зачем сюда пришёл, и вспоминает только когда видит чужое лицо.\",\"Он заговорил сразу, едва мы подошли.\",\"— Судьба разделила нас с супругой, когда Плеть вторглась в Лордерон. Моя дорогая Келсария оказалась в рядах леди Праудмур и уплыла в Калимдор. А я остался в Транквиллионе, а позже последовал за Высоким Советом в Нордерон.\",\"Аллинар продолжал, и в голосе появилась почти детская радость:\",\"— И вот, спустя столько лет, моя благоверная прибывает в Эльдранил! Я был так счастлив, так взволнован, что напрочь забыл о её любимых пирожных!\",\"— Знаешь, ты бы очень сильно выручила меня, если бы набрала в роще вокруг гавани хоть немного ягод. Уж поверь, в долгу я не останусь.\",\"Асценси покрутил флягу в пальцах и посмотрел в сторону рощи так, будто уже знал, кто там считает ягоды своими.\",\"Я пошла за ними. Камни под ногами всё ещё были холодными. Но хотя бы теперь было понятно, куда идти и зачем. Пока.\",\"Роща вокруг гавани оказалась именно такой, какой её описывал Аллинар: тихой, с белыми стволами, оранжевой листвой и кустами, на которых висели мелкие тёмные ягоды. Серебрика. Название всплыло само, когда я подошла к первому кусту и протянула руку.\",\"Сбор шёл медленно. Ягоды мелкие, цеплялись за ветки, и каждый раз приходилось наклоняться так, чтобы не порвать и без того тонкую одежду. Раф стоял чуть в стороне и следил за склоном. Асценси отошёл дальше — то ли высматривал что-то, то ли просто не хотел собирать.\",\"На третьем кусте из травы выскользнул малый маназмей.\",\"Он был тонкий, полупрозрачный, и двигался быстрее, чем я ожидала. Я отшатнулась, ягоды высыпались обратно в куст. Змей дёрнулся в мою сторону.\",\"Я не стала думать. Просто выставила руку и ударила тем, что уже чувствовала под ладонью — резким, сухим всплеском. «Кара». Свет вспыхнул коротко, почти без звука. Змей дёрнулся, сбился с направления и уполз в траву, оставив после себя только лёгкое магическое послевкусие.\",\"Дальше по роще нам попался молодой солнцелап. Рыжий, низкий, с кисточками на ушах. Он сидел у куста и смотрел на нас так, будто мы уже виноваты в том, что существуем. Когда Асценси сделал шаг ближе, зверь оскалился.\",\"Я снова использовала Кару. На этот раз прицелилась точнее. Вспышка ударила по боку, солнцелап взвизгнул, отскочил и скрылся между деревьями. Не умер. Просто решил, что ягоды того не стоят.\",\"К тому моменту, когда мы набрали нужное количество, руки были в соке, а спина ныла от постоянных наклонов. Раф молча помог собрать последние с нижних веток. Асценси к концу уже просто стоял и смотрел в сторону гавани, изредка прикладываясь к фляге.\",\"Когда мы вернулись, Аллинар встретил нас так, будто мы принесли не ягоды, а его собственную жену.\",\"— Не хочу хвастать, но я довольно неплохой кулинар, — начал он, едва увидев свёрток. — Когда-то у меня была кондитерская в Транквиллионе, причём весьма известная. Её, правда, изрядно потрепало во время Второй войны, а в Третью и вовсе разрушило до основания, так что… О чём это я? Ах, верно. Ты принесла ягоды?\",\"— Подумать только: встретить Келсарию с пустыми руками! Ты спасла меня от страшного позора, Люси!\",\"Он быстро отсчитал монеты — семьдесят пять медяков — и положил сверху небольшой свёрток.\",\"— Вот твоя награда за труды. И, прошу, возьми немного моей выпечки. Надеюсь, сладкое тебе по вкусу.\",\"Пять пирогов с серебрикой. Ещё тёплые. Пахли так, что даже Асценси на секунду перестал делать вид, что ему всё равно.\",\"Мы вышли из зала. Ягоды собраны. Пироги есть. Кара работает. А что ещё я умею — пока не ясно. Но хотя бы теперь было на чём сидеть и думать, пока не появится следующее «по порядку».\",\"Аллинар ещё стоял над ягодами, когда я положила на стол медяк — плату за первый урок кулинарии. Руки начали раньше меня: едва я увидела муку, я уже тёрла ладони друг о друга. Аллинар поднял голову, взял мою ладонь, повернул к свету и сказал: «Тесто не любит холодных рук. Грей их, прежде чем браться». Мои уже были тёплые. Откуда они знали это раньше него, я не знала. Урок вышел короче некуда — и почему-то запомнился. Рецепт хлеба с пряностями за десять медяков я отложила на потом.\",\"Инсуриан ждал нас у той же повозки. На этот раз он не стал начинать с приветствий.\",\"— Теперь, когда ты набралась сил, я бы хотел попросить тебя об услуге.\",\"— Видишь ли, маназмеи, которых разводят в гавани, последнее время совсем отбились от рук. А некоторые из них стали проявлять несвойственную этим созданиям агрессию. Конечно, они не могут нанести эльфам серьёзного вреда, но это не значит, что стоит закрывать глаза на эту проблему.\",\"— Я полагаю, что причиной возбуждённого состояния маназмеев стала избыточная магическая энергия, которую они каким-то образом поглотили, — продолжил Инсуриан. — Установил чародейские ловушки, чтобы вывести излишнюю магию из их тел. Если я прав, это должно успокоить наших маленьких питомцев.\",\"Он протянул мне небольшой предмет — магический сердечник. Тёплый на ощупь, с лёгким гулом внутри.\",\"— С помощью этого. Ловушки уже стоят. Тебе нужно только подойти к ним и использовать сердечник, когда змеи будут рядом. Не убивать. Успокаивать.\",\"Я спрятала сердечник в сумку. Внутри что-то улеглось, тёплое и тяжёлое: усталость, которая учит. Руки стали чуть увереннее, Эльдранил чуть ближе. Вечером я записала в журнал пару строк, не вчитываясь в собственный почерк. Пока это были просто строчки.\",\"Ловушки стояли там, где сказал Инсуриан — у низких каменных бортиков, рядом с водой, которая светилась изнутри мягким голубым. Маназмеи кружили рядом, дёрганые, полупрозрачные. Один уже шипел на куст, хотя куст ничего ему не сделал.\",\"Я достала сердечник. Он лёг в ладонь теплом и лёгким гулом. Подошла ближе, дождалась, пока змей окажется почти над ловушкой, и активировала.\",\"Свет дёрнулся из сердечника в землю. Змей замер, изогнулся, потом медленно осел, словно из него вынули лишнюю пружину. Через несколько секунд он уже просто лежал, вялый и почти мирный.\",\"Четвёртый змей дёрнулся в сторону, когда я подошла. Пришлось шагнуть быстрее и ударить Карой в землю перед ним — не чтобы убить, а чтобы отпугнуть обратно к ловушке. Сработало. Пятый даже не сопротивлялся. Просто повис в воздухе, пока энергия уходила, и потом уполз в воду, уже спокойный.\",\"Когда мы вернулись, Инсуриан встретил нас без лишних слов.\",\"— Похоже, моя догадка была верна, — сказал он. — Лишившись избыточной энергии, маназмеи вернулись в норму. А что насчёт тебя, Люси, ты не пострадала?\",\"Он кивнул и разложил на столе три вещи на выбор: волоконный жилет заступника, мундир странника, жилет исследователя. Я посмотрела на них секунду. Ни один не выглядел так, будто спасёт от чего-то серьёзного, но все были лучше, чем то, в чём я ходила сейчас.\",\"Я взяла жилет исследователя. Просто потому, что он меньше всего обещал «защиту» и больше всего — карманы.\",\"Инсуриан даже не прокомментировал выбор. Только вложил мне в руку монету и задержал взгляд на моём лице, будто проверял, много ли во мне осталось от вчерашней босой пилигримки. Видимо, немного. Мне и самой так казалось.\",\"Он не дал нам уйти далеко.\",\"— Тебе, конечно, известно, что после изгнания из Калимдора наши предки, Высокорожденные, нашли приют в Лордероне. Многие поселения, построенные ими в те времена, были покинуты и забыты после основания Кель'Таласа, а позднее разрушены в ходе Войн Троллей и последующего возвышения империи Аратора.\",\"— Но наследие той эпохи до сей поры живо здесь, в древних землях Нордерона. За последние несколько лет нам удалось достичь значительных успехов в исследовании и восстановлении этого края, и сейчас перед тобой плоды наших трудов — твердыня Эльдранил.\",\"— Тебе наверняка не терпится увидеть его своими глазами. Позволь отметить на карте города несколько мест, которые могут тебе пригодиться в будущем. Не торопись и осмотри всё хорошенько, а когда закончишь, найди Сенешаля Тас'талира. Уверен, он найдёт применение твоим способностям.\",\"Он отметил на карте четыре места: торговые ряды Эльдранила, академию, Серебряную террасу и площадь Зенита. А потом — сенешаль.\",\"Мы пошли в сторону города. В сумке лежал новый жилет и сердечник, который больше не был нужен. В голове — четыре точки на карте и имя человека, который, по словам Инсуриана, найдёт мне применение. Пока это звучало одновременно как обещание и как предупреждение.\",\"Инсуриан остановил нас ещё до того, как мы успели толком отойти от повозки.\",\"— Из-за упадка системы силовых каналов обитатели этих лесов на протяжении поколений подвергались воздействию необузданной магической энергии, — начал он без предисловий. — Для них тайная магия — такая же естественная часть жизни, как и для нас. Взять, к примеру, местных лис, которые получили возможность усваивать магию, что вынудило их охотиться на менее крупных порождений магии — например, маназмеев.\",\"— Увы, из-за чародейского всплеска магические хищники повадились нападать на эльфов, и в гавани стало небезопасно. Уменьши численность этих созданий, пока они не причинили больше вреда.\",\"Он поставил на карте угольный крестик. Шесть молодых солнцелапов — столько, по его словам, хватит, чтобы остальные поняли.\",\"У Теларна я за десять медяков выучилась снимать шкуры — «если собираешься убивать, имей смысл с этого что-то получить», сказал он, — а у Гелварила купила нож. Не замена посоху. Просто инструмент.\",\"Торговые ряды, Серебряная терраса, площадь Зенита, Академия — город я обошла за час и запомнила из него немного: Раф останавливался у каждой второй вывески, Асценси — ни у одной, а на террасе кто-то читал на скамье и ни разу не посмотрел на нас. Я постояла рядом минуту. Оказывается, по этому тоже можно скучать — по тому, что на тебя не смотрят как на ещё одного пилигрима, которого надо куда-то отправить.\",\"Салдор стоял у ограды и смотрел на город так, будто ещё не решил, нравится ему здесь или нет. Когда мы подошли, он заговорил первым — не как человек, который ищет помощь, а как тот, кому просто нужно кому-то рассказать.\",\"— После падения Кель'Таласа наша скромная обитель в Высокодолье предоставила приют немалому числу беженцев, — сказал он. — Но мало кто из них решил осесть во Внутренних Землях. Оно и понятно: жизнь в Кель'Даниле сурова и не каждому придётся по нраву.\",\"— Со многими из тех эльфов я успел сблизиться, но больше всего привязался к паре сироток из деревни Золотистой Дымки. Селендис и Веларис. Эти двое ни минуты не могли усидеть на месте и доставили следопытам немало хлопот своими выходками.\",\"— Да, весёлое было время. До меня дошли слухи, что сейчас детишки живут в Эльдраниле. И поскольку мне выпала честь представлять следопытов Высокодолья перед Высоким Советом, я бы хотел навестить близнецов. Но аудиенция состоится гораздо позже, чем я рассчитывал, и времени у меня… есть.\",\"Мы нашли их недалеко от площади. Селендис стояла у фонтана и смотрела на воду. Веларис сидел на бортике и качал ногой. Когда я подошла, девочка подняла голову.\",\"Я смотрела на них и думала о том, как страшно, когда тебя некому искать. И как, оказывается, тепло, когда кто-то через полмира помнит, как ты не мог усидеть на месте.\",\"— Я почти не помню Луносвет, — сказала она. — Но мне кажется, что этот город похож на него.\",\"Потом она заметила то, что я достала из сумки — просто чтобы проверить, не вывалилось ли что-то по дороге. Лилия. Маленькая, уже чуть подсохшая.\",\"Селендис замерла.\",\"— Что это такое? Ой… Лилия. Я помню такую… Веларис, иди сюда!\",\"Мальчик подошёл. Они пошептались. Потом Селендис посмотрела на меня уже иначе — оценивающе.\",\"— Неужели дядя Салдор здесь, так далеко от дома? А почему он сам не пришёл к нам?\",\"— Ты же вроде посыльного, да? Бегаешь туда-сюда по поручениям взрослых, а они тебе что-то за это дают. Давай ты проводишь нас к дяде Салдору, а мы с братом поделимся с тобой сладостями. Что скажешь?\",\"Они и правда шли тихо. Почти. Веларис один раз попытался залезть на ограду, но Раф просто посмотрел на него, и мальчик слез сам. Когда мы дошли до Салдора, Селендис первая его увидела.\",\"— Гляди, Веларис, а вот и дядя Салдор!\",\"— Спасибо тебе, Люси! Дальше мы сами. Вот, держи. Только не ешь их перед трапезой, а иначе аппетит пропадёт. Пока-пока!\",\"Пять конфет. Фирменные, эльдранильские. Салдор уже обнимал их обоих и что-то говорил тихим голосом. Мы отошли.\",\"Звёздная Чешуя нашлась не в роще и не у гавани. Она лежала среди острых золотых кристаллов, полупрозрачная, с чешуёй, которая переливалась даже в тени. Когда мы подошли, она подняла голову. Не агрессивно. Просто посмотрела. Под её брюхом, между кристаллами, лежали три гладких яйца, тёплые на вид, с тем же переливом, что у неё на спине. Она подвинулась так, чтобы закрыть их собой, и только потом бросилась.\",\"Асценси выстрелил первым. Стрела ушла в бок, Чешуя дёрнулась и выдохнула чем-то фиолетовым. Раф шагнул вперёд, закрывая нас щитом. Я осталась чуть сзади и ударила Карой — коротко, в голову. Свет вспыхнул, Чешуя взвизгнула и развернулась ко мне.\",\"Я не стояла. Отступила за камень, дождалась, пока она снова повернётся к нему, и ударила ещё раз. Асценси бил в упор, почти не целясь. Чешуя металась между нами, била хвостом, один раз задела Рафа по ноге. Он только стиснул зубы и продолжил.\",\"Когда она наконец рухнула, чешуя ещё несколько секунд переливалась. Потом погасла. Яиц я не тронула; Раф тоже на них не смотрел, слишком старательно. Я присела и отрезала хвост — радужный, ещё тёплый. В сумке он занял больше места, чем я ожидала.\",\"Сенешаль Тас'талир ждал в Чертоге. Высокий, спокойный, с лицом человека, который уже слышал слишком много докладов за сегодня. Когда я положила хвост на стол, он посмотрел на него, потом на меня.\",\"— Значит, кому-то наконец удалось одолеть Звёздную Чешую. Определённо, роща Вечной Весны станет безопаснее без него, но я всё равно скорблю о гибели столь удивительного создания.\",\"На столе лежали четыре вещи. Меч наёмного воина. Утренняя звезда. Зазубренный кинжал. И посох бойца — двуручный, с небольшим бонусом к интеллекту. Я посмотрела на посох. Потом на свои руки. Кара всё ещё была единственным, чем я умела бить на расстоянии. Посох хотя бы не будет мешать, если придётся подойти ближе.\",\"Я взяла его.\",\"Мы вышли из Чертога. Новый посох был тяжелее старого — ненамного, но так, что руки сразу почувствовали разницу. Раф шёл рядом и молчал. Асценси уже достал флягу.\",\"Шахта Серебряной Пыли встретила нас фиолетовым светом и запахом сырой земли. Кристаллы торчали из стен и пола, большие, острые, и гудели так тихо, что это было слышно только если остановиться. Под ногами — доски, ящики, следы чьих-то сапог. И люди. Несколько эльфов стояли у дальней стены и говорили вполголоса, не обращая на нас внимания.\",\"Штейгер Файрен обернулся, едва мы вошли. Лицо усталое, руки в пыли.\",\"— Оглядись: у нас тут настоящая беда.\",\"— Кристаллы всегда были здесь. Мы их добывали. Аккуратно. А теперь они… реагируют. На всё. На шаги, на голоса, на то, что кто-то просто стоит слишком близко. Двое уже получили по рукам. Не смертельно. Пока.\",\"— Пока — просто быть здесь, — ответил Файрен. — Тас'талир сказал, что пришлёт кого-то, кто умеет работать с магией, а не только с киркой. Если кристаллы снова начнут вести себя странно — остановите. Или хотя бы не дайте никому подойти слишком близко, пока мы не поймём, что происходит.\",\"Он протянул мне небольшой мешочек. Двадцать пять медяков. Опыт лёг следом, короткой строкой.\",\"Файрен не дал нам постоять у стены больше минуты. Он отошёл к ящику, достал что-то из-под тряпки и заговорил уже другим тоном — не «посмотрите, какая беда», а «вот что с этим делать».\",\"— В глубине шахты установлен чародейский кристалл, — сказал он. — Реликт древности, найденный рабочими вскоре после того, как мы открыли шахту. Его энергия призвана пробуждать духов земли, чьи каменные тела полны богатой породой. С помощью таких кристаллов наши предки, надо полагать, и построили добрую половину поселений в Нордероне.\",\"— Но сейчас кристалл вышел из-под контроля. Его сила будоражит духов земли и принуждает нападать на рабочих. Жрица, если ты не робкого десятка, помоги нам сдержать ярость элементалей, пока от Серебряной Пыли не осталось одно название.\",\"Семь оживших камнегневов. Пять осколочных ползунов. Я посмотрела на посох в руках.\",\"— Тогда бей быстрее, — ответил Файрен. — И вот ещё. Я заметил, что тела этих элементалей достаточно прочны. Должно быть, они сотворены из невероятно богатой породы. Тебе ведь наверняка придётся столкнуться с ними в шахтах. Так почему бы нам не обратить это на пользу общему делу?\",\"Он протянул мне кирку. Зачарованную. Рукоять тёплая.\",\"— Принеси мне каменные ядра поверженных элементалей, а я посмотрю, есть ли в них что-нибудь ценное. Шесть штук. Киркой. Не руками.\",\"— Восставшие элементали не отличаются умом или скоростью, однако подвластные им силы делают их крайне опасными. Мои эльфы отважны, но что они могут поделать, когда сама земля разверзается у них под ногами? И это ещё полбеды: некоторые шахтёры оказались в каменных ловушках, удерживающих их подобно лапам чудовища. Если они ещё живы, прошу, найди и освободи их.\",\"Пять геологов. Где-то в глубине.\",\"Я взяла кирку. Посох остался в другой руке. Получалось неудобно, но отпускать ни то, ни другое не хотелось.\",\"Камнегнев поднимался из пола так, будто земля просто решила, что ей надоело лежать спокойно. Камень трещал, складывался в грубую фигуру с руками слишком длинными для нормального тела, и сразу шёл на нас — небыстро, но так тяжело, что каждый шаг оставлял вмятину.\",\"Раф встретил первого щитом. Удар прошёл вскользь, камнегнев качнулся, и я ударила Карой в то место, где у него должна была быть голова. Свет вспыхнул, камень треснул. Асценси бил в стыки — туда, где плиты ещё не успели срастись. Второй рухнул быстрее. Третий успел задеть Рафа по плечу, прежде чем мы его развалили.\",\"Ползуны оказались меньше, но злее. Они выскакивали из трещин уже готовыми кусками и сразу кидались в ноги. Одного я отпугнула посохом: махнула им так грозно, как умела, и ползун, к моему удивлению, поверил. Посох у меня для красоты и для страха, а не для драки, но ползунам об этом знать не обязательно. Второй вцепился в сапог Асценси, и тот матерился так тихо и ровно, что это звучало почти вежливо.\",\"Геолога мы нашли между ящиками. Он сидел, прижатый каменной плитой к стене, и дышал часто, но ещё дышал. Раф поддел плиту плечом. Я помогла посохом. Камень поддался с хрустом. Геолог выбрался, кивнул и сразу пополз к выходу, не оглядываясь.\",\"Когда камнегневов стало шесть, я достала кирку. Зачарованная рукоять легла в ладонь неловко — я никогда раньше ей не работала, и первый удар пришёлся вкось. Подошла к ближайшему разваленному телу, примерилась и ударила в центр грудины. Камень поддался легче, чем я ожидала. Ядро вышло тёплым, тяжёлым, с прожилками, которые ещё слабо светились.\",\"Я выбила второе ядро. Потом третье. Руки болели уже не от Кары, а от обычной работы киркой. В глубине шахты снова что-то треснуло — громче, чем раньше. Кристаллы на стенах отозвались коротким гулом.\",\"Мы пошли дальше. Семь камнегневов. Пять ползунов. Пять человек, которых ещё нужно было вытащить из-под камня. И где-то впереди — тот самый кристалл, который всё это начал. Пока он молчал. Но я уже понимала, что молчание здесь ничего хорошего не значит.\",\"Файрен встретил нас у выхода из шахты. Пыль на его одежде была свежая, а взгляд — уже не такой усталый, как утром.\",\"— Не каждый день приходится сталкиваться со злобными ожившими булыжниками, — сказал он, принимая от меня последний отчёт. — Хорошо, что рядом оказалась такая Жрица, как ты, Люси.\",\"Семьдесят пять медяков. Опыт. И мантия геодезиста — лёгкая, с карманами, которые хотя бы не выглядели так, будто их шили для кого-то, кто никогда не наклоняется. Я накинула её поверх того, что было. Стало чуть теплее.\",\"Я выложила шесть ядер. Они стукнули о стол тяжело и глухо. Файрен взял одно, повертел, кивнул.\",\"— Неплохо сработано, Люси. Теперь я понимаю, почему сенешаль прислал сюда именно тебя — хотя, не буду лукавить, было бы недурно иметь поддержку отряда боевых магов.\",\"Награда лежала на столе: истоптанные брюки, брюки копателя и набедренники боевого горна. Я посмотрела на них. Все три выглядели так, будто уже побывали в шахте без меня. Взяла брюки копателя. Просто потому, что в них хотя бы можно было нормально нагнуться.\",\"Серебряная монета легла сверху. Он положил её сам, прижав пальцем, как печать. А внутри, следом, разлилось знакомое тепло: ещё немного опыта, ещё немного меня.\",\"И ещё одно.\",\"Вечером, уже в Эльдраниле, наставница в храме отвела меня в сторону. Она не стала ничего объяснять словами. Взяла мою руку, положила себе на запястье и тихо сказала: «Чувствуешь, где болит? Свет лечит это место. А теперь — сделай наоборот. Не выпускай боль, а веди её. Медленно. Не отпуская». Я попробовала и отдёрнула руку: у неё на коже на мгновение проступила тень. Она даже не поморщилась. «Слово Тьмы: Боль, — сказала она. — Не бойся его. Бойся только того, что оно тебе понравится». Новое знание легло рядом с Карой — темнее, тягучее. Я не стала пробовать сразу. Просто постояла, чувствуя, как оно устраивается. Не вспышка. Скорее медленный укол, который можно направить и не отпускать.\",\"Файрен уже отвернулся к ядрам. Для него разговор закончился. Мы вышли наружу. Воздух был холоднее, чем в шахте, и пах нормальной землёй, а не пылью и магией. Мантия сидела нормально. Новые брюки — тоже. А в голове, рядом с Карой, теперь лежало ещё одно слово. Пока тихое. Но я уже понимала, что в следующий раз, когда что-то каменное полезет из пола, я попробую и его.\",\"Файрен не дал нам отойти от шахты больше чем на десять шагов.\",\"— Тебе нужно проникнуть вглубь шахты, найти чародейский кристалл и отключить его прежде, чем пробудятся новые элементали. Но будь осторожна: мы и понятия не имеем, что может ожидать тебя у самого источника этих бедствий.\",\"— Что это за гул? Будто бы кто-то вгрызается в металл.\",\"Он замолчал. Кровь отлила от лица так быстро, что это было видно даже в сумерках.\",\"— Колодца ради… Эти твари принялись за опоры шахты! Если их не остановить, туннели обвалятся, и мы потеряем доступ к местным залежам.\",\"Он посмотрел на меня уже иначе — не как на жрицу, которую прислали помочь, а как на единственного, кто ещё не отказался лезть внутрь.\",\"— Я бы не стал просить об этом эльфа со стороны, но ты уже доказала, что своим оружием владеешь лучше, чем кто-либо из нас. Останови этих созданий, пока не поздно.\",\"Четыре исступленных червенита. Где-то у опор.\",\"Я посмотрела на посох. Потом на руки. Кара всё ещё была там. И рядом с ней — новое, тёмное, которое я пока не пробовала. «Слово Тьмы: Боль». Название не нравилось. Но если черви грызут дерево и камень, возможно, им тоже не понравится.\",\"Червенит вылез из трещины уже на полпути вглубь. Толстый, сегментированный, с жвалами, которые скрежетали по камню так, будто пробовали его на вкус. Он не рычал. Просто полз — быстро, прямо на опору.\",\"Раф перехватил его щитом. Я ударила Карой в голову. Свет вспыхнул, червенит дёрнулся, но не остановился. Тогда я попробовала новое. «Слово Тьмы: Боль» легло не вспышкой, а тянущим уколом. Червенит замедлился. Асценси всадил стрелу в стык между сегментами. Второй удар Карой добил.\",\"Дальше оказался великан.\",\"Он стоял у самого кристалла — высокий, каменный, с прожилками, которые светились радугой. Когда мы подошли, он повернул голову. На его плече, в каменной трещине, торчала старая кирка с истёртой до блеска рукоятью — кто-то когда-то пытался его разбудить или остановить, и не успел уйти. Великан провёл пальцами по ручке, как по шраму, и шагнул к нам. Воздух вокруг него дрожал. Радуга ударила в стороны широким лучом, и на секунду всё стало слишком ярким и слишком далёким одновременно.\",\"— Ты слишком далеко! — крикнул Раф.\",\"Я не стала спорить. Подбежала ближе, пока луч не вернулся, и ударила Карой в ногу. Потом — Словом. Боль легла на камень медленно, но легла. Великан взревел. Асценси стрелял почти в упор. Раф держал его внимание на себе, принимая удары, от которых щит гудел.\",\"Кристалл за спиной великана пульсировал всё чаще. Я дождалась, пока великан замахнётся на Рафа, проскочила мимо и положила ладонь на основание. Оно было горячим. И гудело так, что зубы сводило. Я не знала, как его отключать. Просто держала и давила Карой внутрь, пока гул не начал стихать.\",\"Великан рухнул, когда кристалл наконец замолчал. Падая, он посмотрел не на нас, а на кристалл — так смотрят на того, кто перестал звать. Радуга погасла. В шахте стало темно и тихо — почти нормально.\",\"Только тогда я заметила, что ладонь у меня обожжена до волдырей. Боль пришла с опозданием, как всегда приходит настоящая: сначала ты делаешь, потом понимаешь, чем заплатила. Я прижала руку к груди и прочла над ней тихую молитву. Помогло наполовину. Вторую половину я решила оставить себе — на память о том, что я живая.\",\"Мы вышли на свет уже без бега. Просто шли. Снаружи пахло осенними листьями и нормальной землёй.\",\"Файрен ждал у входа. Когда увидел нас, выдохнул так, будто сам сидел внутри.\",\"— Это замечательные новости, Люси. Когда кристалл будет отключён, мы немедленно примемся за восстановление опорных балок, которые были повреждены этими проклятыми сталегрызами. Уверен, мои эльфы будут в восторге, когда узнают, сколько работы нам предстоит…\",\"Он вынес из шахтёрской будки три вещи и разложил на ящике. Наручи из каменной ткани. Выкопанные поручи. Искрящиеся наручи. Я взяла наручи из каменной ткани. Они хотя бы не обещали искрить в самый неподходящий момент.\",\"Потом — про кристалл.\",\"— Каменный великан? Я не ослышался? А мне уж было подумалось, что этот кристалл уже ничем не сможет нас удивить. Как бы то ни было, я рад, что тебе удалось выбраться живой, Люси.\",\"И снова, из той же будки, ещё три вещи. Магическая мешковина угольщика. Головная повязка горняка. Самодельная шахтёрская каска. Я посмотрела на каску. Потом на свои волосы. Взяла повязку. Меньше всего шансов, что она свалится в самый неподходящий момент.\",\"Серебро он отсчитал сам, дважды, сбиваясь, потому что руки у него дрожали от облегчения. Я вычеркнула в журнале оба дела и долго держала карандаш над страницей, не зная, что ещё написать. Написала: «Вышли. Все».\",\"Через день, говорили потом, шахтёры вернулись в забой. Не все — двое так и не смогли заставить себя спуститься, и Файрен их не торопил. Но остальные спустились. Один из геологов, тот, которого мы вытащили из-под плиты, встретил меня у входа и молча сунул в руку кусок кварца — просто так, ни за что. Я до сих пор не знаю, что с ним делать. Ношу.\",\"Сенешаль Тас'талир слушал, не перебивая. Когда я закончила — про кристалл, про великана, про червенитов и про то, что шахта пока стоит, — он только кивнул.\",\"— Вести и впрямь безрадостные, Люси, — сказал он. — Придётся отложить на неопределённый срок работы по расширению анклава Странников и восстановлению троп к югу от Элессара. Однако благодаря твоему вмешательству нам удалось избежать гибели геологов и обрушения шахты.\",\"Я не стала поправлять. Просто приняла двадцать пять медяков и шахтёрскую сумку. Она была проще той, что лежала у меня раньше, но хотя бы не пахла чужими пирогами и ягодами.\",\"Ладонь к тому времени уже зажила. Не затянулась корочкой, не порозовела — просто стала такой, будто никакого кристалла не было. Я долго разглядывала её на свету и почему-то обиделась: ту половину боли я ведь собиралась оставить себе.\",\"Остатки шахты — осколки, пару ядер и что-то светящееся, подобранное просто потому, что лежало под ногами, — я сдала Тельналоку. Он не торговался. Двадцать один медяк и двадцать за то, что чуть не похоронило нас под землёй.\",\"Хранительница энергии Вейде стояла у дерева и смотрела не на нас, а на что-то дальше по склону. Когда мы подошли, она обернулась сразу — будто ждала именно жрицу, а не просто ещё троих, которые решили прогуляться.\",\"— Высвобожденная энергия силовых линий повредила сердечники волшебных големов, стерегущих Ан'телар, — сказала она без предисловий. — В результате чего станция оказалась практически беззащитной перед буйством магических духов.\",\"— Чтобы вернуть стражей в строй, тебе понадобится заменить неисправные сердечники, — продолжила Вейде. — Имей в виду, что оставшейся в них магической энергии может быть достаточно, чтобы нанести существенный вред, так что будь начеку, Жрица.\",\"Четыре сердечника. Где-то на станции, которая уже почти без защиты.\",\"Волшебный страж стоял на платформе и светился так, будто уже решил, что мы — часть поломки. Высокий, из голубого камня и света, с руками, которые двигались медленнее, чем должны были, но всё равно достаточно быстро, чтобы не хотелось проверять, дотянется ли он.\",\"Раф принял первый удар на щит. Звон прошёл по площадке. Я ударила Карой в грудь — туда, где должен был быть сердечник. Свет вспыхнул, страж качнулся. Асценси стрелял в стыки. Второй страж уже поворачивался к нам, когда первый наконец замер.\",\"Я подошла ближе. Сердечник сидел глубоко; старый, когда я его вытащила, был тёплым и гудел так, что свело пальцы. Я вставила новый — страж дрогнул, свет внутри выровнялся, и он просто остался стоять: уже не агрессивный, просто страж.\",\"— Один, — сказала я. — Ещё три.\",\"И тут щёлкнуло.\",\"Не в воздухе. В груди. Коротко, чётко, без фанфар, будто кто-то подтянул во мне все струны разом. Пятый уровень.\",\"— Уровень, — сказала я. — Пятый. Я это чувствую, как чувствуют, что выспались.\",\"Нестабильный дух висел в арке и дёргался так, будто сам не понимал, зачем здесь находится. Маленький, яркий, и совершенно не желающий стоять на месте. Я попробовала Кару. Не взяло. Слово Тьмы тоже соскользнуло, будто в нём не было ничего, что умеет болеть. Пришлось оставить его Рафу и Асценси. Я накинула на Рафа щит, подлечила Асценси, которого дух успел лизнуть искрой, и комментировала из-за их спин, пока он не рассыпался. Комментарии, к сожалению, его тоже не брали.\",\"Восьмой исчез так же быстро, как и появился. В зале стало тише. Големы, у которых мы уже успели сменить сердечники, стояли на своих местах и больше не поворачивали головы в нашу сторону.\",\"Вейде ждала снаружи. За стражей — роскошные наручи и семьдесят пять медяков, отсчитанные в ладонь, как солдатам жалованье. За духов — призрачное оперение. И сразу, без паузы:\",\"— Ты дала нам небольшую передышку, однако мы не можем расслабляться, пока не устраним причину всех бедствий.\",\"Первая печать активировалась без лишнего шума. Просто вспыхнула, гул внутри неё выровнялся, и всё. Я отошла на шаг и посмотрела на следующую.\",\"Вторая печать лежала чуть дальше, у колонны. Я подошла, положила ладонь и активировала. Снова гул, снова выравнивание. Никакой пыли. Пока.\",\"Аномалия появилась, когда я уже шла к третьей. Яркая, рваная, без формы — просто сгусток силы, который решил, что ему тут тесно. Раф шагнул вперёд. Асценси выстрелил. Я ударила Карой, потом Словом. Боль легла на него странно — не как на камень и не как на плоть. Скорее как на что-то, что само состояло из боли и не очень понимало, куда её девать.\",\"Пока они держали аномалию, я добралась до третьей печати. Активировала. Гул прошёл по залу, и аномалия дёрнулась сильнее. Кольцо — перстень-печатка шпиля Рассвета — лежало у основания. Я подобрала его, не глядя, и сразу отступила.\",\"Аномалия рассыпалась, когда третья печать встала на место. Не красиво. Просто перестала быть.\",\"Вейде взяла перстень и долго смотрела на символы. Молчала. Потом кивнула — медленно, будто подтверждала что-то, что ей не очень нравилось.\",\"— Отличная работа, Люси. Теперь мы можем отправить в залы станции рабочих, чтобы всё починить. Высокий Совет будет доволен нашими успехами.\",\"Из того, что она предложила, я взяла жезл Хранителя энергии — он светился спокойнее, чем всё, что я видела за последний час.\",\"— А теперь позволь мне взглянуть на перстень, о котором ты говорила. Как странно… Эти символы мне знакомы.\",\"— Кольцо, что ты нашла, принадлежало волшебнику из шпиля Рассвета — магической академии на западе от Эльдранила. Но маги шпиля занимаются теоретическими исследованиями и не имеют отношения к обслуживанию силовых станций. Твоя находка наводит на безрадостные размышления…\",\"— Вот что, — продолжила Вейде. — Мне и моим людям предстоит здесь ещё много работы. Ты же отправляйся в Эльдранил, предстань перед Высоким Советом и расскажешь обо всём, что здесь случилось. Я могу рассчитывать на тебя, Люси?\",\"Мы вышли. Жезл лёг в сумку рядом с посохом. Город был где-то впереди, и в нём — Высокий Совет, которому предстояло услышать, что на их силовой станции кто-то оставил кольцо мага, который, по идее, не должен был там находиться вообще.\",\"По дороге через рощу Кара свалила медношкурого охотника и дикого дракондора, а нож — с переменным успехом — снял с них обрывки шкур. На дракондоре он соскользнул по перьям, и я порезала палец. Залечила сама. Даже не остановилась.\",\"Илнурия Ар'нарет стояла в зале и говорила так, будто уже произносила эти слова много раз. Спокойно. Без лишней горечи, но и без попытки её спрятать.\",\"— До уничтожения Солнечного Колодца мы наивно считали, что наша цивилизация достигла высшей точки своего развития, — сказала она. — За это заблуждение наш народ заплатил непомерную цену и теперь стоит на краю забвения.\",\"Когда я протянула перстень, Илнурия взяла его и долго смотрела на символы. Потом кивнула.\",\"— Ах, это ты — посланница… выяснили хранители энергии.\",\"Награда лежала на столе. Кольцо легионера. И кольцо хранителя мудрости — простое, с небольшим бонусом к интеллекту. Я взяла второе. Не потому, что чувствовала себя особенно мудрой. Просто интеллект хотя бы не обещал, что я внезапно стану лучше бить посохом.\",\"Пятьдесят медяков. Опыт. И сразу следующее.\",\"— Не буду лукавить: данная ситуация выглядит весьма странно, — сказала Илнурия. — Мне сложно поверить, что кто-то из шпиля Рассвета стал бы саботировать работу силовой станции. Эта академия была основана лордом-чародеем Антарисом — могущественным магом и ярым сторонником дела Высокого Совета. Каждый маг в стенах шпиля Рассвета трудится на благо Эльдранила и всех высших эльфов.\",\"— Тем не менее я не могу закрыть глаза на факты. Уверяю, Высокий Совет приложит все усилия, чтобы разобраться в этом инциденте и привлечь виновных к ответу. Что же касается тебя…\",\"Голос у неё не изменился. Но я уже поняла, что «что же касается тебя» обычно заканчивается ещё одним делом, которое нужно сделать до того, как кто-то другой решит, что жрица уже достаточно узнала.\",\"Я посмотрела на новое кольцо на пальце. Оно сидело нормально. И почти не напоминало о том, что где-то в шпиле Рассвета кто-то, возможно, решил, что силовая станция — подходящее место для того, чтобы оставить после себя улику.\",\"Шпиль Рассвета встретил нас мостом и тишиной, которая уже не выглядела нормальной. Колонны, осенние деревья, и ни одного мага, который бы стоял и делал вид, что всё под контролем. Только ветер и далёкий гул, который я уже начинала узнавать.\",\"Таэдрис ждал у входа. Высокий, в тёмном, с лицом человека, который уже устал объяснять, почему здесь не стоит задерживаться.\",\"— Так это тебя упоминала верховная чародейка? — сказал он, оглядев меня с ног до головы. — Посмотрим, на что ты сгодишься.\",\"— Шпиль сейчас заполонён магическими тварями. Я не могу связаться ни с лордом-чародеем, ни с его учениками. Не знаю, что здесь произошло, но разбираться придётся нам с тобой.\",\"— Для начала нужно отключить источники энергии, питающие замок, — продолжил Таэдрис. — Их три, и они находятся в разных местах. У меня нет обезвреживающего самоцвета, поэтому придётся сделать иначе. Возьми этот кристалл и заряди его энергией тех существ, что сейчас в замке, а затем с его помощью перегрузи защитные механизмы.\",\"Он протянул кристалл. Тёплый, с тихим голодным гулом внутри.\",\"Мы отошли на пару шагов, и тут щёлкнуло — шестой уровень, коротко, без фанфар. Вместе с ним пришло новое: «Слово силы: Стойкость». Тонкая плёнка света, которую можно накинуть на другого. Я накинула её на Рафа раньше, чем подумала, и он удивлённо посмотрел на собственную руку.\",\"Исчадие эфира вылезло из воздуха так, будто ему просто стало тесно в стенах. Фиолетовое, рваное, без лица. Я ударила Карой, Раф закрыл его щитом, Асценси стрелял туда, где у нормальных существ бывает голова. Когда оно рассыпалось, кристалл у меня в ладони дёрнулся и потяжелел — будто отпил.\",\"Мана-клинок был быстрее. Он метнулся к Асценси, и Слово Тьмы легло на него странно, как на свет, который не понимает, куда девать боль. Кара добила. Кристалл стал горячим.\",\"Платформы мы отключали по одной. Первая мигнула и погасла почти вежливо. У второй свет вспыхнул ярче, чем нужно, и я на секунду ослепла. Третья ждала у деревьев, и исчадие вылезло прямо из круга, когда я уже поднимала руку. Раф принял удар за меня. Я ударила в упор и ткнула кристалл в центр, не глядя.\",\"Гул оборвался. Тишина после него была почти неприличной.\",\"Таэдрис взял сытый кристалл, повертел и убрал. Перчатки утренней зари я выбрала из трёх пар, потому что в них не было металла. Серебро он положил мне в ладонь с коротким кивком — и сразу, без паузы, выдал два новых дела.\",\"— Маги шпиля работали со многими древними трактатами и магическими предметами. Нельзя допустить, чтобы их уничтожили вольные духи маны. Скорее всего, они на высших этажах.\",\"Трактат по истории Высокорожденных. Записи о Чарономиконе. Схемы чародейских сердечников. Гадальный шар чародея.\",\"Потом он протянул посох. Свой.\",\"— Из-за произошедшего фамильяры вышли из-под контроля. Я попробовал настроить посох на тип энергии, освободившей их, чтобы обратить процесс и связать их со мной. Попробуй подчинить фамильяров.\",\"Посох был легче моего и гудел иначе — не голодом, а чем-то, что уже знало, куда бить. Асценси молча отпил из фляги. Раф открыл было рот — и, на моё удивление, закрыл.\",\"Верхние этажи шпиля пахли пылью, старой магией и чем-то, что уже начинало развоплощаться. Книги лежали стопками, свитки — где попало, а между ними бродили фамильяры, которые больше не понимали, кому они принадлежат.\",\"Трактат лежал на балконе под грудой камней, шар — рядом, тёплый, будто его только что выпустили из рук. Записи о Чарономиконе нашлись между креслом и столом, схемы — в стопке книг, брошенной в спешке. Из какого-то ящика выпали штаны подмастерья, и я переоделась прямо там, за книжным шкафом, пока Раф деликатно изучал потолок.\",\"Фамильяров было хуже всего. Не потому, что они нападали. Они не нападали. Они бродили между полками, маленькие, светящиеся, растерянные, и время от времени один из них просто тускнел и переставал быть. Тихо, без крика. Первого я подчинила посохом у купола — он дрогнул, замер и прижался к моей ноге, как кошка. Второго не успела. Он погас в шаге от меня, и я ещё долго держала посох вытянутым в пустоту.\",\"Сеамни Полукровка нашлась у круга на полу. Полуэльфийка, бледная, и смотрела так, будто уже видела, как всё это рушится.\",\"— Высшая эльфийка… пожалуйста, помоги мне, — сказала она. — Что-то случилось с моим отцом. Он и его коллеги словно одержимые изучали новую вещь. Увлечённые своей идеей, они забыли про сон и отдых, про семью. И, хотя отец говорил, что его работа перевернёт нашу жизнь, я всё отчётливей видела нарастающее в глазах окружающих безумие.\",\"— Затем пришли духи магии, сея всюду хаос и разрушение. Те из нас, кто сохранил рассудок, пытались с ними сладить, но всё без толку, а отцу и коллегам наши потуги были безразличны. Последнее, что я помню, — призраки маны сметают нашу оборону, а затем… я оказываюсь здесь, в стазисе. Это место теперь пропитано страданиями моих друзей и близких… Прошу, уведи меня отсюда!\",\"Дневник нашёлся в одной из комнат, на столе, среди разбросанных книг. Записи лорда-чародея Антариса. Рискованные эксперименты. Управление потоками магии. И фраза, от которой даже Раф остановился:\",\"Я закрыла дневник и посмотрела на Сеамни. Она смотрела на стены так, будто ещё помнила, как они выглядели раньше. Я убрала дневник поглубже в сумку. Ей не нужно было видеть почерк.\",\"Таэдрис читал долго. Потом закрыл и сказал только:\",\"— Хорошо. Когда ситуация здесь стабилизируется, мы сможем продолжить исследования, начатые обитателями шпиля Рассвета, — в разумных пределах, разумеется.\",\"Из наград я взяла нордеронский длинный лук — и отдала Асценси. Щит миротворца пусть останется тем, у кого руки не заняты посохом, жезлом и чужими дневниками. Асценси подержал лук, проверил тетиву и кивнул мне. Один раз. Для него это было как письмо на трёх страницах.\",\"— Ты довольно талантливая Высшая эльфийка, Люси. Отрадно видеть, что среди нашего народа есть кто-то вроде тебя. И только посмотри на этих фамильяров: разве они не чудо?\",\"Талантливая. Я стояла, и у меня тряслись колени, и я думала не о таланте, а о том, что ещё пять минут назад эти маленькие существа исчезали у меня на глазах, один за другим, тихо, без крика. И что я ничего не могла сделать, пока не смогла. Иногда разница между «спасла» и «смотрела» — это просто пять минут и немного удачи.\",\"Фамильяры стояли поодаль и больше не тускнели. Я пересчитала их глазами. Двух не хватало. Таэдрис этого не знал, а я не стала говорить.\",\"Одеяние Провидца я выбрала, почти не глядя: легче того, что было. Потом он заговорил о Сеамни, уже тише.\",\"— Горе Сеамни! Лорд-чародей всегда был заботливым отцом и делал всё, чтобы его дочь могла жить среди эльфов, не стесняясь своего происхождения. Какое бы безумие его ни поразило, он позаботился о том, чтобы она уцелела в произошедшем инциденте.\",\"Сеамни стояла очень прямо, как стоят дети, которым только что сказали, что всё хорошо, и они изо всех сил стараются поверить. Я знаю этот взгляд. Я сама так смотрела в первый день, у повозки. Мне захотелось подойти и взять её за руку. Я не подошла. Не знала, имею ли право.\",\"— Из этого следует как минимум два вывода. Во-первых, он не стал Презренным, а во-вторых, рассчитывал вернуться в замок, когда закончит начатое. Что же он задумал?\",\"Простые брюки. Седьмой уровень — щёлкнул где-то между его вопросом и моим молчанием, и я заметила его только по тому, как перестали дрожать колени. Позже, вечером, я переписала в журнал цифры — тридцать один, тридцать два, двадцать семь — и они впервые показались мне не важнее, чем «Двух не хватало».\",\"— Бессмысленно разбираться с духами маны, пока цел разлом, — сказал он. — Если мы не уничтожим его, эти существа вскоре заполнят шпиль, а затем обратят свой взор к силовым каналам, обеспечивающим магией весь Нордерон.\",\"Он протянул кристалл. Другой. Не тот, что жрал энергию. Этот гудел иначе — ровнее, но злее.\",\"— Нельзя допустить подобную катастрофу. Люси, я прошу тебя отправиться на вершину шпиля и уничтожить источник здешних бедствий с помощью резонирующего кристалла.\",\"— На вершину, — сказала я. И всё. Ни одного «если». Раф посмотрел на меня удивлённо и ничего не сказал.\",\"Вершина шпиля встретила нас кругом и светом, который уже не выглядел как нормальная магия. Колонны, пол с узорами, и в центре — разлом. Он пульсировал. Фиолетовый, рваный, и с каждым ударом становился шире.\",\"Над разломом воздух шёл рябью, как над костром, и из этой ряби уже тянулись чужие очертания.\",\"Первое отродье вылезло сразу, яркое, без формы, и бросилось на Рафа. Он закрыл щитом. Кара легла на него странно, как на свет. Асценси стрелял в стыки. Разлом вздохнул — и стал шире.\",\"Ещё одно. И ещё. Я перестала считать. Била, отходила, лечила Рафа, била снова. Слово Тьмы соскальзывало — они были не из плоти. Мана уходила, как вода в песок, и где-то на пятом я поймала себя на том, что шепчу: «ну пожалуйста, ну пожалуйста», сама не зная кому.\",\"Потом разлом содрогнулся и потерял форму, и с той стороны полезло что-то большое.\",\"Астральный пожиратель вылез целиком. Голодный. Он не смотрел на нас — он нюхал воздух, поворачиваясь к кристаллу у меня в руке, как зверь, которого слишком долго держали за дверью и вдруг пахнуло едой. Холодный — от него в лицо дохнуло, как из погреба. Первый удар Раф принял на щит, и звон прошёл через площадку мне в зубы. Второй он не принял. Его отбросило к колонне, и он не встал сразу.\",\"Как я оказалась рядом — не знаю. Помню свет из ладоней, слишком слабый, и его лицо — серое, с кровью из носа. Помню, как Асценси встал между нами и пожирателем, один, с луком, и стрелял так быстро, что тетива пела.\",\"Раф открыл глаза.\",\"— Кристалл, — сказал он. — Люси. Кристалл.\",\"Гул в руке стал почти криком. Я поднялась, обошла пожирателя сбоку, пока он тянулся к Асценси, и ткнула кристалл в самый центр разлома.\",\"Пожиратель рухнул. Последним движением он потянулся не ко мне, а туда, где только что был свет, — и не дотянулся. Поток энергии иссяк. Разлом сжался, мигнул и закрылся.\",\"Тишина. Только ветер и наше дыхание.\",\"Я села прямо на узорчатый пол. Руки тряслись так, что кристалл выпал и покатился. Никто его не поднял. Раф сидел у колонны, вытирал нос рукавом и смотрел на меня. Асценси стоял над нами, опустив лук, и впервые за весь день у него в руке не было фляги.\",\"— Закрыт, — сказала я наконец.\",\"— Закрыт, — согласился Раф. И добавил, не сразу: — Ты лечила раньше, чем я упал. Я видел.\",\"Я не знала, что на это ответить. Сама не знаю почему, но руки начали раньше, чем я испугалась.\",\"Таэдрис ждал у подножия. Увидел нас — и кристалл, который больше не гудел, — и выдохнул так, будто держал этот выдох с утра.\",\"— Отличная работа, Жрица. Боевые маги прибудут — рано или поздно.\",\"Шапку смотрителя я взяла из трёх наград, потому что в ней не было металла. Серебро. Опыт. Это всё было потом, и запомнилось хуже, чем кровь у Рафа под носом.\",\"— Журнал исследований лорда-чародея необходимо доставить в Эльдранил, — сказал он. — Я прилагаю к ним свои записи, где излагаю некоторые мысли по поводу произошедшего и дальнейших планов мага. Ступай, Люси. Я же останусь здесь до прибытия боевых магов.\",\"Он протянул свёрток: дневник Антариса и свои заметки.\",\"Дневник был тёплый от рук Таэдриса. Чужая жизнь, записанная чужим почерком, чужие страхи и чужое безумие. Я вдруг подумала о собственном журнале, о своих корявых строчках про сердечники и змей, и мне стало не по себе: если однажды кто-то так же будет передавать из рук в руки мой, пусть хотя бы в нём будет написано, что я старалась.\",\"Я взяла.\",\"Камень возвращения лёг в ладонь привычно. Зелёный свет пополз по руке, по земле, по воздуху — медленно, как всегда. Асценси уже убрал лук и молчал, как всегда. Раф — тоже, и вот это было страшно.\",\"Свет вспыхнул. Мир дёрнулся.\",\"Илнурия встретила нас в том же зале. На этот раз без речи про Солнечный Колодец — она просто протянула руку, и я отдала свёрток.\",\"Она взяла его. Открыла. Молчала дольше, чем нужно для обычного отчёта.\",\"— Невероятно! — сказала она наконец. — Безрассудный гордец покусился на энергии силовых линий и посмел нарушить работу жизненно необходимой Нордерону станции — и ради чего?\",\"— Хуже всего то, что большая часть записей, содержащих ключевые положения идей лорда-чародея, зашифрована, и о его дальнейших действиях мы можем лишь предполагать.\",\"— Нам потребуется время, чтобы выяснить планы Антариса, — продолжила Илнурия. — Но будь уверена: мы остановим этого безумца и убережём жителей Нордерона от беды. От лица Высокого Совета я выражаю тебе благодарность, Люси.\",\"Пятьдесят медяков. Опыт. И благодарность, которая звучала так, будто я принесла им не дневник человека, чуть не сожравшего их станцию, а обычный отчёт.\",\"— Узнаешь. — Она помолчала. — Должна признать, что твоя роль в разрешении кризиса в Шпиле Рассвета оказалась куда значительнее, чем я предполагала. И, хотя нам ещё предстоит до конца разобраться в произошедшем, твоё имя уже на слуху среди членов Совета.\",\"— В частности, тобой заинтересовался лорд Ястребиное Копьё, недавно присоединившийся к нам в качестве генерала следопытов — именно благодаря его усилиям в Нордероне и существует орден Странников. Ступай к нему: полагаю, у генерала к тебе есть важное дело.\",\"Рентар Ястребиное Копьё стоял у окна и смотрел так, будто уже видел меня раньше. Высокий. Спокойный. И с лицом человека, который слишком долго был изгнанником, чтобы теперь удивляться.\",\"— Значит, ты и есть Люси, о которой я слышал? — сказал он. — Я — Рентар Ястребиное Копьё, некогда лорд-следопыт Кель'Таласа и, до недавнего времени, лидер изгнанников Кель'Литиен. Рад встрече.\",\"— Рада, — сказала я. И, к собственному удивлению, это было правдой.\",\"— Наши владения далеко не так обширны, как королевства людей или дворфов. То, что ты видела, Люси, — это, считай, и есть все земли, что остались у нас в этом мире. И долг Странников — любой ценой защитить этот край и его жителей.\",\"Он протянул письмо.\",\"— Увы, даже здесь нам продолжают досаждать эти зеленокожие чудовища, лесные тролли. Странники берегут от этих дикарей границы рощи Вечной Весны, но помощи добровольцев им не повредит. Я дам тебе рекомендации: уверен, твои таланты пригодятся нашим доблестным защитникам. Отправляйся в Анклав Странников, что на юго-востоке отсюда, найди капитана Келмарина и предложи свою помощь.\",\"Я взяла письмо. Анклав Странников на юго-востоке. Капитан Келмарин. Лесные тролли у рощи Вечной Весны.\",\"Мы вышли. Эльдранил жил своей жизнью. Кто-то спорил у фонаря. Кто-то нёс ящики. Никто не знал, что где-то на юго-востоке уже ждут Странники и тролли, которые не собираются ждать, пока Высокий Совет расшифрует записи своего лорда.\",\"Асценси открыл флягу, только когда мы отошли достаточно далеко. Раф шёл рядом, чуть прихрамывая, и впервые за день молчал не потому, что нечего сказать.\",\"— Ты тогда лечила раньше, чем я упал, — повторил он у ворот, будто проверял, не приснилось ли.\",\"— Знаю, — сказала я. — Не спрашивай как.\",\"Он не спросил.\",\"Усталость навалилась сразу вся, как мокрый плащ. Где-то внутри было тихо и немного больно — за тех, кого мы не успели, за шпиль, за Совет, который делал вид, что всё под контролем. И за себя тоже: за то, что у меня одна жизнь, и я уже знаю, на что её трачу.\",\"Пока же — просто шли. Устало, молча, плечом к плечу. И мне было страшно, и больно за всех, кого мы не успели, и всё равно я шла.\",\"Пока ещё есть куда.\"],\"plates\":[{\"after\":11,\"alt\":\"Я посмотрела на них обоих. Раф держался ровно, голос спокойный, но в уголках рта уже прята\",\"src\":\"/chronicle/tome/003.jpg\"},{\"after\":12,\"alt\":\"— Люси, — сказала я. — И я пока не знаю, что тут обычно трогают в первую очередь. И где ту\",\"src\":\"/chronicle/tome/004.jpg\"},{\"after\":17,\"alt\":\"Минут пять я простояла. Думала о том, что камни всё ещё холодные, что Раф, судя по всему, \",\"src\":\"/chronicle/tome/005.jpg\"},{\"after\":43,\"alt\":\"Аллинар ещё стоял над ягодами, когда я положила на стол медяк — плату за первый урок кулин\",\"src\":\"/chronicle/tome/006.jpg\"},{\"after\":53,\"alt\":\"Свет дёрнулся из сердечника в землю. Змей замер, изогнулся, потом медленно осел, словно из\",\"src\":\"/chronicle/tome/007.jpg\"},{\"after\":79,\"alt\":\"Потом она заметила то, что я достала из сумки — просто чтобы проверить, не вывалилось ли ч\",\"src\":\"/chronicle/tome/008.jpg\"},{\"after\":89,\"alt\":\"Звёздная Чешуя нашлась не в роще и не у гавани. Она лежала среди острых золотых кристаллов\",\"src\":\"/chronicle/tome/009.jpg\"},{\"after\":118,\"alt\":\"Когда камнегневов стало шесть, я достала кирку. Зачарованная рукоять легла в ладонь неловк\",\"src\":\"/chronicle/tome/010.jpg\"},{\"after\":123,\"alt\":\"Семьдесят пять медяков. Опыт. И мантия геодезиста — лёгкая, с карманами, которые хотя бы н\",\"src\":\"/chronicle/tome/011.jpg\"},{\"after\":156,\"alt\":\"Серебро он отсчитал сам, дважды, сбиваясь, потому что руки у него дрожали от облегчения. Я\",\"src\":\"/chronicle/tome/012.jpg\"},{\"after\":157,\"alt\":\"Через день, говорили потом, шахтёры вернулись в забой. Не все — двое так и не смогли заста\",\"src\":\"/chronicle/tome/013.jpg\"},{\"after\":173,\"alt\":\"— Уровень, — сказала я. — Пятый. Я это чувствую, как чувствуют, что выспались.\",\"src\":\"/chronicle/tome/014.jpg\"},{\"after\":217,\"alt\":\"Посох был легче моего и гудел иначе — не голодом, а чем-то, что уже знало, куда бить. Асце\",\"src\":\"/chronicle/tome/015.jpg\"},{\"after\":228,\"alt\":\"Из наград я взяла нордеронский длинный лук — и отдала Асценси. Щит миротворца пусть остане\",\"src\":\"/chronicle/tome/016.jpg\"},{\"after\":249,\"alt\":\"— Кристалл, — сказал он. — Люси. Кристалл.\",\"src\":\"/chronicle/tome/017.jpg\"},{\"after\":250,\"alt\":\"Гул в руке стал почти криком. Я поднялась, обошла пожирателя сбоку, пока он тянулся к Асце\",\"src\":\"/chronicle/tome/018.jpg\"},{\"after\":288,\"alt\":\"Пока ещё есть куда.\",\"src\":\"/chronicle/tome/019.jpg\"}]},{\"id\":\"g2-01\",\"numeral\":\"1\",\"title\":\"Часть 1\",\"kicker\":\"Глава 2\",\"dek\":\"Письмо капитану Келмарину два дня пролежало у меня в сумке. Ничего с ним не случилось. Бумага помялась ещё сил\",\"paragraphs\":[\"Письмо капитану Келмарину два дня пролежало у меня в сумке. Ничего с ним не случилось. Бумага помялась ещё сильнее, края обтрепались о шапку смотрителя, но слова Рентара никуда не делись: Анклав Странников, юго-восток, лесные тролли, роща Вечной Весны. Они меня ждали. Тролли, судя по всему, тоже. Я не спешила.\",\"Не из лени. Просто за последние дни я закрыла разлом, пережила астрального пожирателя и выслушала благодарность Высокого Совета в пятьдесят медяков. После такого организм требует чего-то простого: земли под ногами, огня, мяса и тишины. И что-то во мне, сама не знаю что, твердило: тот, кто бежит к следующему капитану сразу после предыдущего лорда, рано или поздно бежит уже мёртвым.\",\"А у меня одна жизнь. Здесь это не фигура речи: где-то под рёбрами сидит холодное знание, что второй попытки не будет. Ни чуда, ни запасной Люси где-нибудь в кармане. И всё-таки иногда, на самом краю, мелькает что-то глупое и упрямое — будто бывает и по-другому. Откуда оно, я не знаю. Проверять не собираюсь.\",\"Раф и Асценси ушли в таверну.\",\"— Мы будем там, — сказал Раф, поправляя ремень щита. — Если что — зови.\",\"— Если что, — ответила я, — вы меня не услышите. Между нами будет пол-леса и бочка эля.\",\"Асценси посмотрел на меня через плечо, долго, и только потом пошёл. Иногда забота выглядит именно так: как взгляд в спину.\",\"* * *\",\"Нордерон осенью — это отдельный вид наглости.\",\"Лес здесь не желтеет постепенно и с сожалением, как мне почему-то казалось правильным. Он горит. Золото на кронах такое густое, что солнце, пробиваясь сквозь листья, ложится на траву медовыми пятнами, и кажется, будто под ногами пролили что-то дорогое. Стволы светлые, почти белые, тонкие, как кости танцовщиц. Под ними — оранжевые кусты, похожие на застывшее пламя, и рыжие цветы, торчащие из травы, как кто-то нарочно рассыпал их, чтобы было красиво.\",\"Арки из зеленоватого камня стоят прямо посреди луга — изогнутые, с резьбой, наполовину ушедшие в землю. Когда-то это было частью чего-то большего. Теперь — просто красивое напоминание о том, что эльфы умеют строить на века и терять построенное за одну ночь. Я провела ладонью по одной из колонн. Камень был тёплый от солнца и шершавый от времени.\",\"Я разбила лагерь в стороне от дороги, в низинке, где трава была мягче, а ветер — слабее. Место для огня, место для сна, место, откуда видно три направления сразу. Почему я сразу стала искать такие вещи, объяснить не могла. Иногда мне казалось, что я живу чью-то чужую жизнь, где всё уже расставлено по местам, а я просто захожу и сажусь, куда показали. Только никто не показывал.\",\"* * *\",\"Медношкурого охотника я увидела в траве, у кромки леса. Небольшая тварь, рыжая, в цвет листвы. Если бы не движение, я бы прошла мимо. Он рылся в земле, нервно вскидывая голову, и шкура его на солнце действительно отливала медью — не красиво-эльфийской, а живой, тёплой, как начищенный котёл.\",\"Четвёртый уровень. Я это не увидела — почувствовала, тем странным внутренним чутьём, которое этот мир вложил мне в голову вместе с телом жрицы. Одно знание — и уже понятно: не угроза. Еда.\",\"Я подняла руку. Свет собрался в ладони — плотный, горячий, с запахом раскалённого металла, — и ударил. Кара легла на зверя вспышкой. Он взвизгнул, развернулся ко мне, бросился. Слово Тьмы: Боль я накинула, пока он бежал, и почувствовала, как оно впилось в него — холодное, липкое, медленное. Он добежал. Цапнул по голени — больно, но не страшно. Вторая Кара. Третья.\",\"Он лёг в траву и больше не вставал.\",\"Я постояла над ним, переводя дыхание. Никакого торжества. Просто тишина и немного дрожи в пальцах — не от страха, от напряжения. Тело ещё не совсем моё. Каждое заклинание отзывается внутри, как будто кто-то тянет за нитку, привязанную к позвоночнику.\",\"Потом достала нож.\",\"Снятие шкур — то немногое, чему меня успели научить здесь, в Эльдраниле, за десять медяков. Руки ещё не привыкли: лезвие соскальзывало, мех рвался по краю, и эту шкуру я почти испортила. Следующая сошла ровнее. Мясо я завернула в листья.\",\"Вечером был шашлык.\",\"Не тот, о котором мечтаешь. Жёсткий, пахнущий дымом и чем-то диким, с горечью костра. Но горячий. Я сидела у огня, жевала, смотрела, как золото на кронах темнеет и становится бронзой, и думала, что в мире, где можно умереть один раз, нет ничего ценнее вечера, в котором никто не пытается тебя убить.\",\"Я съела всё. До последнего жёсткого кусочка, хотя наелась гораздо раньше. А остаток мяса завернула в листья и спрятала поглубже в сумку — не на завтрак, а просто чтобы был. Почему-то мысль о том, что завтра я могу проснуться там, где еды нет совсем, сидела во мне крепче любой другой. Откуда она взялась, я не знала. Я её не звала. Она просто жила внутри, как старая привычка, которой я не помнила.\",\"* * *\",\"Второй день был похож на первый, только смелее. Медношкурые бродили по опушкам, и я научилась замечать их раньше, чем они меня: по колыханию травы, по рыжему пятну, которое двигалось не так, как листья. Я брала их по одному. Никогда — двоих сразу. Шкуры копились в сумке, мясо — у костра, и я, кажется, впервые перестала думать о том, что я здесь чужая.\",\"А потом я увидела дракондора.\",\"Он висел над лугом — иначе не скажешь. Не летел, а именно висел, перебирая крыльями, как огромная стрекоза. Тело синее, фиолетовое, с переливом, крылья — полупрозрачные, светящиеся на солнце, хвост длинный, гибкий. Красивый. Опасно красивый, как всё в этом лесу.\",\"{{Дикий дракондор}}. Седьмой уровень.\",\"Я остановилась. Вот здесь надо было думать. Медношкурые — это еда. Дракондор моего уровня — это поединок. Поединок, в котором проигравший не встаёт, а таких, как он, — сколько угодно: я своими глазами видела над лугом ещё нескольких, и ни один из них не будет плакать, если я лягу в траву.\",\"«Вы слишком далеко!»\",\"Мысль пришла будто не моя — сухая, резкая, красная, как ожог, и почему-то на «вы». Кара не сорвалась с пальцев. Свет просто погас, не долетев. {{Внутри меня кто-то знает, где мне стоять, лучше меня самой}}, подумала я, делая два шага вперёд. {{Хоть бы представился.}}\",\"Ещё два шага. Трава хрустнула. Дракондор повернул голову.\",\"Кара сорвалась с ладони и вонзилась в него золотым росчерком. Под ногами вспыхнул круг — оранжевый, тёплый, — и на мгновение я стояла в нём, как в луже света. Дракондор вскрикнул — пронзительно, по-птичьи, — и рванулся ко мне. Крылья ударили воздух так, что трава легла.\",\"Он был быстрым. Быстрее охотников, быстрее, чем я хотела. Когти полоснули по плечу. Я не вскрикнула — сжала зубы, отступила на полшага, чтобы не упасть, и ударила Карой снова. Мана уходила. Я чувствовала её убыль, как чувствуешь, что в кружке становится меньше воды: не цифрами, а лёгкостью. Он тоже слабел — крылья били реже, вскрик стал хриплым.\",\"В какой-то момент я поймала себя на том, что не думаю ни о Келмарине, ни о троллях, ни о том, что у меня одна жизнь. Только дистанция. Только следующая Кара. Только его крылья — где они, куда идут, когда ударят. В такие минуты я, оказывается, становлюсь проще. Это полезно. Это пугает.\",\"Когда всё закончилось, он лежал в траве, огромный, синий, со сложенными крыльями, и свет в них медленно гас.\",\"Это не похоже ни на что из того, что было со мной раньше. Не вспышка, не голос. Тепло — изнутри, снизу вверх, от ступней к макушке, — как будто кто-то влил в меня горячий свет и он разошёлся по жилам. Рысьи уши дёрнулись сами. Царапина на плече перестала саднить. Пальцы, только что дрожавшие, стали твёрдыми.\",\"Я вдохнула — и вдох оказался глубже, чем был только что. Восьмой. Я знала это так же точно, как знают, что проснулись. Внутри будто раздвинули стены, и свет в груди, который раньше приходилось вычерпывать до дна, теперь плескался выше. Плечо горело. Колени не держали. Я просто стояла и не могла поверить, что жива.\",\"Я стояла посреди луга, над мёртвым дракондором, и дышала.\",\"Цифры я записала вечером, у костра, дрожащей рукой: двести двадцать семь, четыреста пятьдесят. Это не просто цифры. Это ещё один удар, который я смогу пережить. Ещё одна Кара, когда казалось, что маны уже нет. Ещё один шаг между мной и концом, который здесь — настоящий.\",\"— Восьмой, — сказала я. Голос был хриплый. — Ну, хоть кто-то в этом лесу сегодня вырос.\",\"* * *\",\"Утром я пошла к руинам. Сначала, правда, долго сидела у остывшего костра и трогала плечо: от вчерашних когтей не осталось ничего — ни корки, ни розовой полосы, гладкая кожа, как будто дракондора и не было. Меня это почему-то не обрадовало.\",\"Они стояли на холме, над лугом: колонны — высокие, светлые, с резными основаниями, — и площадка, вымощенная шестиугольными плитами, местами треснувшими, местами вспученными корнями. Корни здесь были везде. Старые, толстые, тёмные, они ползли по камню, как будто лес медленно, вежливо, по-эльфийски пытался забрать это место обратно.\",\"Посреди руин был рунный камень.\",\"{{Рунный камень Элессар.}} Название было выбито у подножия старыми буквами, которые я почему-то смогла прочитать. Камень молчал. Руны на нём — если это были руны — не светились. Просто стояли. Как надгробие чему-то, чего я уже никогда не узнаю.\",\"У подножия колонны, между корней, стоял сундук.\",\"— Ты ещё кого-то из нас ждёшь? — спросила я у камня Элессар.\",\"— Нас, — сказали у меня за спиной.\",\"Я обернулась.\",\"Раф стоял на краю площадки — в доспехах, с щитом, свежий, как будто не провёл два дня в таверне. Асценси — чуть позади, с луком на плече. На его доспехах, кажется, была свежая царапина — мелкая, но была. Дорога сюда, видимо, тоже не обошлась без разговоров с местными.\",\"— Ты не пряталась, — сказал Раф. — Дым от твоего костра видно с дороги. — Он прищурился. — А ты… другая. Выросла, что ли?\",\"Асценси ничего не сказал. Только задержал на мне взгляд чуть дольше обычного и кивнул — как кивают тому, кто вернулся с того берега.\",\"— Письмо всё ещё у тебя? — спросил Раф, глядя на юго-восток, где за золотыми кронами были Анклав, Келмарин и тролли.\",\"Я тронула сумку. Бумага хрустнула.\",\"— Ну, — сказал Раф. — Откроем?\"],\"plates\":[{\"after\":20,\"alt\":\"Вечером был шашлык.\",\"src\":\"/chronicle/tome/020.jpg\"},{\"after\":38,\"alt\":\"Я стояла посреди луга, над мёртвым дракондором, и дышала.\",\"src\":\"/chronicle/tome/021.jpg\"},{\"after\":39,\"alt\":\"Цифры я записала вечером, у костра, дрожащей рукой: двести двадцать семь, четыреста пятьде\",\"src\":\"/chronicle/tome/022.jpg\"},{\"after\":45,\"alt\":\"Рунный камень Элессар. Название было выбито у подножия старыми буквами, которые я почему-т\",\"src\":\"/chronicle/tome/023.jpg\"},{\"after\":51,\"alt\":\"— Ты не пряталась, — сказал Раф. — Дым от твоего костра видно с дороги. — Он прищурился. —\",\"src\":\"/chronicle/tome/024.jpg\"}]},{\"id\":\"g2-02\",\"numeral\":\"2\",\"title\":\"Часть 2\",\"kicker\":\"Глава 2\",\"dek\":\"Мы ушли от камня Элессар, не открыв сундук. Решение было коллективным: Раф сказал «потом», Асценси сказал «как\",\"paragraphs\":[\"Мы ушли от камня Элессар, не открыв сундук. Решение было коллективным: Раф сказал «потом», Асценси сказал «как хочешь», а я сказала, что если в нём сидит что-то с зубами, пусть сидит дальше. Сундук возражать не стал.\",\"Дорога вниз, к лесу, была вымощена тем же светлым камнем, что и площадка у руин. Плиты местами просели, между ними пробивалась трава, а по обочинам на тонких золочёных столбах висели фонари. Днём они не столько светили, сколько мерцали: синие сгустки света, как пойманные капли неба, которые кто-то повесил на палку и забыл снять. Эльфы. Даже фонари у них такие, будто стоят дороже моей жизни.\",\"Раф шёл рядом, грохоча доспехами на каждой третьей плите. Потом вдруг остановился посреди дороги.\",\"— Погоди.\",\"— Это тебе.\",\"Он сунул мне в руки рулоны ткани, аккуратно скрученные, перевязанные бечёвкой. Шерсть: три рулона, грубые, тёплые, пахнущие овчарней. И лён, тоже три, светлее, мягче, с запахом пыльной кладовки. Без церемоний, как суёт старший брат младшей сестре варежки перед выходом на мороз.\",\"— Сошьёшь что-нибудь. Или бинты. Мне они ни к чему.\",\"— Спасибо, — сказала я. И, что удивительно, имела это в виду.\",\"— Это не всё.\",\"Он снова полез в сумку. Вытащил свёрток. Свёрток был мокрый. Свёрток блестел. И пах так, что у меня свело скулы, а рот сам наполнился слюной. Такого со мной давно не случалось.\",\"Рыба. Мелкая, серебристая, с переливом по боку, как разлитое масло. Сырая блестящая рыбка, много. Он вытряхнул её прямо мне в подставленную сумку, всю, сколько было.\",\"— Тридцать четыре, — сказала я, пересчитав. Медленно. Вслух. — Раф. Ты дал мне тридцать четыре сырых рыбы.\",\"— Ты же готовишь, — сказал Раф.\",\"— Готовлю. Да. — Я посмотрела на рыбу. Рыба посмотрела на меня. Тридцать четыре раза. — Скажи честно. Ты смотришь на мои уши, видишь рысь и думаешь: «ей понравится»?\",\"Раф открыл рот. Потом закрыл.\",\"— Ты стоял на берегу, удил и думал: «Люси любит рыбу. И клубки». Ткань, Раф. Шерсть. Ты мне ещё бантик на верёвочке привяжи.\",\"Асценси, который всё это время стоял чуть в стороне, издал звук. Короткий. Сдавленный.\",\"— Ты смеёшься, Асценси. Я слышу. У меня четыре уха.\",\"Он молча помотал головой, отвернулся, и плечи у него затряслись. Лук на спине покачивался в такт. Раф посмотрел на него с выражением человека, которого предали прямо на дороге.\",\"— Это хорошая рыба, — сказал Раф. Тихо. С достоинством.\",\"— Я не сказала, что плохая. — Я убрала свёрток в сумку. Сумка запахла морем. Теперь она окончательно стала лавкой старьёвщика, который подрабатывает на рыбном рынке. — Я её пожарю. Всю. И когда ты придёшь к костру, Раф, я дам тебе одну. Одну. И буду смотреть, как ты её ешь. Молча.\",\"* * *\",\"— Асценси.\",\"Я начала вытаскивать. Шкуры медношкурых — выделанные, вернее то, что из них получилось после моего ножа и двух дней работы. Тонкая кожа: стопка, двадцать штук, лёгкая, рыжеватая, ещё пахнущая костром. Обрывки — много, тридцать четыре, всё, что не пошло в дело, но выбросить было жалко. И один кусок жёсткой кожи, тяжёлый, плотный, будто его сняли с чего-то, что не хотело его отдавать.\",\"Я сгрузила всё это Асценси в руки: двадцать тонких кож, тридцать четыре обрывка и одну жёсткую, последнюю, положила сверху, как вишенку на торт.\",\"Асценси поднял на меня глаза — вопрос без слов.\",\"— Ты охотник. — Я пожала плечами. — Ты в коже ходишь. Ты в ней спишь, стреляешь, наверное, и дышишь в ней. Вдруг сошьёшь что-нибудь. Нам. Мне — что-нибудь, что не порвёт первый же дракондор. Рафу — что-нибудь, что не звенит.\",\"Он перебрал обрывки, пересчитал их одними губами, потом посмотрел на Рафов свёрток с рыбой и показал мне два раза по три пальца и ещё четыре. Тридцать четыре. Как рыбы.\",\"И мы трое стояли посреди эльфийской дороги, под синим фонарём, с сумками, полными тряпок, рыбы и кожи, и смеялись. Не громко. Не долго. Но по-настоящему. Так, как смеются люди, которые недавно закрыли разлом и выжили, и пока ещё не совсем верят, что это было с ними.\",\"Я поймала себя на мысли: эту жизнь, чужую, непонятно чью, у меня в любой момент могут отнять когтем, стрелой, топором тролля. Но вот сейчас, вот прямо здесь — она была не такой уж плохой. Почти моей.\",\"* * *\",\"Дорога пошла дальше, к строениям. Плиты под ногами сменились камнем с золотистым узором, и мимо поплыли ткани — красные, золотые, с тяжёлыми кистями, развешанные так, будто эльфы и здесь не могли обойтись без украшений даже там, где воюют. Фонарей стало больше. Синих, мерцающих. И людей — больше.\",\"Кто-то стоял впереди. Высокий, прямой, в доспехах. Я увидела его краем глаза — не лицо, только осанку, и то, как он смотрел на дорогу. Так смотрят те, кто отвечает за то, что по ней приходит.\",\"Я тронула сумку. Бумага хрустнула — письмо Рентара всё ещё было там, между тканью и рыбой.\",\"Я выпрямилась, поправила шапку смотрителя и пошла вперёд.\"],\"plates\":[{\"after\":12,\"alt\":\"— Ты же готовишь, — сказал Раф.\",\"src\":\"/chronicle/tome/025.jpg\"}]},{\"id\":\"g2-03\",\"numeral\":\"3\",\"title\":\"Часть 3\",\"kicker\":\"Глава 2\",\"dek\":\"Таверна в Анклаве Странников была похожа на всё эльфийское сразу: слишком красивая для места, где воюют, и сли\",\"paragraphs\":[\"Таверна в Анклаве Странников была похожа на всё эльфийское сразу: слишком красивая для места, где воюют, и слишком уютная для места, где умирают.\",\"С потолка до пола спускались фиолетовые полотнища, тяжёлые, как ночное небо, которое кто-то сложил и повесил сушиться. В золотых канделябрах горели свечи — синим, ровным, холодным огнём, от которого не пахло ни воском, ни дымом. На полу лежала медвежья шкура с головой: пасть оскалена, стеклянные глаза смотрят в потолок с выражением глубокой обиды. А в углу, на подставке, стоял сам медведь. Вернее, другой медведь. Чучело. На задних лапах, передние подняты, когти растопырены, будто он собирался кого-то обнять и передумал на полпути.\",\"Асценси аккуратно обошёл медвежью голову. Не наступил. Охотники, видимо, уважают коллег даже в таком виде.\",\"За стойкой стояла хозяйка. Высокая, светловолосая, с лицом женщины, которая видела достаточно голодных воинов, чтобы не бояться ни одного из них. Кто-то у стойки окликнул её по имени — Телера, — и я сразу поняла: хозяйка. А по тому, как она держала плечи и как спокойно смотрела на вооружённых гостей, — что она сильнее меня. Даже трактирщица здесь, пожалуй, могла бы меня побить. Это многое говорило о Нордероне.\",\"— Знаешь, что нужно воинам после тяжёлого боя? — спросила она, не дожидаясь, пока я поздороваюсь. — Горячее мясное блюдо.\",\"— Знаю, — сказала я. — Я два дня этим жила.\",\"— Нежная, сочная оленина в собственном соку отлично подойдёт к вину Солнечного Края, которое нам недавно привезли. Увы, мои запасы мяса на исходе, а пополнять их весьма проблематично из-за непрекращающихся набегов троллей.\",\"— Как думаешь, — Телера наклонилась над стойкой, — сможет такая жрица, как ты, поохотиться на белохвостых оленей, что пасутся на севере отсюда, у границ Диколесья, и принести мне столько мяса, чтобы им можно было мешок набить?\",\"— Шесть кусков вырезки, — добавила она, уже отворачиваясь к очагу. — Принеси мне сюда, в Анклав. Остальное я сама.\",\"— Шесть кусков, — сказала я. — Вырезки. Не шкуры, не рогов, не задней ноги, обглоданной волком.\",\"Раф наклонился ко мне.\",\"— Ты понимаешь, что мы пришли сюда воевать с троллями?\",\"— Понимаю.\",\"— И первое, что мы делаем, — идём за мясом.\",\"— Раф. — Я посмотрела на него снизу вверх. — Армия марширует на желудке. Это не я придумала. Не знаю кто — фраза просто сидела у меня в голове, будто всегда там жила. Кроме того, ты мне вчера дал тридцать четыре рыбы. Ты последний, кто имеет право говорить о еде.\",\"* * *\",\"К северу от Анклава лес становился другим.\",\"Олени паслись на опушке. Крупные, рыжевато-бурые, с белыми хвостами, которые вскидывались при каждом шорохе, как флаги капитуляции. Рога — широкие, ветвистые. Восьмой уровень. Как я.\",\"Первый олень поднял голову, когда я ещё не успела подойти.\",\"Я подходила по шагу, пока олень не переступил ногами и не насторожился, и тогда Кара ударила его в бок — не вспышкой даже, а сухим толчком света, от которого у меня кольнуло в запястье. Он рванул ко мне, тяжело, так что земля задрожала; Раф шагнул наперерез, и щит звякнул. Боль я накинула почти не глядя, следом — ещё Кару. Стрела Асценси свистнула у самого виска, и я даже не вздрогнула. Почти.\",\"Олень лёг в траву.\",\"Я подошла. Достала нож. Вырезка — это не шкура, тут нельзя торопиться. Мясо тёмное, плотное, тёплое. Руки работали сами. Мысли — тоже.\",\"{{Вырезка — 1 из 6}}, — отметила я потом в журнале, вытирая нож о траву. Рука немного дрожала. Олень смотрел в небо открытыми глазами, и я закрыла их ладонью, прежде чем уйти.\",\"Потом шкура. Снятие шкур — медленное, кропотливое. Я опустилась на колени рядом с тушей, и вокруг меня на мгновение лёг тусклый круг света — то ли от магии, то ли от солнца, — и нож пошёл по краю, отделяя мех от мяса. Шкура будет. Асценси получит ещё. Пусть шьёт.\",\"* * *\",\"Мы шли дальше, на север. Деревья становились гуще. Свет — тусклее. Кусты здесь были такие же рыжие, но под ними лежали тени, длинные, чёрные, и в этих тенях что-то не шевелилось. Именно — не шевелилось. Птицы перестали кричать. Я не заметила, когда.\",\"Уши дёрнулись. Сначала рысьи, потом — я сама.\",\"— Тихо, — сказала я.\",\"Я увидела его первой. Под кустом, у самых белых стволов, в траве, которая была примята не так, как примята трава под спящим. Рыжие листья лежали на нём, будто лес пытался его укрыть. Не успел.\",\"Эльф. Следопыт. Кожаный доспех, плащ. Рыжие волосы — как листья вокруг.\",\"Следопыт Дартелон. Имя было вышито на подкладке плаща — у Странников, как я потом узнала, так делают все: чтобы было кому сказать. Я прочитала его вслух и пожалела.\",\"Тело было изувечено. Рваные раны — по рукам, по груди, по горлу. Глубокие, неровные, будто кто-то рвал, а не резал. Я присела рядом. Не трогала. Смотрела.\",\"Крови не было.\",\"Ни на траве. Ни на листьях. Ни под ним. Раны — огромные, страшные — были сухими. Кожа вокруг них — серая, натянутая, как пергамент. Лицо — впалое, будто из него вытянули не только жизнь, но и всё, что её держало.\",\"Он умер не от клыков и когтей. Раны были потом. Или для вида. Или просто так. А умер он оттого, что его выпили. Досуха.\",\"Я сидела рядом с ним и чувствовала, как по спине ползёт холод. Не магический. Самый обычный, человеческий, тот, что приходит, когда понимаешь: где-то рядом есть что-то, что умеет так делать. И это что-то, может быть, ещё здесь.\",\"— Люси, — тихо сказал Раф. Он стоял за мной, со щитом, повернувшись спиной к телу и лицом к лесу.\",\"Асценси стоял чуть в стороне. Лук поднят. Стрела на тетиве. Он смотрел не на тело, а на деревья, и я впервые увидела, как у него дрожит челюсть.\",\"— Его выпили, — тихо сказал Раф. — Кто пьёт эльфов?\",\"— Тот, кто голоден. — Я встала. Колени не дрожали. Почти. — И кого мы пока не видели.\",\"У пояса следопыта была сумка. Кожаная, потёртая, с застёжкой. Из неё торчали края бумаги. Записи. Я протянула руку — и остановилась на полпути. Вдруг ловушка. Вдруг то, что его выпило, оставило подарок. Вдруг.\",\"Я забрала записи.\",\"Я не стала их читать. Не здесь. Не над телом, не под этими белыми стволами, не в этой тишине. Сунула в сумку — рядом с письмом Рентара, с вырезкой, с тканью Рафа и его проклятой рыбой. Сумка становилась тяжелее. Не от веса.\",\"Где-то наверху наконец закричала птица.\"],\"plates\":[{\"after\":3,\"alt\":\"За стойкой стояла хозяйка. Высокая, светловолосая, с лицом женщины, которая видела достато\",\"src\":\"/chronicle/tome/026.jpg\"},{\"after\":38,\"alt\":\"— Его выпили, — тихо сказал Раф. — Кто пьёт эльфов?\",\"src\":\"/chronicle/tome/027.jpg\"}]},{\"id\":\"g2-04\",\"numeral\":\"4\",\"title\":\"Часть 4\",\"kicker\":\"Глава 2\",\"dek\":\"Остальные пять кусков вырезки я добыла молча. Олени паслись там же, на опушке у границ Диколесья, и каждый раз\",\"paragraphs\":[\"Остальные пять кусков вырезки я добыла молча. Олени паслись там же, на опушке у границ Диколесья, и каждый раз, поднимая руку для Кары, я сначала оглядывала кусты. Не оленя — кусты. Раф делал то же самое. Асценси вообще, кажется, перестал смотреть на дичь: смотрел только на деревья.\",\"* * *\",\"Капитан Келмарин стоял в центре анклава, у костра.\",\"Костёр здесь тоже был эльфийский: брёвна сложены шатром, ровно, как по чертежу, а под ними — круглое ложе из золотистого металла с узором, похожим на солнце. Огонь горел высоко и ярко, и от него на светлые плиты ложились тени колонн. Вокруг лежали фиолетовые ковры. Видимо, чтобы воевать с троллями было удобнее сидя.\",\"Сам капитан — рыжеволосый эльф с жёстким лицом — выглядел как человек, который давно не спал и давно этого не замечает.\",\"Я протянула ему не письмо Рентара. Записи.\",\"— Дартелон, — сказал он. Не вопрос.\",\"— Под кустом, у белых стволов, на севере. — Я помолчала. — Его выпили, капитан. Досуха. Раны есть, но крови не было.\",\"— Потеря Дартелона и его отряда — горе для Странников, — сказал он наконец. — Они были хорошими эльфами и мастерами своего дела. Не знаю, что за чудовище унесло их жизни, но оно должно понести наказание.\",\"Он отсчитал пятьдесят медяков и положил их передо мной на стол, медленно, по одному, будто каждая монета была за кого-то из них. Я не сразу смогла их взять. Вечером я записала на полях, без всякого повода: {{Дартелон.}} Просто имя.\",\"— Я бегло ознакомился с записями, которые вёл Дартелон, — сказал он. — Они полны заметок о невиданных ранее зверях, с которыми столкнулись его следопыты.\",\"— Дартелон пришёл к выводу, что эти существа обладают магической природой и, вероятно, жаждут магии. — Он поднял на меня глаза. — Ему удалось выследить их вожака и даже отметить местонахождение логова этого зверя. Но добраться до него, по всей видимости, Дартелон не успел: чудовище напало раньше и застало отряд врасплох.\",\"Жаждут магии.\",\"Я посмотрела на свои руки. На руки жрицы, в которых живёт Свет. На Рафа — паладина, у которого Свет даже в щите. Асценси стоял чуть позади, и я подумала, что охотнику, может быть, повезло больше всех нас.\",\"— Отряд мастеров, — сказала я, когда Келмарин отвернулся к огню. — Мастеров, Раф. Не учеников. Они знали этот лес лучше нас и не вернулись. А у меня одна жизнь и кушак, которого ещё даже нет.\",\"— Можно отказаться, — сказал Раф. Без упрёка. Просто положил это на стол рядом с медяками.\",\"— И что тогда? Гончие придут сюда, к костру, где кто-то сейчас смеётся?\",\"— Придут, — согласился он. — Но не сегодня. Я просто хочу, чтобы ты знала: «нет» тоже бывает ответом. Хотя бы раз в неделю.\",\"Асценси ничего не сказал. Только отвинтил крышку фляги, сделал глоток и протянул её мне. Я глотнула. Это было ужасно. Это было именно то, что нужно.\",\"— Я хочу, чтобы ты продолжила дело Дартелона, — сказал Келмарин. — Найди следы берилловых гончих и одолей их вожака, Сапфировую Пасть. Останки принеси Мьюре Яркопряд в лагерь разведчиков на границе с Диколесьем. Она поймёт.\",\"— Оленину тоже кто-то должен приносить, — сказал он. — Телера уже спрашивала.\",\"* * *\",\"Я выложила на стойку шесть кусков вырезки. Тёмное мясо, завёрнутое в листья.\",\"— За годы жизни бок о бок со Странниками я поняла две вещи, — сказала Телера, пересчитывая. — Первое: голодный Странник хуже тролля.\",\"— А второе?\",\"— Второе: они на дух не выносят магические кексы.\",\"Она вытерла руки о передник и, глядя на вырезку, впервые за всё время улыбнулась. Она дала мне серебряную монету и завернула в тряпицу пять острых отбивных оленины.\",\"Пять острых отбивных. Мясо пахло специями и дымом. Неплохо. Моя кулинария пока так не умела.\",\"— Острые, — сказал Раф, понюхав тряпицу. — А надо бы что-то сытное. Похлёбку. Чтобы держала. Я получаю по щиту за всех троих, мне нужно, чтобы внутри было что-то тяжёлое.\",\"— Тебе нужно, чтобы внутри было что-то, кроме рыбы, — сказала я. — Тридцать четыре штуки, Раф. Я ещё помню.\",\"Асценси молча взял одну отбивную, понюхал перец и положил её на свою сторону стола. Потом подумал и положил вторую.\",\"Потом Телера выложила три пояса на выбор. Кожаные остались лежать: я ношу только ткань, так что выбор был, честно говоря, иллюзией выбора.\",\"Кушак — светлая ткань, мягкая, с аккуратным узором по краю, тёплая от её рук. Я почувствовала это, едва застегнула, как чувствуешь, что надела любимый свитер: мана стала глубже на глоток. А мана — это Кара, которой хватит на ещё один удар. На Сапфировую Пасть, которая, если верить Дартелону, жаждет магии.\",\"Я затянула узел покрепче. Пальцы почему-то не слушались.\"],\"plates\":[{\"after\":4,\"alt\":\"Сам капитан — рыжеволосый эльф с жёстким лицом — выглядел как человек, который давно не сп\",\"src\":\"/chronicle/tome/028.jpg\"},{\"after\":17,\"alt\":\"— Придут, — согласился он. — Но не сегодня. Я просто хочу, чтобы ты знала: «нет» тоже быва\",\"src\":\"/chronicle/tome/029.jpg\"}]},{\"id\":\"g2-05\",\"numeral\":\"5\",\"title\":\"Часть 5\",\"kicker\":\"Глава 2\",\"dek\":\"Роща Вечной Весны оказалась не тем, что обещало название.\",\"paragraphs\":[\"Роща Вечной Весны оказалась не тем, что обещало название.\",\"Весной здесь и не пахло. Пахло осенью — сухой листвой, нагретой корой, землёй, которая уже готовится спать. Те же золотые кроны, те же белые стволы, те же рыжие кусты, но всё стало старше. Деревья — толще, корни — шире, склоны — круче. Справа и слева поднимались скалы, серые, поросшие мхом, и дорога, мощёная эльфийским камнем, то пряталась в траве, то выныривала снова, будто проверяла, идём ли мы ещё за ней.\",\"{{Жаждут магии}}, писал Дартелон. А я теперь носила на себе ещё глоток этой магии. Сама. Добровольно. Как человек, который идёт к волкам и на всякий случай натирается салом.\",\"Асценси поймал мою руку на кушаке, посмотрел на неё и выразительно поднял бровь. Я убрала руку. Через сорок шагов она вернулась туда сама.\",\"* * *\",\"Первый след мы нашли у руин.\",\"Отпечатки лап в мягкой земле, крупные, глубокие, с длинными когтями. Но не это заставило меня остановиться. Трава вокруг была примята и выцвела — не пожухла, не засохла, а именно выцвела, будто из неё вытянули цвет. И пахло здесь странно. Не зверем. Озоном. Так пахнет воздух после молнии.\",\"Хозяйка следов вышла из-за деревьев сама.\",\"Берилловая гончая была красивой. Это первое, что я подумала, и мне стало стыдно за эту мысль. Пёс размером с крупного волка, приземистый, широкогрудый, с шерстью цвета глубокой воды. Не синий даже — бирюзовый, с переливом, и по спине, по загривку, по лапам у него бежало холодное свечение, будто под шкурой текла не кровь, а лунный свет. Глаза светились тоже.\",\"Гончая подняла голову и посмотрела не на Рафа. Не на Асценси. На меня.\",\"Она бросилась.\",\"Раф шагнул наперерез, щит лёг, удар отдался звоном по всей опушке. Гончая отскочила, обогнула его — не пытаясь пробить, а именно обогнула, — и снова пошла ко мне. Не к тому, кто бил. К тому, от кого пахло Светом.\",\"Кара. Вспышка легла ей на загривок, и свечение под шкурой вздрогнуло, будто она глотнула. Мне это не понравилось. Тогда я бросила в неё Слово Тьмы: Боль — холодное, тёмное, не из Света; может, хоть оно ей не по вкусу. Стрела Асценси вошла ей в бок, Раф ударил сверху. Гончая взвизгнула, крутанулась, клацнула зубами у моей руки — промахнулась на ладонь.\",\"Она легла в траву, и свет под её шкурой погас не сразу. Медленно, как остывают угли.\",\"Дальше было как по описи, только опись вёл кто-то злой. Второй след — у подножия скалы, и гончих там было две: одна на Рафа, вторая, разумеется, на меня, пока Раф не научился ставить щит так, чтобы дуги не было. Третий — у валуна, вросшего в склон, где трава вокруг не просто выцвела, а умерла. Там гончая ждала одна и смотрела на меня так долго, что я успела сказать ей: «Знаешь, я тоже не в восторге от этого кушака». К третьему бою у меня перестали дрожать руки. Это было хорошо. И плохо: когда руки перестают дрожать, начинаешь думать, что так будет всегда.\",\"* * *\",\"Асценси присел у следов и долго смотрел на них.\",\"Потом молча поднял руку и показал на склон, на тёмный проём в скалах чуть выше. Все три цепочки следов сходились туда.\",\"Логово.\",\"Дартелон его нашёл. Отметил. И не успел.\",\"* * *\",\"Вход в пещеру был похож на рот.\",\"Серые камни, громоздящиеся друг на друга, мох по краям, а наверху — каменные сосульки, свисающие, как зубы. Изнутри тянуло холодом и тем самым запахом — озоном, грозой, металлом. У входа росли грибы: крупные, жёлтые и рыжие, с широкими шляпками, неестественно яркие на сером камне. Они светились. Чуть-чуть. Будто тоже чего-то наелись.\",\"Я остановилась у порога. Проверила себя. Здоровье — почти полное. Мана — нет. Я ждала, пока она вернётся, и считала вдохи. Кушак, надо отдать ему должное, работал: мана поднималась быстрее, чем раньше. На глоток. Как и обещал.\",\"Асценси снял лук с плеча, проверил тетиву. Ничего не сказал. Даже не закашлял.\",\"Мы вошли.\",\"* * *\",\"Сапфировая Пасть лежала в глубине пещеры, на камнях, среди светящихся грибов. Сначала я приняла её за валун. Потом валун поднял голову.\",\"Она была намного больше гончих. Тот же бирюзовый мех, но темнее, гуще, почти синий, как сапфир. Свечение под шкурой не бежало струйками — оно горело. Ровно, холодно, сильно. Пасть — широкая, тяжёлая, и я поняла, откуда имя. Одиннадцатый уровень. И что-то ещё, что я почувствовала раньше, чем поняла: эта тварь была не просто сильнее, а опаснее. Таких мир отмечает отдельно — не цифрой, а тем холодком, который ползёт по спине.\",\"Только потом я разглядела, что она делает. Она вылизывала светящиеся грибы. Медленно, жадно, как голодная собака вылизывает пустую миску, — и рёбра у неё под сапфировым мехом ходили, как у зверя, который давно не ел досыта. Вокруг лежали кости. Не только звериные. Я не стала смотреть, чьи.\",\"Она не охотилась на нас ради удовольствия. Ей просто было мало. Всего на свете ей было мало, кроме того, что светилось у меня в ладонях.\",\"Она бросилась одновременно с Рафом — и не на него. Конечно, не на него. Длинный прыжок, мимо щита, через камни — ко мне. Раф развернулся на полушаге, ударил её щитом в плечо, сбил с траектории. Она проехала по камню когтями, высекая искры, и развернулась. К нему. На мгновение. Только на мгновение.\",\"Кара. Свет ударил ей в морду, и свечение под шкурой вспыхнуло ярче — она глотнула. Я увидела это. Я ей помогала.\",\"Слово Тьмы: Боль. Тёмная нить вошла ей в бок и осталась там, медленная, холодная, грызущая. Тварь дёрнулась — не от боли даже, от раздражения, будто кто-то подал ей блюдо не того вкуса.\",\"Раф держал её. Это было главное. Он стоял между мной и ней, и каждый раз, когда она пыталась обойти его, он делал шаг — один, короткий, точный — и снова оказывался на пути. Щит звенел. Когти скребли по металлу. Я видела, как у него дрожит рука после каждого удара. Видела, как он не отступает.\",\"Я била. Кара — когда она поворачивалась к Рафу, чтобы свет ушёл в рану, а не в пасть. Слово Тьмы — когда старое кончалось. Внутри становилось легче — не той лёгкостью, которая радует, а той, которая предупреждает, — и к пятой Каре у меня жгло между лопатками, будто свет выходил не из ладоней, а из спины.\",\"Раф поскользнулся на грибе — глупо, нелепо, на этом проклятом светящемся грибе, — и щит ушёл в сторону на полладони. Ей хватило. Сапфировая Пасть рванулась ко мне, и я увидела её пасть близко. Слишком близко. Синий свет в глотке. Запах грозы, такой густой, что зазвенело в голове.\",\"Я не побежала. Бежать от неё было некуда — сзади камни, вход далеко, а она быстрее. Я шагнула в сторону, за выступ скалы, и она врезалась в камень плечом. Не попала. На ладонь. Опять на ладонь.\",\"Стрела Асценси вошла ей в глаз.\",\"Она завыла. Раф уже был рядом — щит, удар, ещё удар, — и тварь развернулась к нему, ослепшая наполовину, злая, теряющая свет.\",\"Она упала не сразу. Сначала опустилась на передние лапы. Потом легла. Свечение под шкурой мигнуло — раз, другой, — и начало гаснуть. Медленно. Как будто тварь не хотела отдавать ни капли того, что успела выпить.\",\"Руки теперь дрожали. Всё-таки дрожали. Я опустила их и стояла, слушая, как в пещере становится тихо. Как Раф дышит — тяжело, хрипло. Как Асценси опускает лук. Как где-то капает вода.\",\"* * *\",\"Я подошла к ней последней.\",\"Сапфировая Пасть лежала на камнях, огромная, тёмная, и свет в ней больше не горел. Просто мёртвый зверь. Красивый. Страшный. Убивший Дартелона и его отряд.\",\"Я сняла с неё то, что могла унести: сломанный клык и голову. Голову Сапфировой Пасти. Руки сделали это сами, а я стояла где-то рядом и смотрела на них со стороны.\",\"Клык был сломан у самого основания — тёмный, синеватый, тяжёлый. Голову я завернула в плащ, как могла. Она была тяжелее, чем я ожидала. Или я была слабее, чем думала.\",\"Раф поднял щит. На нём были свежие царапины — глубокие, длинные, светящиеся по краям синим. Он посмотрел на них, потом на меня.\",\"— Ты не убежала, — сказал он.\",\"— Некуда было.\",\"— Было. За выступ. Ты могла дальше.\",\"— Тогда она пошла бы за мной, а не за тобой, — сказала я. — А у тебя щит.\",\"Он кивнул. Медленно. Как кивают, когда понимают что-то, о чём не стоит говорить вслух.\",\"По дороге Асценси вдруг свернул с тропы, не сказав ни слова, и вскоре догнал нас с охапкой длинной сухой травы. Молча завернул в неё свёрток с головой — плотно, в три слоя. Свёрток перестал оставлять за нами след. Я поняла это только у лагеря, когда ни одна ворона за нами так и не увязалась.\",\"* * *\",\"До Мьюры мы в тот вечер не дошли. Раф развёл огонь в лощине, Асценси положил свёрток с головой подальше от углей, а я легла у костра прямо на плащ и даже не стала есть. Последнее, что я помню, — треск сырой ветки и как Раф накрывает меня своим плащом поверх моего.\",\"А потом был песок.\",\"Серый, мёртвый, до самого края неба, и в нём — рыжие пятна, как ржавчина на старом ноже. Ни травы, ни птиц. Тишина такая плотная, что её было слышно: она гудела в ушах ровно и низко, будто где-то под песком работало что-то огромное и больное. Я шла, и мне хотелось есть. Не так, как хочется после боя, — а везде, всем телом, как будто голод был не во мне, а в воздухе, в песке, в небе цвета грязной воды.\",\"Она вышла из-за камня бесшумно. Я не увидела её — только почувствовала, как что-то тёплое вцепилось в голову, сверху, у самой макушки. Было горячо. Очень горячо. А потом — холодно, и холод пошёл вниз, по шее, по позвоночнику, до самых пяток.\",\"Я проснулась.\",\"Костёр догорал. Раф спал сидя, со щитом на коленях, Асценси — на боку, лицом к лесу. Над лощиной светлело. Кисточки на макушке дёрнулись сами, раз и другой, хотя вокруг было совсем тихо, и я долго лежала, прислушиваясь, к чему они прислушиваются.\",\"Ничего не было. Только лес и наше дыхание.\",\"Я встала, подбросила в огонь веток и, сама не зная почему, отрезала от вчерашнего мяса самый большой кусок и положила его у руки Рафа, а не себе в сумку. Раньше я бы спрятала. С того утра я перестала прятать еду на потом.\"],\"plates\":[{\"after\":44,\"alt\":\"Сапфировая Пасть лежала на камнях, огромная, тёмная, и свет в ней больше не горел. Просто \",\"src\":\"/chronicle/tome/030.jpg\"},{\"after\":61,\"alt\":\"Ничего не было. Только лес и наше дыхание.\",\"src\":\"/chronicle/tome/031.jpg\"}]},{\"id\":\"g2-06\",\"numeral\":\"6\",\"title\":\"Часть 6\",\"kicker\":\"Глава 2\",\"dek\":\"Лагерь следопытов у границы Диколесья был первым местом в Нордероне, которое выглядело так, будто здесь действ\",\"paragraphs\":[\"Лагерь следопытов у границы Диколесья был первым местом в Нордероне, которое выглядело так, будто здесь действительно ждут войны.\",\"Никаких фиолетовых ковров. Никаких синих свечей в золотых канделябрах. Частокол — заострённые брёвна, вбитые в землю плотно, плечом к плечу, как солдаты в строю. Палатки — светлые, эльфийские, конечно, с узором по краю, потому что эльфы не умеют иначе даже здесь, — но поставлены тесно, входами к центру. Посреди лагеря горел костёр. Обычный. Без металлического солнца под брёвнами. Просто огонь, у которого греются люди, которые завтра, может быть, не вернутся.\",\"У частокола стояла баллиста — развёрнутая на север, огромная, деревянная, с натянутым воротом и болтом длиной в мой рост. Я остановилась и посмотрела на неё.\",\"* * *\",\"Мьюру Яркопряд я узнала сразу — не по лицу, по взгляду. Так смотрят те, кто ждал вестей и уже приготовился к плохим.\",\"— Здравствуй, жрица. Ты здесь, чтобы помочь Странникам, или у тебя ко мне есть какое-то дело?\",\"Голова Сапфировой Пасти легла на стол перед ней — тяжёлая, тёмно-синяя, с полуприкрытым глазом и мёртвой, уже не светящейся пастью. Мьюра не отшатнулась.\",\"Она долго смотрела на голову. Потом достала серебряную монету и вложила мне в ладонь, сжав мои пальцы своими. И выложила рядом три кольца.\",\"Тепло опыта поднялось изнутри, и на этот раз я его заметила. Не потому, что стало легче. Потому что за ним стояли Дартелон, его отряд и пещера с грибами.\",\"Я взяла Перстень заклинателя — тонкий, серебристый, с тёмным камнем — и сняла с пальца старое кольцо хранителя мудрости. Чуть крепче стали ноги, чуть яснее голова. Капля здоровья между мной и следующей пастью.\",\"Асценси посмотрел на перстень, потом на меня, и в глазах у него читалось: «опять что-то вкусное для гончих?» Вслух он не сказал. Ему и не надо было.\",\"— Никогда не видела таких созданий, — сказала она тихо. — Неужели их тоже породила магическая энергия Нордерона?\",\"«Тоже». Я услышала это слово. Сначала разлом в Шпиле Рассвета, потом фамильяры, потом пожиратель. Теперь гончие, которые пьют магию. Нордерон был похож на дом, в котором где-то протекает труба, а все делают вид, что пятна на потолке — это такой узор.\",\"— Ответ могут дать только силовые линии. Возьми это устройство и размести его в узлах силы на юге рощи Вечной Весны, чтобы я могла проанализировать магическую активность в регионе и найти источник возможных искажений.\",\"Строчка легла в журнал почти сама: {{«Поиск аномалий». 3 узла. Юг рощи, Лазурный Путь.}}\",\"* * *\",\"Разведчица Эресса стояла у частокола, рядом с баллистой, и смотрела на север. Когда я подошла, она не обернулась сразу. Сначала досмотрела то, что смотрела. Мне это понравилось.\",\"— Это значит, тебя капитан послал нам в помощь? — Она окинула меня взглядом. — Любопытно.\",\"Она отсчитала пятьдесят медяков.\",\"— Боюсь, я не скажу тебе ничего нового, — сказала Эресса. — Численность троллей в Амани'ши растёт вместе с их агрессией. Последние нападения — не более чем проверка нашей обороны. — Она кивнула на частокол. — И без прорицания ясно, что они готовят полномасштабную атаку на рощу.\",\"— Налёты троллей становятся всё более дерзкими, — сказала она. — Из последних четырёх повозок с припасами только одной удалось добраться до места назначения. Остальные захватили тролли и утащили их в свой лагерь на западе отсюда. Если ты отправишься туда и вернёшь нам украденные припасы, Странники будут благодарны тебе.\",\"— Пять ящиков, — добавила она. — Верни их, и я найду, чем отблагодарить.\",\"Асценси хмыкнул. Это был не кашель. Это был одобрительный хмык. Похоже, Эресса ему нравилась.\",\"— И ещё, — сказала она. — К северо-востоку отсюда лежит Диколесье, крупнейшая вотчина лесных троллей за пределами Зул'Амана, и на его границе возвышается застава Амани'ши — мрачное напоминание о том, что мы далеко не одиноки в этих землях. Тролли Диколесья отравляют нам жизнь с момента прибытия в Нордерон, но сейчас их нападения участились, а к заставе стекается всё больше и больше мародёров и охотников за головами. — Она посмотрела на меня в упор. — Как думаешь, Люси, сможешь отправиться к их лагерю и малость сократить численность этих треклятых дикарей?\",\"В журнале появились две новые строчки. {{«Мародёрству — бой!»: ящики, 0 из 5. «Налётчики Амани»: 0 из 8.}} Цифра восемь смотрела на меня со страницы так, будто это не они, а я должна была кончиться.\",\"* * *\",\"Торговцу Ангарилу я сдала всё, что накопилось за эти дни и не было ни едой, ни тканью Рафа, ни рыбой Рафа. Сломанный клык Сапфировой Пасти он повертел и положил к остальному без вопросов. Хорошие торговцы никогда не спрашивают, откуда клык.\",\"* * *\",\"Солнце сползало к западу, и тени от кольев частокола легли на траву длинными полосами, как прутья решётки. Костёр в центре лагеря разгорелся сильнее. Кто-то из следопытов чистил лук. Кто-то молча ел. Баллиста смотрела на север.\",\"Мы пошли к воротам.\"],\"plates\":[{\"after\":11,\"alt\":\"— Никогда не видела таких созданий, — сказала она тихо. — Неужели их тоже породила магичес\",\"src\":\"/chronicle/tome/032.jpg\"}]},{\"id\":\"g2-07\",\"numeral\":\"7\",\"title\":\"Часть 7\",\"kicker\":\"Глава 2\",\"dek\":\"Диколесье начиналось не с границы. Оно начиналось с запаха.\",\"paragraphs\":[\"Диколесье начиналось не с границы. Оно начиналось с запаха.\",\"Золото рощи кончилось как-то сразу, будто кто-то провёл черту. Вместо белых стволов — ели, тёмные, мрачные, с ветками до земли. Вместо медовых пятен на траве — серый, влажный свет, который пробивался сквозь хвою неохотно, как гость, которого не звали. Трава стала жёстче и темнее. А в воздухе повис запах дыма, гнилого дерева и чего-то кислого, звериного — так пахнет логово, в котором давно никто не убирал.\",\"Дорога была. Мощёная, старая, из крупного серого камня, — только мостили её явно не эльфы. Камни лежали криво, тяжело, с широкими щелями, в которых росла трава. Вдоль дороги торчали жаровни на шестах, и в них горел огонь. Днём. Чтобы было видно издалека: здесь кто-то живёт и этот кто-то не прячется.\",\"Застава Амани'ши.\",\"* * *\",\"Первый налётчик вышел к нам у разбитой повозки.\",\"Повозка лежала на боку, колёса вверх, вокруг — щепки и обрывки мешковины. Одна из тех четырёх, наверное. Одна из трёх, что не дошли. Я успела подумать об этом, а потом тролль поднял голову.\",\"Высокий. Выше Рафа на голову. Кожа зелёная, с синеватым отливом, длинные руки, сутулые плечи, а из-под губы — клыки, загнутые вверх, жёлтые, как старая кость. Десятый уровень. На два выше меня. В руке — что-то, что когда-то было топором, а теперь было просто тяжёлым и острым.\",\"Раф пошёл вперёд. Щит, удар, звон.\",\"Свет пришёл в ладонь неохотно — пальцы ещё ныли после опушки, — и Кара ударила тролля коротко и жёстко, как пощёчина. Он дёрнулся, но не повернулся ко мне: Раф держал его крепко. Я добавила Боль, потом ещё Кару. Стрелы Асценси свистели мимо, и каждая находила зелёную шкуру.\",\"Тролль падал долго. Живучие — это я поняла сразу, по тому, как он ещё шевелил пальцами, когда должен был уже лежать. Он рухнул у колеса повозки, лицом в траву, и топор выпал из его руки.\",\"* * *\",\"Второй налётчик пришёл сам — услышал первого. Третий пришёл на крик второго. Это была их тактика, если её можно так назвать: каждый, кто умирал, звал следующего.\",\"{{Налётчики — 2 из 8}}, — записала я на ходу, прижимая журнал к щиту Рафа. Буквы прыгали.\",\"Руины. Не эльфийские — тролльи. Огромные каменные строения, тяжёлые, угловатые, из серо-бурого камня, с резьбой, от которой веяло чем-то древним и злым. Лица. На стенах были вырезаны лица — широкие, с оскаленными ртами, с круглыми пустыми глазами, обведёнными бирюзовой краской, которая облупилась от времени. Идолы. Они смотрели на дорогу. На нас.\",\"Асценси остановился перед ближним идолом. Не оглядываясь на нас, провёл пальцами по резьбе — по клыкам, по завиткам вокруг глаз, — так, как гладят чужую работу, которую уважают. Потом пошёл дальше. Для Асценси это была целая лекция по искусствоведению.\",\"У подножия одного из идолов, прямо под его оскаленной мордой, стоял ящик.\",\"Деревянный, крепкий, с металлическими уголками — эльфийской работы. Здесь, среди троллей, он выглядел так же неуместно, как я сама. Ящик с украденными припасами. Один из тех, за которыми нас послала Эресса.\",\"Я подняла крышку. Внутри были припасы. И — среди них, будто кто-то из троллей положил их на сохранение — сапоги. Кожаные, тёмные, с узором, вытисненным по голенищу. Письмена. Не тролльи — что-то другое, аккуратное, с завитками.\",\"Я молча протянула сапоги Асценси: ткань — мне, кожа — ему, так у нас повелось.\",\"Раф всё-таки настоял на кости, чтобы было честно. Асценси выбросил шестьдесят, я — двадцать четыре, из вежливости. Сапоги ушли к тому, к кому и должны были.\",\"* * *\",\"Дальше застава менялась.\",\"Каменные руины кончились, и пошёл лагерь. Живой, грязный, настоящий. Шатры — огромные, из шкур, натянутых на каркасы, а у входов — бивни. Белые, изогнутые, высотой в два моих роста, воткнутые в землю парами, как ворота. Чьи бивни, я не хотела знать. Между шатрами — частокол, тёмный, из грубых брёвен. Жаровни. Кости. Какие-то стойки с чем-то, что сушилось и пахло так, что я начала дышать ртом.\",\"Налётчики не кончались. Мы убивали одного — выходил другой. Убивали другого — с другой стороны дороги уже бежал третий. Я перестала считать удары и считала только ману. Она уходила и возвращалась, уходила и возвращалась — медленнее, чем мне хотелось, быстрее, чем раньше. Перстень заклинателя и кушак работали. Тихо, незаметно, на глоток. Глоток за глотком.\",\"А потом я увидела его.\",\"Он был в глубине лагеря, у самого большого шатра, между двумя бивнями. Крупнее всех налётчиков, что я видела. Шире в плечах. Кожа ярко-зелёная, почти ядовитая. Красная грива — или то, что тролли считают гривой. И что-то в том, как он стоял, как держал голову, сразу говорило: этот — главный. Не потому, что так решили. Потому что все остальные так решили, когда увидели его.\",\"Он не сразу заметил нас. Он стоял на коленях перед идолом — огромным, с оскаленной деревянной пастью — и мазал чем-то тёмным его клыки. Губы у него шевелились. Слов я не понимала, ни одного, кроме того, что он повторял чаще других, нараспев, будто звал кого-то по имени: «Лоа… лоа…» Потом бросил в жаровню щепоть чего-то, и пламя вспыхнуло зелёным, и он закрыл глаза, как закрывают, когда просят. Он просил. У кого-то большего, чем он сам, — за свой лагерь, за своих налётчиков, за то, чтобы мы не пришли.\",\"Мы пришли.\",\"Мон'земби. Одиннадцатый уровень. И то же самое, что я чувствовала у Сапфировой Пасти, — холодок по спине. Мир отмечал его отдельно. Опасный. Сильнее, чем просто цифра.\",\"Мон'земби повернул голову. Увидел нас. И заорал так, что у меня заныли зубы.\",\"Раф пошёл ему навстречу.\",\"* * *\",\"Раф — впереди, щит поднят, и Мон'земби врезается в него всем весом, и Раф отъезжает на полшага по мокрым камням, но не падает. Звон. Хрип. Опять звон.\",\"Кара. Свет ложится на ярко-зелёное плечо, и тролль даже не оглядывается — он занят Рафом, и это хорошо, это правильно, так и должно быть. Боль уходит в него, и у меня самой немеют кончики пальцев, как будто я сунула их в снег.\",\"Сбоку — налётчик. Ещё один. Десятый уровень, выбежал из-за шатра, и на мгновение я вижу его только краем глаза и думаю: всё. Вот оно. Сейчас он доберётся до меня, пока Раф держит большого, и у меня одна жизнь, и это будет очень глупо.\",\"Асценси разворачивается. Одна стрела — в налётчика. Тот спотыкается, ревёт, бежит уже к Асценси, не ко мне.\",\"Внутри пусто, как в вычерпанном колодце. Я слышу собственное дыхание — громкое, частое. Раф отступает ещё на полшага. Щит у него в руке дрожит. Тролль бьёт снова, и я вижу, как у Рафа подгибается колено.\",\"Мон'земби вздрагивает. Медленно, тяжело поворачивает голову — ко мне. Впервые. Глаза — маленькие, красные, злые.\",\"Я стою. Не бегу. Не потому, что храбрая. Потому что если я побегу, он побежит за мной, и Раф не успеет.\",\"Он падает.\",\"Не красиво. Не эпично. Просто его ноги перестают держать, и он валится вперёд, на камни, у самых ног Рафа, и земля под ним вздрагивает. Красная грива ложится в грязь.\",\"Я опускаю руку, нахожу налётчика — он ещё жив, он бьёт Асценси, — и бью его. Кара. Асценси добивает.\",\"* * *\",\"Я подошла к Мон'земби последней. Как к Сапфировой Пасти. Как, наверное, буду подходить ко всем, кто чуть меня не убил: последней, медленно, чтобы убедиться, что он не встанет.\",\"Я нагнулась и подняла её. Голову Мон'земби. Окровавленную и отвратительную. Что она для чего-то нужна, я поняла по тому, как бережно тролли украсили её бусинами, — и только поэтому не бросила её обратно в грязь. Я завернула её в обрывок шкуры, что валялся рядом, и она всё равно пачкала руки.\",\"Асценси подошёл — новые сапоги уже были на нём, быстро — посмотрел на свёрток, потом на меня. Бровь поползла вверх. Я перевела: «Коллекцию собираешь?»\",\"— Я не собираю. Меня заставляют. — Я посмотрела на свёрток. — И, честно говоря, я даже не знаю, кому её нести. Мне её никто не заказывал.\",\"Раф стоял над тушей, опираясь на щит. Дышал тяжело. На щите появились новые вмятины — глубокие, рваные.\",\"— Цел? — спросила я.\",\"— Цел.\",\"— Колено?\",\"— Цело.\",\"— Врёшь.\",\"— Немного.\",\"И из-за шатра вышел следующий.\",\"Он был моложе остальных — я это видела по клыкам, коротким, ещё не пожелтевшим. Он посмотрел на тело Мон'земби у ног Рафа. Посмотрел на нас. И разжал пальцы. Топор упал на камни. Секунду, две — он просто стоял, и руки у него висели, как у того, кто не знает, куда их деть.\",\"Из глубины лагеря кто-то рявкнул. Одно слово, хлёсткое, как плеть. Молодой вздрогнул, наклонился, поднял топор и пошёл на нас — не бегом, шагом, будто на работу, которую ненавидит.\",\"Он упал, как падали все. Я так и не узнала, что значило то слово. Но я видела его руки, и его руки не хотели этой войны. В сумке у него, когда я заставила себя посмотреть, были только сушёные ягоды и резная деревянная рыбка. Маленькая, неумелая. Детская.\"],\"plates\":[{\"after\":19,\"alt\":\"Я молча протянула сапоги Асценси: ткань — мне, кожа — ему, так у нас повелось.\",\"src\":\"/chronicle/tome/033.jpg\"},{\"after\":27,\"alt\":\"Он не сразу заметил нас. Он стоял на коленях перед идолом — огромным, с оскаленной деревян\",\"src\":\"/chronicle/tome/034.jpg\"},{\"after\":39,\"alt\":\"Я стою. Не бегу. Не потому, что храбрая. Потому что если я побегу, он побежит за мной, и Р\",\"src\":\"/chronicle/tome/035.jpg\"}]},{\"id\":\"g2-08\",\"numeral\":\"8\",\"title\":\"Часть 8\",\"kicker\":\"Глава 2\",\"dek\":\"Следующего мы уложили. И того, что за ним. А потом застава на какое-то время затихла — не сдалась, нет, просто\",\"paragraphs\":[\"Следующего мы уложили. И того, что за ним. А потом застава на какое-то время затихла — не сдалась, нет, просто перевела дух, как зверь, который отполз в кусты зализывать раны и ждёт, когда ты повернёшься спиной.\",\"Мы не стали поворачиваться. Мы ушли в сторону.\",\"За заставой лес опускался к воде. Ели здесь стояли редко, но были огромными — такими, что я задирала голову и не видела верхушек, только тёмные лапы хвои где-то наверху и серое небо между ними. Стволы — в три обхвата, бурые, морщинистые, как кожа старика. Корни выползали из земли и снова уходили в неё, и между ними росли грибы — мелкие, рыжие, на тонких ножках. В траве желтели цветы. Совсем обычные. После идолов с пустыми глазами я была им почти благодарна.\",\"Опушка обрывалась к воде. Озеро или река — я не поняла. Гладкое, серое, неподвижное, и над ним висела дымка. Берег — песчаный, пологий, с камнями.\",\"Оно ползло к нам от воды. Медленно. Неторопливо. Как ползёт тот, кому некуда спешить, потому что всё, что он хочет съесть, никуда не денется.\",\"У самой воды лежал плоский камень, и на нём — рыбьи кости, перья, бусина на шнурке и резная палочка с завитком, похожим на змею. Не мусор. Кто-то раскладывал это аккуратно, рядком, как раскладывают на столе для гостя. Свежая рыба лежала с краю — ещё блестела.\",\"Змей подполз к камню раньше, чем к нам. Взял рыбу — не жадно, по-хозяйски, как берут своё. И только потом поднял голову и посмотрел на нас: на тех, кто ничего не принёс.\",\"Змей.\",\"Длинный — длиннее, чем я сначала поняла, потому что часть его тела всё ещё оставалась в траве у берега, когда голова уже поднялась над песком. Чешуя — бурая, с жёлтым узором, ромбами по спине. Голова широкая, плоская, и над ней — что-то вроде гребня. Он поднимал её высоко, на уровень моего лица, и покачивал ею из стороны в сторону. Медленно. Гипнотически.\",\"Шшеракс. Имени я тогда не знала — узнала потом, с плаката у Келмарина. Но шипел он именно так: ш-ш-ш-ракс. Десятый уровень. И тот же холодок по спине — мир снова отмечал кого-то отдельно.\",\"Я вскинула ладонь — и Кара не дотянулась, рассыпалась в воздухе, как искры от сырого полена. Змей зашипел — длинно, влажно, — и пополз быстрее.\",\"Раф шагнул вперёд.\",\"* * *\",\"Это был не бой с гончими и не бой с Мон'земби. Змей не бил. Змей обвивал, бросался, отдёргивался. Он двигался так, что я не всегда понимала, где кончается его тело и начинается тень от ели.\",\"Раф встретил его щитом. Голова змея ударила в металл с глухим стуком, отдёрнулась и ударила снова — сбоку, низко, туда, где щита не было. Раф развернулся. Успел.\",\"Кара. Свет вонзился в чешую между ромбами, и змей дёрнулся, свился кольцом — и снова развернулся к Рафу. Хорошо. Так и надо.\",\"Слово Тьмы: Боль. Холод сорвался с пальцев и ушёл под чешую, и у меня самой заныло под ложечкой: Боль всегда немного отдаёт назад.\",\"Асценси стрелял с края опушки. Стрелы входили змею в бок, и каждый раз он шипел громче.\",\"Я била, пока руки не отяжелели так, будто к локтям привязали по камню. Земля под ногами была мягкой, корни — скользкими, и я старалась стоять там, где можно было отступить, не запнувшись.\",\"Змей поднял голову высоко, выше, чем раньше. Раскрыл пасть. Я увидела клыки — длинные, изогнутые, влажные, — и на мгновение подумала, что сейчас он ударит меня. Через Рафа. Через щит. Просто сверху.\",\"Раф ударил первым. Щитом — снизу вверх, под челюсть.\",\"Голова мотнулась в сторону.\",\"Кара.\",\"Шшеракс рухнул на песок, и его длинное тело ещё долго дёргалось, свиваясь и развиваясь, будто не могло поверить, что всё. Потом затихло.\",\"* * *\",\"Голова лежала на песке — плоская, тяжёлая, с полуоткрытой пастью. Из пасти торчал клык. Один — второй, видимо, сломался о щит Рафа. Я присела, достала нож и очень, очень осторожно, обмотав руку плащом, выломала его. Клык Шшеракса. Тяжёлый, и на нём ещё остался яд: на кончике дрожала мутная капля. Я завернула его в тряпку. Потом ещё в одну. Потом подумала и положила в сумку подальше от рыбы Рафа.\",\"Раф тем временем ковырялся у камней на берегу. Наклонился, поднял что-то, повертел, сунул в сумку. Снова наклонился.\",\"Потом показал мне на ладони: грубый камень и кусок медной руды. Выпрямился, посмотрел на мой свёрток спокойно.\",\"— Ты носишь головы, — сказал он. — Я ношу камни. Каждому своё.\",\"Перед уходом я ещё раз оглянулась на плоский камень с рыбьими костями. Тролли кормили его. Может, задабривали, может, молились, может, просто привыкли, как привыкают к старому псу у ворот. Завтра кто-то из них придёт сюда с рыбой — и найдёт пустой берег.\",\"Клык лежал у меня в сумке. Я впервые подумала, что у каждой головы, которую я ношу, есть кто-то, кто её ждал. Не меня — её.\",\"* * *\",\"Мы вернулись на заставу.\",\"Она ждала нас такой же, какой мы её оставили: мощёная площадь из серого камня, тяжёлого, с круглым узором, вытесанным прямо в плитах, как огромная печать. Строения из бурого камня. Факелы на шестах. И шатёр — высокий, с каменными столбами по бокам, а над входом красное знамя с золотым узором — тот самый узор, что я видела на полотнищах, только здесь он был больше. Как вывеска. Как герб.\",\"Я открыла журнал — настоящий, в потёртой обложке, с пятном от ягодного сока на третьей странице. Я веду его с первого дня: если не записывать, кажется, что ничего не было. Голова Мон'земби и клык — Келмарину.\",\"Ящики — все пять. Это я помнила без журнала, потому что каждый из них открывала сама, под оскаленными мордами идолов, оглядываясь через плечо. Эресса получит свои припасы.\",\"Будто услышав, из-за шатра вышел ещё один.\",\"Девятый уровень. Ниже Мон'земби, ниже Шшеракса, ниже всех, кого мы сегодня видели. Но всё так же зелёный, всё так же с клыками, всё так же с топором. И всё так же — орущий.\",\"Кара.\"],\"plates\":[{\"after\":5,\"alt\":\"У самой воды лежал плоский камень, и на нём — рыбьи кости, перья, бусина на шнурке и резна\",\"src\":\"/chronicle/tome/036.jpg\"},{\"after\":28,\"alt\":\"— Ты носишь головы, — сказал он. — Я ношу камни. Каждому своё.\",\"src\":\"/chronicle/tome/037.jpg\"}]},{\"id\":\"g2-09\",\"numeral\":\"9\",\"title\":\"Часть 9\",\"kicker\":\"Глава 2\",\"dek\":\"Налётчик девятого уровня умер как червяк.\",\"paragraphs\":[\"Налётчик девятого уровня умер как червяк.\",\"Кара, Слово Тьмы: Боль, щит Рафа, два удара меча — и он уже лежал у шатра, раскинув руки, так и не доорав свою боевую песню. После Мон'земби и Шшеракса это было почти обидно. Будто его вывели из-за шатра специально под финальную сцену, назвали вожаком за компанию и забыли сделать живучим.\",\"* * *\",\"Камень я заметила не сразу.\",\"Поляна была такая, какие в Нордероне попадаются на каждом шагу: трава по щиколотку, слишком зелёная, чтобы быть настоящей, стволы в три обхвата, солнце сквозь кроны пятнами. Под ногами жёлтые цветы. Красиво до неприличия. Здесь хочется сесть, вытянуть ноги и забыть, что где-то за деревьями стоят идолы с оскаленными мордами.\",\"А посреди всего этого торчал серый камень. Узкий, острый кверху, как наконечник копья, воткнутый в землю. Над ним бледно светилось что-то вроде огонька.\",\"— Надгробие, — сказал Раф. Подумал и добавил: — Не наше.\",\"Я подошла ближе. Камень оказался читаемым — в этом мире читается всё, что не убегает. На тёмной гладкой стороне кто-то вырезал строчки, ровно, аккуратно, как вырезают тогда, когда больше ничего сделать нельзя.\",\"\\u0001[[Малкарион (10-го уровня)]]\",\"\\u0001[[Малкарион, высший эльф 10-го уровня, был убит существом Мон'земби 11-го уровня в зоне «Нордерон»]]\",\"Я прочитала. Потом ещё раз — медленно, как читают, когда очень надеются, что в первый раз ошиблись.\",\"Сумка на боку вдруг стала тяжелее. Там, в свёртке, лежала голова. Та самая. Одиннадцатого уровня, с теми же клыками, которые где-то здесь, на этой самой траве, закончили чью-то единственную жизнь.\",\"— Кто-нибудь его знал? — спросила я сама не знаю у кого.\",\"Я стояла и смотрела на чужие угловатые буквы имени. Кто-то его так назвал. Кто-то, наверное, произносил это имя ласково, сокращал, звал к ужину. А он однажды пришёл сюда, в Нордерон, такой же пилигрим, как я. Обрадовался. Сделал первые шаги по Анклаву Странников, получил первое задание, первую тряпку, первый уровень. Потом второй. Потом десятый.\",\"А потом — поляна. Жёлтые цветочки. Тролль с топором.\",\"Ни «попробуй ещё раз», ни второго шанса. Здесь после этой строки ничего нет. Только камень, огонёк и одна фраза для тех, кто придёт следом и захочет прочитать.\",\"Значит, дело не в уровне. Дело в том, что нам повезло. Или в том, что нас было трое. Или в том, что Раф вовремя подставил щит. Или ещё в чём-то, чего я не знаю, — и вот это «не знаю» пугало сильнее всего.\",\"У подножия, там, где камень уходил в траву, был ещё один знак. Не такой, как надпись сверху, — ровная, гладкая, будто её не вырезали, а она проступила сама. Этот знак кто-то процарапал ножом, криво, глубоко, в несколько заходов: «Дождись». Ниже — три чёрточки. Свежие.\",\"Кто-то вернулся сюда. Кто-то, кто его знал, приходил и не мог ничего сделать, кроме как поцарапать камень. Или трое кого-то.\",\"— Кто их ставит? — спросила я. — Камни. Надписи.\",\"Раф пожал плечами — не как тот, кто не знает, а как тот, кому никогда не приходило в голову спросить.\",\"— Никто. Они просто… есть. Там, где кто-то упал. Всегда так было.\",\"«Всегда так было» — это не ответ. Но больше никто вокруг меня, похоже, его и не искал. Я посмотрела на ровную надпись сверху — «10-го уровня» — и на кривое «Дождись» внизу. Одно написал мир. Другое — человек. Мне почему-то очень захотелось знать, кто из них прав.\",\"За кустами справа что-то шевельнулось. Я дёрнулась так, что чуть не уронила посох.\",\"Из травы поднялась сутулая фигура с силками на поясе, и по раскраске на лице я узнала: [[Зверолов Амани]].\",\"— Пошли, — сказал Раф тихо. — Он тут не один такой.\",\"— Я знаю. — Я ещё раз посмотрела на камень. — Спи, Малкарион. Мы за тебя… в общем, мы его уже.\",\"* * *\",\"Лагерь встретил нас костром.\",\"Обычным, из поленьев, обложенным камнями. Над огнём дрожал воздух, рядом росло деревце с листвой такого жёлтого цвета, будто осень решила начаться здесь, отдельно от остального леса. За ним стоял частокол — светлые брёвна, поставленные плотно, как зубы. Горел факел.\",\"У костра стояла Разведчица Эресса. Высшая эльфийка, светлые волосы, тот взгляд, каким смотрят на новобранцев, когда новобранцы неожиданно вернулись живыми. Она заметила меня издалека и чуть подалась вперёд, и я вспомнила: мне есть что ей сказать.\",\"Чуть поодаль, у маленькой палатки с сундуком, дежурил [[Следопыт Нордерона]]. Зелёный плащ, меч, лицо человека, которому платят за то, чтобы он стоял ровно. Стоял он ровно.\",\"Я рассказала ей про налётчиков. Эресса выслушала, глядя в огонь, и сказала, не поднимая головы:\",\"— Славно. Это даст нам немного времени, чтобы начать атаку на Диколесье.\",\"Она выставила передо мной три пары обуви. Ткань среди них была одна — Дикарские сандалии. Самое смешное, что на мне сейчас были тоже «Дикарские сандалии». Тёзки. Только мои — младшая сестра, бедная родственница.\",\"Эресса отдала мне сандалии. Вечером в журнале я хотела написать что-нибудь про Малкариона. Не написала. Карандаш не шёл.\",\"Потом я поставила перед ней ящики. Все пять, по одному, тяжело, с грохотом, и только когда поставила последний, поняла, как ныли руки.\",\"Она выложила плащи. Тонкотканый был лёгким, как дыхание, и прибавлял ума — а ум у жрицы это мана, Кара и, главное, лечение. Без маны жрица — просто эльфийка с палкой. Старая «Мантия геодезиста» не прибавляла ничего, кроме чувства долга.\",\"Эресса сама набросила плащ мне на плечи и застегнула пряжку, как застёгивают ребёнку перед выходом на холод. Потом вложила в ладонь серебряную монету. Я не нашлась, что сказать.\",\"* * *\",\"Вечером Раф сидел у костра Эрессы и тёр куском замши тот самый грубый камень с берега, где умер Шшеракс. Тёр так, будто от этого зависело что-то важное.\",\"— Ты всё-таки его не выбросил, — сказала я.\",\"— Его нельзя выбрасывать. Он ещё не открылся. — Раф повернул камень к огню. — Снаружи они все скучные. Серые, кривые, как картошка. А потом снимаешь корку — и там вот такое. — Он показал ногтем тонкую зелёную жилку. — Отец говорил: камень всегда честнее того, кто его продаёт.\",\"— Твой отец продавал камни?\",\"— Резал. Гранил. Чинил кольца жёнам, которые думали, что мужья не заметят. Мужья всегда замечали, кстати. Им просто было приятнее, что заметил кто-то другой. — Он хмыкнул. — У нас в доме пахло полировочной пастой и луком. До сих пор, когда кто-то жарит лук, я тянусь за замшей.\",\"— А меч?\",\"— Меч был потом. — Раф посмотрел на камень, потом на огонь. — Это длинная история, а у Эрессы короткие дрова. Потом.\",\"Асценси сидел напротив и молча крутил в пальцах крышку фляги. Медведя у него тогда ещё не было, и руки ему было некуда девать.\",\"А я поймала себя на том, что тихо мычу какой-то мотив. Три ноты вниз, одна вверх. Я не знала, откуда он. Попробовала вспомнить следующую ноту — и мотив рассыпался, как сухой лист в пальцах. Осталось только ощущение, что кто-то когда-то пел это рядом со мной. Кто — не было.\",\"— Красиво, — сказал Раф. — Что это?\",\"— Не знаю, — сказала я. И это была правда, от которой стало холодно у самого огня.\",\"Я оглянулась туда, откуда мы пришли. За частоколом, за деревьями, на поляне с жёлтыми цветами стоял серый камень. Малкарион тоже, наверное, когда-то стоял у этого костра. Выбирал между сандалиями и сапогами. Радовался новому плащу.\"],\"plates\":[{\"after\":15,\"alt\":\"Ни «попробуй ещё раз», ни второго шанса. Здесь после этой строки ничего нет. Только камень\",\"src\":\"/chronicle/tome/038.jpg\"},{\"after\":30,\"alt\":\"У костра стояла Разведчица Эресса. Высшая эльфийка, светлые волосы, тот взгляд, каким смот\",\"src\":\"/chronicle/tome/039.jpg\"},{\"after\":42,\"alt\":\"— Его нельзя выбрасывать. Он ещё не открылся. — Раф повернул камень к огню. — Снаружи они \",\"src\":\"/chronicle/tome/040.jpg\"}]},{\"id\":\"g2-10\",\"numeral\":\"10\",\"title\":\"Часть 10\",\"kicker\":\"Глава 2\",\"dek\":\"Лагерь жил своей жизнью, и кое-что в ней изменилось — я заметила это не сразу. Двое следопытов собирались на с\",\"paragraphs\":[\"Лагерь жил своей жизнью, и кое-что в ней изменилось — я заметила это не сразу. Двое следопытов собирались на север, к Диколесью, — без спешки, без лишних взглядов через плечо. Ещё неделю назад туда не ходили по двое. Один из них, проходя мимо, коротко кивнул мне. Не как жрице. Как тем, кто принёс голову Сапфировой Пасти. Я не знала, что с этим кивком делать, и просто кивнула в ответ.\",\"У палатки стояла [[Мьюра Яркопряд]]. Она смотрела на меня так, как смотрят на того, кто пришёл очень вовремя, — значит, для меня есть работа. Для меня всегда есть работа. Это единственное, в чём этот мир стабилен.\",\"— Магия — это ужасающая сила в руках опытного заклинателя, — сказала Мьюра, не тратя времени на приветствие. — Клинок же — мощное оружие даже в самых неумелых руках. Уж не знаю как, но тролли заполучили оружие, которое усилено сильными магическими чарами. Нужно лишить их этого преимущества. Укради у них столько, сколько сможешь.\",\"— «Даже в самых неумелых руках», — повторила я. — Это она про троллей или про меня?\",\"— Про троллей, — сказал Раф. — Ты клинки не носишь. Ты носишь посох для вида и Кару для дела.\",\"— Шесть, — добавила Мьюра. — Шесть осенённых лоа клинков. Больше ты всё равно не унесёшь.\",\"Карандаш вывел: {{«Опасное оружие». 6 клинков. 0 из 6.}}\",\"— За это, — Мьюра кивнула на ящик у палатки, — выберешь себе что-нибудь. Сокрушитель черепов, Посох Благородных… там ещё есть.\",\"* * *\",\"У костра меня перехватила Эресса.\",\"— В чащобах тебе наверняка встретятся звероловы из воинства Амани, — сказала Эресса, и голос у неё стал жёстче. — Они натренированы убивать — топорами, когтями или при помощи укрощённых ими зверей. Для этого тролли используют особые снадобья, вводят своих питомцев в исступление перед боем. Нам нужно, чтобы ты убила всех звероловов, каких только встретишь. Нельзя допустить, чтобы агрессия троллей осталась безнаказанной.\",\"Асценси качнул головой. Один раз, коротко, и опустил руку на лук.\",\"Мы с Рафом обернулись одновременно. Асценси не говорит, но и «нет» — даже без слов — я от него не видела ни разу.\",\"— Он охотник, — сказал Раф медленно, будто переводил. — А они — звероловы. Ты хочешь, чтобы охотник шёл убивать других охотников за то, что они ловят зверей?\",\"— Я ничего не хочу, — сказала я. — Я хочу понять, сколько это стоит. Шесть троллей — это шесть боёв. Шесть раз, когда кто-то из нас может не успеть.\",\"— Они поят зверей снадобьями, — сказала Эресса. — Чтобы те бесились перед боем. Рысь, которая выпила это, грызёт собственные лапы, пока не доберётся до тебя.\",\"Асценси долго смотрел на неё. Потом отвинтил флягу, сделал один глоток и кивнул. Только раз. Этого было достаточно.\",\"— Ладно, — сказала я. — Тогда за рысей. Не за награду.\",\"{{«По следу дикого зверя». 6 звероловов.}} Я закрыла журнал и почувствовала, как холодеет под ложечкой.\",\"Раф проверял щит, как проверяют дверь перед уходом: дёрнул ремень, постучал костяшками по краю. Асценси молча стоял рядом и смотрел за частокол, туда, где начинался лес.\",\"Мы вышли за ворота.\"],\"plates\":[{\"after\":17,\"alt\":\"— Ладно, — сказала я. — Тогда за рысей. Не за награду.\",\"src\":\"/chronicle/tome/041.jpg\"}]},{\"id\":\"g2-11\",\"numeral\":\"11\",\"title\":\"Часть 11\",\"kicker\":\"Глава 2\",\"dek\":\"Задание называлось «Поиск аномалий», и, честно говоря, это было самое мирное, что мне предлагали со дня рожден\",\"paragraphs\":[\"Задание называлось «Поиск аномалий», и, честно говоря, это было самое мирное, что мне предлагали со дня рождения в этом мире. Никого не убивать. Ничего ни у кого не отбирать. Просто поставить три прибора в трёх местах и уйти.\",\"Мьюра вложила мне в руки силовой анализатор и объяснила, как с ним обращаться: поставить в узле силовой линии, отойти, подождать — второй можно ставить не раньше чем через десять ударов сердца.\",\"— Он ваш и только ваш, — сказала она. — И предупреждаю: на месте установки он даст мощный луч света.\",\"* * *\",\"Первые два узла обошлись без происшествий. В руинах с серо-синими колоннами из камня ударил в небо голубой луч — мощный, как и обещали, я машинально пригнулась. В берёзовой роще у озера анализатор засветился фиолетовым, тихо, как ночник. К воде я не подходила: после Шшеракса у меня с водой сложные отношения.\",\"* * *\",\"Третье место было у пещеры.\",\"Я поставила анализатор у самого входа. Быстро. Не глядя внутрь.\",\"— Всё, — сказала я. — Уходим. Сейчас же. Пока то, что там внутри, не решило, что мы ему интересны.\",\"Асценси пошёл первым, не дожидаясь второго приглашения.\",\"* * *\",\"Капитан Келмарин ждал нас в Анклаве.\",\"Он развернул свёрток и долго смотрел на голову. Потом сказал, медленно, словно каждое слово ему приходилось вытаскивать изнутри:\",\"— Мон'земби был настоящим проклятьем для Странников. Этот треклятый переросток мог голыми руками разорвать оленя. Можешь себе представить, что он делал с эльфами. К тому же его бесчинства внушали прочим троллям уверенность в своих силах. — Он закрыл свёрток. — Хвала Солнцу, с этой угрозой наконец покончено.\",\"Могу, капитан. Я видела камень на поляне. Малкарион. Десятый уровень. Я не стала ему рассказывать — в его лице для этого не было места.\",\"Из того, что он выложил, я взяла Лунокаменный жезл — прохладный даже в руке, быстрее и злее моего старого Жезла Хранителя энергии.\",\"И тут меня накрыло.\",\"Тёплая волна снизу вверх, от новых сандалий до макушки. Золотое сияние вокруг, на секунду ярче очага. Внутри что-то щёлкнуло и встало на место, как будто меня перекроили по чуть большему размеру.\",\"Девятый. Я не прочитала это. Я это почувствовала. Как чувствуют утро, не открывая глаз.\",\"Малкарион был десятым.\",\"* * *\",\"Второй свёрток — клык.\",\"— Ты поборола Шшеракса? Я впечатлён, Люси. Это чудовище попортило немало крови моим следопытам — и в прямом, и в переносном смысле слова. Однако непохоже, чтобы тролли его боялись, и это немного беспокоит: не хватало ещё, чтобы против нас ополчились ещё и звери Диколесья. — Он убрал клык. — Впрочем, теперь в этих землях стало на одну угрозу меньше. Вот твоя награда.\",\"Он выставил на стол четыре вещи, и одна из них — Резная хрустальная сфера, для левой руки, с умом внутри — посмотрела на меня. А я посмотрела на свой посох.\",\"Посохом я не воюю — машу для вида, а бью Карой и Болью. А ум — мана. Мана — лечение. Лечение — Раф живой.\",\"— Для правой руки придётся что-то искать, — сказала я.\",\"— Найдёшь, — сказал Раф.\",\"— Это не ответ. Это надежда.\",\"Я всё равно выбрала сферу.\",\"Келмарин вложил мне сферу в ладонь, а сверху — горсть монет, которую я не стала пересчитывать при нём. В журнале, отдельной строчкой: {{Мон'земби — сдан. Лунокаменный жезл. Малкарион, я принесла.}}\",\"Я посмотрела на огонь в золотом круге. Сфера в руке была холодной, и мне вдруг очень захотелось, чтобы кто-нибудь сказал, что я всё делаю правильно. Что эта жизнь, в которую я проснулась, — правда моя.\",\"Никто не сказал.\"],\"plates\":[{\"after\":18,\"alt\":\"Девятый. Я не прочитала это. Я это почувствовала. Как чувствуют утро, не открывая глаз.\",\"src\":\"/chronicle/tome/042.jpg\"}]},{\"id\":\"g2-12\",\"numeral\":\"12\",\"title\":\"Часть 12\",\"kicker\":\"Глава 2\",\"dek\":\"Мьюра Яркопряд стояла у своей палатки, рядом с баллистами, и, увидев меня, перестала теребить рукав. Значит, я\",\"paragraphs\":[\"Мьюра Яркопряд стояла у своей палатки, рядом с баллистами, и, увидев меня, перестала теребить рукав. Значит, я принесла то, что она ждала.\",\"Мьюра долго смотрела на свои записи, хмурилась, перечитывала. Потом сказала, не мне даже, а куда-то в воздух:\",\"— Как странно… Приборы фиксируют полное отсутствие магической активности в одном из узлов. Но это невозможно! Подобные мёртвые зоны могли образоваться только в регионе с полным отсутствием силовых линий или… — она подняла на меня глаза, — или если кто-то намеренно искажает показания приборов, чтобы укрыться от любопытных глаз.\",\"Она поставила на ящик зелья: пять маленьких флаконов с лечебным и пять слабых зелий омоложения — выбирай. Положила сверху серебряную монету. А потом, подумав, добавила пять зелий скорости — просто так, от себя.\",\"Что я взяла из двух других, потом не смогла вспомнить даже по журналу: строчка там смазалась. Зато была приписка: {{Мьюра дала скорость просто так. Она знает, что мне нужно убегать.}}\",\"Тепло опыта прошло по телу — короткое, привычное. Потом всё снова стало обычным: забор, баллисты, Мьюра со своим тревожным лицом. В отличие от некоторых узлов силовых линий.\",\"* * *\",\"Хранитель рун Нимриэль ждал у колонн.\",\"— Что это у тебя? — спросил он и протянул руку. Не за мной, за камнем. За камнем фамильяра.\",\"Он взял камень и сказал «спасибо» одними глазами. Вечером я запишу: {{«Рунический оберег» — отдан камень. Опыт 440.}}\",\"А потом Нимриэль посмотрел на меня ещё раз, по-другому.\",\"* * *\",\"— Знаешь ли ты, чем мы здесь заняты, Люси? — спросил Нимриэль и, не дожидаясь ответа, обвёл рукой рунный камень. — Испокон веков рунные камни оберегали границы Кель'Таласа, отпугивая суеверных троллей с их примитивным колдовством, а также защищая королевство от очей Легиона. Элессар должен был стать первым рунным камнем Нордерона. Вообрази, какая великая честь — трудиться над подобным делом!\",\"Он помолчал, и голос у него стал тише:\",\"— К несчастью, тайны, стоящие за созданием рунных камней, утеряны в пламени былых войн, и нам приходится опытным путём перебирать всевозможные комбинации рунических символов и печатей, вливая в них магическую энергию и наблюдая за результатом. Возможно, пройдёт несколько десятилетий, прежде чем мы закончим свою работу, но что это за срок для эльфа, верно? — Он улыбнулся краешком губ. — Кстати о сроках: если твой путь приведёт тебя в Эльдранил, загляни к Равелии Этрезил и напомни о последней партии чернил…\",\"В журнал легло: {{«Чернила должны течь». Равелия, Эльдранил, напомнить про чернила.}}\",\"Я приняла задание. Эльдранил. Равелия Этрезил. Последняя партия чернил.\",\"— Чернила, — сказал Раф. — После троллей. Ты слышишь, как это звучит?\",\"— Как отпуск, — сказала я.\",\"— Как что?\",\"— Отпуск. Это когда… — Я запнулась. — Когда никуда не надо и никто не пытается тебя убить.\",\"Раф посмотрел на меня с тем же лицом, с каким смотрел на тридцать четыре рыбы.\",\"— Мы говорим «стоянка», — сказал он. — Откуда ты взяла это слово?\",\"Я не знала. Оно просто было у меня во рту, готовое, как будто я пользовалась им всю жизнь. Какую жизнь — вот вопрос. Я не засмеялась.\"],\"plates\":[{\"after\":12,\"alt\":\"— Знаешь ли ты, чем мы здесь заняты, Люси? — спросил Нимриэль и, не дожидаясь ответа, обвё\",\"src\":\"/chronicle/tome/043.jpg\"}]},{\"id\":\"g2-13\",\"numeral\":\"13\",\"title\":\"Часть 13\",\"kicker\":\"Глава 2\",\"dek\":\"Чаща здесь была другая.\",\"paragraphs\":[\"Чаща здесь была другая.\",\"Не осенняя, не золотая — тёмно-зелёная, густая, с еловыми лапами, нависающими так низко, что свет доходил до травы уже процеженным, зеленоватым, как через бутылочное стекло. Под ногами мох. Над головой — ничего, кроме веток. Было тихо той тишиной, в которой каждый шорох кажется шагом.\",\"На поляне стояли двое.\",\"[[Следопыт Орейн]] — высокий, рыжеватый, десятого уровня, и смотрел он на меня как на последнюю надежду этого леса. И рядом с ним — [[Следопыт Белладил]]. Тот стоял, но как-то неправильно. Так стоят, когда держатся на ногах исключительно из упрямства.\",\"— Моего друга покусали местные змеи и отравили своим ядом, — сказал Орейн, не отходя от Белладила ни на шаг. — Я могу поддерживать его в нынешнем состоянии, но для противоядия мне нужна помощь. В этой чаще растут кусты дикого зверобоя. Листья этого растения обладают целебными свойствами; я могу объединить их с другими ингредиентами и сделать противоядие. — Он сглотнул. — Пожалуйста, принеси мне несколько листьев. Здесь его много — можно увидеть даже отсюда.\",\"Змеи.\",\"Я вспомнила Шшеракса. Клык в свёртке, который я сдала Келмарину. «Попортило немало крови моим следопытам — в прямом и в переносном смысле». Вот он, прямой смысл. Стоит передо мной и держится из упрямства.\",\"— Семь, — сказал Орейн. — Мне нужно семь листьев.\",\"Я записала: {{«Противоядие для Белладила». 7 листьев зверобоя.}} И подчеркнула. Дважды. Белладил дышал за моей спиной тяжело и часто.\",\"Я огляделась. Видно было ели, мох и темноту между стволами. Где-то там же, я помнила, бродят звероловы Амани — шесть штук нам ещё нужно для Эрессы. Значит, листья будем собирать в тех же кустах, где охотятся тролли.\",\"* * *\",\"Первый зверолов нашёлся почти сразу.\",\"Он стоял между елей и выглядел так, будто это мы пришли к нему в дом без приглашения. По сути, так и было. Раф пошёл вперёд, щит на руке. Я подняла жезл. Лунный камень на конце мягко засветился.\",\"Мы положили его быстро. А рядом, у корней, я увидела куст. Невысокий, с бледными цветами. Наклонилась, сорвала.\",\"Я спрятала лист за пазуху, ближе к телу, чтобы не помять. {{Зверобой — 1 из 7.}} И снова это тёплое, тихое ощущение внутри, будто я чему-то научилась, — немного, на тридцать пять крупинок.\",\"* * *\",\"Второй тролль сидел под елью.\",\"Огромное дерево, ствол в два моих роста в обхвате, ветки над головой — как крыша. Под этой крышей, на корточках, — [[Налётчик Амани]], десятый уровень. Он нас не видел. Он обрывал листья с бледного куста, по одному, аккуратно, как обрывают то, что жалко, и складывал их в тряпицу. А за его спиной, привалившись к стволу, лежал второй тролль. Нога у него распухла до колена, тёмная, блестящая, и чуть выше щиколотки я разглядела две точки. Как у Белладила.\",\"Налётчик что-то говорил лежащему — тихо, нараспев, не по-боевому. Я не понимала ни слова. Но интонацию поняла бы на любом языке: «потерпи». Орейн говорил с Белладилом точно так же.\",\"Потом налётчик обернулся, увидел нас — и встал между нами и лежащим. Не заорал. Просто встал, подняв топор.\",\"Раф уже был в бою. Тролль бил по щиту, по плечу, по щиту снова. Раф пропустил совсем немного, но я смотрела на него так, будто он пропустил всё.\",\"Мы его положили. Налётчик рухнул у самых корней ели, и я подошла — сначала к нему, потом, медленнее, к тому, кто лежал у ствола.\",\"Второй тролль смотрел на меня. Он не мог встать и не пытался. Дышал он тяжело и неровно — так же, как Белладил за моей спиной на поляне. В тряпице у мёртвого лежали листья дикого зверобоя. Шесть. Он собирал траву для друга, которого покусали те же змеи. А может быть, и тот же змей, которому другие тролли носили рыбу.\",\"Мы — они. Я всегда думала, что граница проходит где-то по частоколу.\",\"Я взяла из тряпицы один лист. Один — для Белладила. Остальные пять сунула лежащему в ладонь и сжала его пальцы, как Эресса сжимала мои. Он не понял. Или понял. Глаза у него были жёлтые, мутные от яда, и в них не было ни благодарности, ни злости — только удивление.\",\"— Ты отдала ему траву, — сказал Раф. Не упрёк. Он просто хотел, чтобы это было сказано вслух.\",\"— Я отдала ему его траву, — сказала я. — Свою я найду сама.\",\"Асценси, не говоря ни слова, свернул с тропы к соседнему кусту и через минуту вернулся с двумя листьями. Положил мне в ладонь. Мы пошли дальше. Я не оглядывалась. Но ещё долго слышала за спиной это тяжёлое, неровное дыхание — и не могла понять, чьё именно: его или Белладила.\",\"* * *\",\"Третий — снова зверолов.\",\"Он кончился быстро: девятый уровень, сто семьдесят восемь здоровья, и я чувствовала, как они уходят из него, одно за другим, до нуля. Свет внутри меня умеет считать чужую жизнь. Я бы предпочла, чтобы не умел.\",\"А в добыче — клинок.\",\"Я взяла его в руку. Осенённый лоа клинок. Он лёг в ладонь так, будто ждал именно её, и уже не хотел отпускать. Пятна крови почти сливались с узором, которым были украшены эфес и лезвие.\",\"То есть узор на нём сделан так, чтобы кровь была почти не видна. Или кровь на нём так давно, что сама стала узором. Я не знала, какой вариант хуже. И чья это кровь — тоже не знала. Может, оленья. Может, эльфийская. Может — Малкарион.\",\"— Ещё пять клинков, четыре зверолова и сколько-то листьев. — Я убрала клинок в сумку, подальше от еды. — И один следопыт, который ждёт нас из упрямства.\",\"И тут Раф увидел жилу.\",\"Медная, зелёная от окиси, она выходила из склона в трёх шагах от тропы, как вена на руке. Раф замер. Я знаю этот взгляд: так смотрит медведь на улей.\",\"— Нет, — сказала я.\",\"— Чуть-чуть. Пару ударов.\",\"— Раф. Там стена. С троллями.\",\"— Они далеко. А медь — вот она.\",\"Он уже снимал кирку со спины. Первый удар прозвучал на весь лес, как колокол на свадьбе. За стеной, между зубцами, повернулась красно-зелёная голова. Я перестала дышать. Раф застыл с поднятой киркой. Асценси медленно, очень медленно, положил стрелу на тетиву.\",\"Раф опустил кирку. Посмотрел на жилу. Посмотрел на меня.\",\"— Потом, — прошептала я. — Ты обещал «потом» про меч. Пусть у тебя будет два «потом».\",\"Стена впереди никуда не делась: каменная кладка, а над ней — что-то красно-зелёное, троллье. И факел.\",\"Я сжала жезл.\"],\"plates\":[{\"after\":26,\"alt\":\"— Я отдала ему его траву, — сказала я. — Свою я найду сама.\",\"src\":\"/chronicle/tome/044.jpg\"},{\"after\":41,\"alt\":\"Он уже снимал кирку со спины. Первый удар прозвучал на весь лес, как колокол на свадьбе. З\",\"src\":\"/chronicle/tome/045.jpg\"}]},{\"id\":\"g2-14\",\"numeral\":\"14\",\"title\":\"Часть 14\",\"kicker\":\"Глава 2\",\"dek\":\"Семь листьев я несла так, будто это были не листья, а чья-то жизнь. По сути, так оно и было.\",\"paragraphs\":[\"Семь листьев я несла так, будто это были не листья, а чья-то жизнь. По сути, так оно и было.\",\"Орейн стоял на той же поляне, рядом с Белладилом. Тот теперь сидел — прямо в траве, ссутулившись, — и Орейн склонился над ним. Лицо Орейна исказилось, пока он осматривал раны товарища. Потом он поднял голову на мои шаги, и в его лице было столько ожидания, что у меня сжалось горло. Значит, ещё не поздно.\",\"— Надеюсь, ты с хорошими новостями.\",\"Я впервые видела, как у кого-то в этом мире искажается лицо. У троллей — да, постоянно, они вообще только этим и заняты. А у эльфа, у следопыта, у человека, который держал друга на ногах одним упрямством, — нет.\",\"— С хорошими, — сказала я. — Семь штук.\",\"Он протянул руку. Я отдала листья — семь, ровно столько, сколько он просил. Пальцы у Орейна дрожали, когда он их брал.\",\"— Это то, что нужно, — сказал Орейн, и у него дрогнул голос. — Спасибо, Люси. Твоя помощь, возможно, спасла жизнь моему другу.\",\"Белладил сидел. Белладил дышал. Пока этого хватало.\",\"* * *\",\"Орейн, не отрываясь от ступки, кивнул на свою сумку: там лежали эликсиры. Пять эликсиров мудрости, пять эликсиров увеличения или пять лечебных зелий — на выбор. И серебряная монета, которую он сунул мне в ладонь, не глядя.\",\"Нормальная жрица выбрала бы мудрость. Мудрость — это для таких, как я. Это мана, лечение, правильный, разумный, взрослый выбор.\",\"Эликсир увеличения.\",\"— С восьмого уровня, не раньше, — сказал Орейн, заметив мой взгляд. — Ты станешь больше и сильнее, на восемь силы. Двадцать минут. Только в бою, иначе зря.\",\"Я и так не маленькая. Представьте меня ещё больше. Высшая эльфийка в два этажа, в тряпочном плаще, с лунным жезлом и хрустальной сферой, и сила у неё на восемь больше. Сила. У жрицы. Которая бьёт Карой и молится, а посохом — уже даже не машет, потому что посоха больше нет.\",\"Асценси увидел, куда я смотрю, и поднял бровь.\",\"— Абсолютно, — сказала я ему. — Мне нужно, чтобы тролли видели меня издалека. Чтобы боялись. Ну или чтобы целились. Тут уж как повезёт.\",\"Бровь так и осталась поднятой. Раф промолчал, и это молчание было громче любого смеха.\",\"Я выбрала эликсир увеличения. Пять штук. Мудрость я когда-нибудь куплю. А шанс стать большой бывает раз в жизни.\",\"Орейн отдал мне пять бутылок и серебро. В журнал я записала одно: {{Белладил дышит ровнее.}} Крупнее, чем пишу обычно.\",\"* * *\",\"Шестой зверолов нашёлся на склоне, между высоких елей.\",\"Солнце садилось — где-то за стволами небо стало персиковым, и тени вытянулись длиннее деревьев. Тролль упал в траву ниже по склону. Я уже начинала читать заклинание, когда он умер.\",\"Я опустила руки. Заклинание рассыпалось у меня в пальцах — уже не нужно было. Шестой зверолов лежал в траве, далеко, дальше, чем я могла дотянуться Светом.\",\"Три вещи сразу: я опоздала, я победила, и я опять не там стою.\",\"— Ты слишком далеко! — крикнул Раф запоздало.\",\"— Он уже мёртв, — сказала я. — Куда ближе-то.\",\"— Привычка, — сказал Раф.\",\"— У кого?\",\"— У меня. Я всё время боюсь, что ты слишком далеко.\",\"Я не нашлась, что ответить. Отвернулась, чтобы он не видел моего лица.\",\"— К Эрессе, — сказала я. — Потом за клинками.\",\"Я тронула сумку. Пять эликсиров увеличения звякнули о сферу.\"],\"plates\":[{\"after\":6,\"alt\":\"— Это то, что нужно, — сказал Орейн, и у него дрогнул голос. — Спасибо, Люси. Твоя помощь,\",\"src\":\"/chronicle/tome/046.jpg\"}]},{\"id\":\"g2-15\",\"numeral\":\"15\",\"title\":\"Часть 15\",\"kicker\":\"Глава 2\",\"dek\":\"Шесть клинков в сумке — это тяжело. Не по весу, по ощущению. Шесть кусков стали, на которых кровь почти сливае\",\"paragraphs\":[\"Шесть клинков в сумке — это тяжело. Не по весу, по ощущению. Шесть кусков стали, на которых кровь почти сливается с узором. Я несла их через лес и всё время думала, что каждый из них когда-то был у кого-то в руке. А теперь у меня в сумке.\",\"Мьюра Яркопряд стояла у своей палатки, рядом с баллистами. Увидела меня, выпрямилась. Ждёт.\",\"— Нашла ли ты что-нибудь полезное для нас, Жрица? — спросила она и посмотрела на мою сумку. На шесть осенённых лоа клинков, которые оттягивали её вниз.\",\"«Жрица» — не «Люси», а именно Жрица, с большой буквы, как будто это звание, а не класс. Мне даже понравилось.\",\"Я выложила все шесть на стол. Металл звякнул, и Мьюра вздрогнула.\",\"Она взяла один клинок, повертела, и пальцы у неё побелели.\",\"— Мощь этого оружия пугает меня, — сказала она тихо. — Я не слышала ни о чём подобном со времён Войн Троллей.\",\"Войны Троллей. Это было давно. Так давно, что эльфы говорят об этом с тем же лицом, с каким старики говорят о прадедах. И вот теперь — снова. Те же тролли, тот же лес, новые клинки, и магия на них такая, что пугает эльфийку, которая работает с силовыми анализаторами.\",\"* * *\",\"Мьюра открыла ящик у палатки. Посох Благородных смотрел на меня оттуда с видом законного наследника, но посох двуручный, а в левой руке у меня теперь сфера. Я взяла булаву — Кулак правосудия, одноручную, с толстым навершием.\",\"В правой руке у меня с самого Келмарина была пустая ладонь. Я помнила, как сказала: «Для правой руки придётся что-то искать». И Раф ответил одним словом: «Найдёшь». А я сказала, что это не ответ, а надежда.\",\"— Кулак правосудия, — прочитала я вслух. — Звучит как приговор.\",\"— Звучит как молоток, — сказал Раф.\",\"Мьюра вложила булаву мне в руку рукоятью вперёд, как вручают оружие тем, кому доверяют. И серебро.\",\"Булава легла в правую руку — тяжёлая, удобная. Сфера осталась в левой. Впервые за долгое время у меня в обеих руках что-то было. Я сжала обе ладони и почувствовала себя почти воином.\",\"* * *\",\"Эресса ждала у костра.\",\"Тот же огонь в кольце из камней, то же жёлтое деревце, тот же Следопыт Нордерона у своей палатки с сундуком. Ничего не изменилось. Только у меня теперь было шесть мёртвых звероловов в журнале.\",\"Эресса заговорила первой, едва увидела меня: о том, что эти тролли использовали несчастных животных в своих целях, о слепой ярости, о созданиях, у которых отняли волю. И о том, что я оказала Нордерону услугу.\",\"Из наручей, которые она выложила, ткань была одна — Наручи заклинателя, мягкие, как вторая кожа. Мои Роскошные были роскошными примерно уровня на десятом.\",\"Эресса сама застегнула их у меня на запястьях. Пальцы у неё были жёсткие, в мозолях от тетивы, и очень осторожные.\",\"Застегнув последнюю пряжку, она посмотрела мне через плечо — туда, где у баллисты стоял Асценси со своей флягой.\",\"— Он всё такой же? — спросила она тихо.\",\"— Какой?\",\"— Молчит. — Эресса не улыбнулась. — Я знала его брата. Тот говорил за двоих, смеялся за двоих, пил за двоих. Его было слышно с другого конца заставы. А этот всегда стоял рядом и молчал. Им так было удобно.\",\"Она замолчала. Я ждала, что будет дальше. Дальше не было.\",\"— А где брат? — спросила я.\",\"Эресса посмотрела на флягу в руке Асценси. Потом на меня. И пошла к костру, не ответив. Иногда молчание — это и есть ответ, только вежливый.\",\"Булава в правой руке, сфера в левой, наручи на запястьях, перстень на пальце, кушак на поясе.\",\"Я впервые выглядела как жрица. Как будто кто-то одел меня в чужую жизнь, и она пришлась впору. Это пугало сильнее, чем тролли.\"],\"plates\":[{\"after\":26,\"alt\":\"— А где брат? — спросила я.\",\"src\":\"/chronicle/tome/047.jpg\"}]},{\"id\":\"g2-16\",\"numeral\":\"16\",\"title\":\"Часть 16\",\"kicker\":\"Глава 2\",\"dek\":\"Мьюра заговорила, и я запомнила её слова почти дословно. По голосу было ясно: это не просьба, это то, что прид\",\"paragraphs\":[\"Мьюра заговорила, и я запомнила её слова почти дословно. По голосу было ясно: это не просьба, это то, что придётся сделать.\",\"\\u0001[[Амани никогда не отличались искушённостью в истинном чародействе: их ворожба груба и безыскусна, хотя подчас бывает эффективна. Но это оружие зачаровано изощрённой магией. Прежде чем бороться с ней, мы должны понять её, Жрица.]]\",\"\\u0001[[Думаю, начать следует с капища на возвышенности южнее Зеб'Джунты, где тролли творят свои примитивные ритуалы. Возьми это перо, Люси. С его помощью ты сможешь видеть глазами орлов, кружащих в небе над Диколесьем. Узнай, что происходит в храме, и расскажи обо всём мне, да поскорее!]]\",\"Видеть глазами орлов.\",\"Серебряное перо. Только моё, единственное. Мьюра объяснила, как им пользоваться: сжать, позвать и недолго, пока не досчитаешь до двухсот, смотреть глазами нордеронского орла. Потом перо должно отдохнуть. И добавила, не отпуская моей руки: «Пока ты связана с орлом, ты беззащитна. Помни об этом».\",\"— Двести счётов, — сказала я. — Вы меня покараулите?\",\"— Покараулим, — сказал Раф. И встал рядом, щит на руке.\",\"Асценси молча встал с другой стороны.\",\"* * *\",\"Я вышла к частоколу. Брёвна, светлые, грубо стёсанные. Факел у камней. Над забором — синее, очень высокое небо, и в нём кружила птица. Тёмная точка с распахнутыми крыльями.\",\"Я узнала её сразу, хотя видела впервые: [[Нордеронский орёл]]. Одиннадцатый уровень, двести двадцать два здоровья — я почувствовала его силу так же ясно, как ветер от его крыльев.\",\"И вдруг я стала не одна. Я стала двумя. Одна стояла на земле, с закрытыми глазами, за спиной Рафа. Другая — летела.\",\"* * *\",\"Сначала был толчок. Как будто меня выдернули из собственного тела за макушку. Потом — ветер.\",\"Внизу горели кроны. Золотые, рыжие, медные — осень лежала на лесе сплошным ковром, и сверху он казался мягким, как мех. Солнце пробивалось через листву, и листва светилась изнутри. Где-то между деревьями мелькнула крыша — изящная, эльфийская, с изогнутыми краями. А потом и она осталась позади.\",\"Я никогда не видела Нордерон таким. Снизу он красивый. Сверху — невозможный.\",\"И одновременно где-то очень далеко, на самом краю сознания, я помнила: внизу, у частокола, стоит моё тело. Глаза пустые. Руки опущены. Одно неловкое движение тролля — и его нет.\",\"Я повернула на юг.\",\"* * *\",\"Цвет внизу менялся.\",\"Золото уступало место тёмной зелени. Потом зелень стала мутной. Воздух — я чувствовала это крыльями — стал тяжелее, влажнее. Внизу поднимался туман, жёлто-серый, плотный, как старая вата. Сквозь него проступали ели — высокие, тёмные, мрачные.\",\"Руины. Каменные блоки, ступени, стены, поросшие мхом. Всё огромное, грубое, неправильное — совсем не так, как строят эльфы. Эльфы строят так, чтобы было красиво. Тролли строят так, чтобы было страшно.\",\"Я сделала круг над самым тёмным местом. Там, в тумане, среди обломков, стояло что-то, к чему не хотелось приближаться даже с высоты.\",\"{{Алтарь — видела}}, — отметила я потом в журнале. Рука дрожала даже вечером.\",\"И площадь.\",\"Широкая, открытая, обнесённая обломками стен и колонн. Сердце этого места. Если у таких мест вообще есть сердце.\",\"Я развернула крылья обратно — к золоту, к солнцу, к частоколу, где стояла пустая высшая эльфийка, а рядом с ней — двое, которые обещали её покараулить.\"],\"plates\":[{\"after\":11,\"alt\":\"И вдруг я стала не одна. Я стала двумя. Одна стояла на земле, с закрытыми глазами, за спин\",\"src\":\"/chronicle/tome/048.jpg\"}]},{\"id\":\"g2-17\",\"numeral\":\"17\",\"title\":\"Часть 17\",\"kicker\":\"Глава 2\",\"dek\":\"Я вернулась в тело.\",\"paragraphs\":[\"Я вернулась в тело.\",\"Это было как проснуться после сна, в котором летала: ноги вдруг оказались тяжёлыми, а земля — слишком близко. Частокол, факел, камни. Раф справа. Асценси слева. Оба на месте, оба смотрят на меня.\",\"— Ну? — спросил Раф.\",\"— Алтарь, — сказала я. — Жертвенный. И площадь. И очень много тумана.\",\"Я пощупала собственные руки, просто чтобы убедиться, что они мои. Мои. Булава, сфера, наручи. Никто меня не съел, пока я была птицей.\",\"Спасибо, Раф.\",\"* * *\",\"Мьюра ждала у палатки.\",\"Я рассказала ей всё: алтарь, площадь, туман. Она слушала, не перебивая, и лицо у неё становилось всё темнее.\",\"— Значит, зачарованное оружие — лишь малая часть того, что уготовили нам тролли… — сказала она наконец. — Нужно больше сведений, Люси, иначе нам не остановить их наступление.\",\"И отсчитала мне семьдесят пять медяков.\",\"Я открыла журнал. Карандаш ещё не коснулся бумаги, когда это случилось.\",\"И мир вспыхнул.\",\"Тепло прокатилось по телу — и сразу же за ним, золотом, во всё небо, во всю меня:\",\"Десятый уровень.\",\"Малкарион был десятым.\",\"Только он остановился здесь. А я — пока нет.\",\"— Поздравляю, — сказал Раф.\",\"Мьюра подняла глаза от записей и посмотрела на меня так, как смотрят на огонь, вспыхнувший без огнива.\",\"— Я записываю, когда это случается со Странниками, — сказала она. — Двенадцать лет записываю. Ни разу не смогла предсказать — ни по возрасту, ни по ранам, ни по молитвам. Как будто кто-то где-то ставит отметку, а нам показывает только свет.\",\"Она вернулась к записям. Я осталась стоять с этим «кто-то где-то» в руках, как с чужим письмом без подписи.\",\"Вечером я открыла журнал на последних страницах, там, где веду список того, чем горжусь, и вписала: {{10-й уровень.}} И нарисовала рядом маленький герб. Криво. Как умею. А ниже, мельче: {{Малкарион — тоже.}}\",\"* * *\",\"А Мьюра уже смотрела на меня тем самым взглядом. Постоять с этим светом мне не дали.\",\"Заданий было три, и все — про храм. Первое Мьюра сказала вполголоса, будто она боялась, что ведьма услышит:\",\"— Во главе заклинателей, занимающихся созданием храмовых воинов, стоит знахарка по имени Ун'тула. Смерть этой ведьмы станет лучшим доказательством… — она запнулась и махнула рукой, — …что их творения ничего не стоят. Убей Зулфи Ун'тулу. В храме Великой Змеи.\",\"{{«Ведьма Масок». Зулфи Ун'тула. Храм.}}\",\"Ведьма Масок. Знахарка. Та, кто делает воинов.\",\"— Штаны провидца, жёсткие поножи или поножи главаря, — сказала Мьюра. — Когда вернёшься.\",\"* * *\",\"Второе Мьюра произнесла жёстче, глядя куда-то мимо меня, в сторону храма:\",\"— Думаю, ты знаешь, что в обществе троллей распространены жертвоприношения. Порой жертвы даже сами вызываются участвовать в их варварских ритуалах. Это считается у них великой честью — ценой собственной жизни ублажить жестоких богов — лоа, — чтобы те даровали троллям своё благословение. — Она помолчала. — Это нужно остановить. Отправляйся к храму и уничтожь жертвенные алтари. Пять алтарей.\",\"{{«Жертвенные алтари». 5.}}\",\"«Порой жертвы даже сами вызываются».\",\"Сами. Добровольно. Отдать свою единственную жизнь, чтобы боги были довольны.\",\"* * *\",\"А третье она сказала уже почти устало, как говорят о том, что давно не даёт спать:\",\"— Для начала нужно, чтобы ты разобралась с особыми стражами храма. Их называют заколдованными воинами, и они представляют реальную угрозу. Если колдуны Амани начнут плодить их сотнями, нам перед ними не выстоять. Наша задача — показать, что эти хвалёные воины не стоят… — дальше она говорила быстро и тихо, про силы, которые на них тратят, и я разобрала не всё. — Двенадцать храмовых воинов, Люси.\",\"{{«Заколдованные воины». 12.}}\",\"— Одеяние Провидца, тёмный кожаный мундир… — перечислила Мьюра. — Выберешь.\",\"Я не стала ничего выбирать. Награды — потом. Сначала — двенадцать воинов, пять алтарей и одна ведьма. В храме. Под туманом. Где я совсем недавно была птицей и чувствовала, как орлу не нравится это место.\",\"Теперь туда придётся идти пешком.\"],\"plates\":[{\"after\":14,\"alt\":\"Десятый уровень.\",\"src\":\"/chronicle/tome/049.jpg\"}]},{\"id\":\"g2-18\",\"numeral\":\"18\",\"title\":\"Часть 18\",\"kicker\":\"Глава 2\",\"dek\":\"Мост был верёвочный.\",\"paragraphs\":[\"Мост был верёвочный.\",\"Конечно, верёвочный. Тролли не строят каменных мостов в храм своей Великой Змеи. Они натягивают канаты между столбами, кладут поперёк доски и считают, что этого достаточно. Для троллей, может, и достаточно. Для меня каждая доска была отдельным вопросом, и на каждый я отвечала, вцепившись в канат.\",\"Я знала, куда мы пришли. Знала так, как знают название места, о котором слишком много говорили у костров:\",\"Храм Великой Змеи.\",\"Раф шёл впереди, щит на руке. За ним — Асценси. Я — последняя, как всегда. Жрица всегда идёт последней, потому что, если упадёт первая, лечить будет некому.\",\"Я перестала об этом думать и пошла дальше. Доска скрипнула. Я не обратила внимания. Почти.\",\"* * *\",\"За мостом начиналась площадь.\",\"Мощёная, широкая, из плотно уложенных каменных плит, кое-где вывороченных, кое-где заросших травой. По краю шли низкие столбики с натянутым канатом — как ограждение. Горел факел. Над площадью поднимались стены и башни, и на каждой — резные лица. Тролльи. Оскаленные.\",\"И здесь нас встретили.\",\"\\u0001[[Храмовый воин Тики]]\",\"Я ожидала тролля. А это был не тролль.\",\"Это была маска. Огромная деревянная маска на деревянном теле — истукан, резной, раскрашенный, с пустыми прорезями глаз. Заколдованный. Он двигался не так, как двигаются живые: слишком ровно, без дыхания, без суеты. Как кукла, которую дёргают за нитки откуда-то сверху.\",\"Ведьма Масок. Ну конечно.\",\"Раф шагнул вперёд и принял его на щит. Удар — деревянный, глухой, будто стучат по двери. Я подняла руку.\",\"Кара, Боль, ещё Кара. Истукан упал. Не рухнул — сложился, как сломанная игрушка.\",\"* * *\",\"Следующий был выше. Тоже Тики, двенадцатого уровня — на два выше меня. Я почувствовала это раньше, чем разглядела маску.\",\"{{Воины — 2 из 12}}, — сказала я себе вслух, чтобы потом записать. Голос сел.\",\"* * *\",\"Потом были ещё.\",\"Я не буду рассказывать о каждом. Они были одинаковые — и в этом было что-то по-настоящему жуткое. Одинаковые маски, одинаковые движения, одинаковый деревянный звук, когда они падали на камень. Не враги, а изделия. Ведьма где-то в глубине храма сидела и делала их — одного за другим. А мы ломали — одного за другим.\",\"Асценси первым понял, как их бить быстрее. Не сказал — показал: выстрелил не в маску, а в узел верёвки на затылке, там, где маска крепилась к деревянному телу. Маска съехала набок, истукан на секунду ослеп и замахал руками в пустоту. Раф хмыкнул, я перестала тратить Кару на лицо. Асценси даже не обернулся посмотреть, заметили ли мы.\",\"{{Пять из двенадцати.}} Я загнула пятый палец и сжала кулак.\",\"* * *\",\"Дальше вела дорога.\",\"В конце её стояли руины. Песочные стены, арки, проёмы, башни. Всё в жёлто-сером мареве, будто воздух здесь был гуще, чем снаружи.\",\"Где-то там — ведьма. Где-то там — алтари. Где-то там — ещё семь масок.\",\"Перо в волосах щекотало висок. Я так и не поняла, зачем его оставила. Может, напоминание. Может, просто красиво. Может, мне нужно было хоть что-то лёгкое в месте, где всё остальное было тяжёлым.\",\"Плиты под ногами были неровные. Я смотрела под ноги.\"],\"plates\":[{\"after\":0,\"alt\":\"Мост был верёвочный.\",\"src\":\"/chronicle/tome/050.jpg\"},{\"after\":11,\"alt\":\"Я ожидала тролля. А это был не тролль.\",\"src\":\"/chronicle/tome/051.jpg\"}]},{\"id\":\"g2-19\",\"numeral\":\"19\",\"title\":\"Часть 19\",\"kicker\":\"Глава 2\",\"dek\":\"Храм рос вверх террасами.\",\"paragraphs\":[\"Храм рос вверх террасами.\",\"Каменные ступени, широкие и низкие, как для великанов. Плиты с прорезанным узором — квадратные завитки, похожие на лабиринт. Тёмная зелень в каждой щели: папоротник, мох, листья, которые лезли из камня так уверенно, будто храм строили для них, а тролли пришли потом.\",\"Раф поднимался первым. Щит, красный плащ, широкая спина. Асценси за ним. Я — последней, и слабый свет с моих пальцев ложился под ноги, как маленький фонарь.\",\"Первый алтарь стоял на террасе, плоский, тяжёлый, с узором на крышке. Он развалился с третьей Кары.\",\"{{Алтари — 1 из 5.}} Я записала это, сидя на корточках у обломков, и руки пахли гарью.\",\"Я посмотрела на место, где он стоял, и подумала про «добровольцев» из задания Мьюры. Тех, кто сам вызывается. Ради благословения.\",\"* * *\",\"Алтари были дальше, выше, по всему храму. Второй. Третий.\",\"Пять из двенадцати. Истуканы куда-то подевались, а может, ведьма их ещё не доделала.\",\"* * *\",\"Терраса вывела нас на площадь.\",\"Мощёную, широкую, окружённую стенами. В дальней стене — вход в сам храм: тёмный проём под тяжёлым карнизом, по бокам — бирюзовые вставки, как глаза. Вокруг — груды обломков, золотистых, рыжих, будто здесь обвалилось что-то сделанное из золота. Или из костей. Я не стала приглядываться.\",\"А посередине — камень.\",\"Длинный, серый, с рунами на боку. И вокруг него, по плитам, расползалась тёмно-красная лужа. Не свежая. Но и не старая.\",\"Жертвенный камень.\",\"И возле него стояла она.\",\"Зулфи Ун'тула. Она даже не пряталась.\",\"Вокруг неё, прислонённые к колоннам, стояли маски. Недоделанные. Одна без глаз, у другой не было рта, третья была только начерно вырезана из чурбака, и стружка лежала у её подножия свежей горкой. Ведьма водила кистью по последней — красной краской, вокруг прорезей, медленно, бережно, как красят лицо ребёнку перед праздником.\",\"Она увидела нас и не бросила кисть. Сначала докрасила. Потом выпрямилась и сказала — на нашем языке, ломано, с трудом выталкивая каждое слово, будто носила их во рту давно и ни разу не доставала:\",\"— Дерево не плачет.\",\"Она показала кистью на маски. Потом — куда-то за стену, туда, где была Зеб'Джунта.\",\"— Матери — плачут. Дерево — нет. Ещё лица. Мне нужно ещё лица.\",\"Я не знаю, что она хотела этим сказать. Я знаю, что я услышала: она делала воинов, чтобы вместо кого-то живого в бой шёл кто-то деревянный. А мы весь день ломали её деревяшки.\",\"Потом она подняла руки, и между ладонями у неё собрался огонь, и думать стало некогда.\",\"Раф пошёл вперёд.\",\"Она начала читать. Я видела, как огонь собирается у неё в ладонях, медленно, неотвратимо:\",\"Жертвенный огонь.\",\"Раф принял удар. Я почувствовала, как он дрогнул. Ещё держится.\",\"Её жизнь уходила — слишком медленно для моих нервов, и после каждой Кары у меня мелко дрожали колени.\",\"Я стояла у края площади, у груды обломков, и считала. Не раны — её заклинания. Пока она читает «Жертвенный огонь», она не делает ничего другого. Пока она не делает ничего другого, Раф жив.\",\"А потом ведьма упала.\",\"Прямо возле своего камня. Возле своей лужи. Красиво, если бы не было так мерзко. {{Зулфи Ун'тула — 1 из 1}}, — подумала я, и в ту же секунду Раф крикнул мне:\",\"— Ты слишком далеко!\",\"Меня даже не задело. Мана — почти на донышке. Раф помят, Асценси цел.\",\"Живы. Все.\",\"Я выдохнула. Только сейчас поняла, что всё это время дышала через раз.\",\"* * *\",\"Возле ведьмы что-то тускло поблёскивало. Я подошла, стараясь не смотреть ей в лицо. В складках её одежды, перетянутый чётками, лежал свиток. Отмеченный змеем.\",\"Свиток был тёплый, будто ещё помнил её руки. На нём красовался знак змеи, и я сразу почувствовала: теперь он мой, и избавиться от него будет не так просто. Где-то внутри, на шнурке, болталась бирка с надписью на нашем языке: «Запрещённый трактат о Ула'теке».\",\"Я держала его в руках и чувствовала, как мне не хочется его держать. Слово «запрещённый» само по себе ничего не значит. Но запрещённый у троллей, которые приносят живых в жертву, — это уже серьёзно.\",\"Ула'тек. Я не знала, кто это. И почему о нём нельзя писать — тоже.\",\"Я развернула.\",\"Свиток был испещрён письменами троллей, и я не могла понять, что именно он содержит. Но я знала, кто сможет: в Анклаве Странников есть Мьюра Яркопряд. Я записала: {{Отмеченный змеем свиток — отнести Мьюре.}}\",\"Чётки. Змеиный символ. Письмена, которые я не могу прочитать. Раф глянул через плечо и сказал, что понимает по-тролльи только «аргх». Асценси даже не стал смотреть. Значит, к Мьюре.\",\"Я приняла задание и спрятала свиток в сумку. Подальше от еды. Рядом с клинками я бы его тоже не положила — но клинков уже не было, я их сдала.\",\"Я оглянулась на площадь. Камень, лужа, мёртвая ведьма. Вход в храм — тёмный, открытый, ждущий.\"],\"plates\":[{\"after\":43,\"alt\":\"Чётки. Змеиный символ. Письмена, которые я не могу прочитать. Раф глянул через плечо и ска\",\"src\":\"/chronicle/tome/052.jpg\"}]},{\"id\":\"g2-20\",\"numeral\":\"20\",\"title\":\"Часть 20\",\"kicker\":\"Глава 2\",\"dek\":\"Двенадцатая маска упала прямо мне под ноги, и я поняла, что больше не помню, как падала седьмая. Наверное, это\",\"paragraphs\":[\"Двенадцатая маска упала прямо мне под ноги, и я поняла, что больше не помню, как падала седьмая. Наверное, это правильно: если запоминать каждого, кто пытался тебя убить, к зиме в голове не останется места ни для чего другого.\",\"Пятый алтарь развалился под Карой, и мы пошли обратно — через разбитую дорогу, через верёвочный мост, где доски опять скрипели.\",\"* * *\",\"Мьюра выслушала меня про воинов и выдохнула так, будто держала этот воздух с утра:\",\"— Теперь они трижды подумают, прежде чем создавать этих тварей. Мне даже страшно представить, что было бы, если бы нам пришлось сражаться с целой армией этой пакости.\",\"Она выложила на стол Одеяние Провидца — старшую сестру моей старой мантии. Название звучало как пророчество. Похоже, сбывалось.\",\"* * *\",\"Про алтари она сказала тише, отведя глаза:\",\"— То, что делают тролли, отвратительно и жестоко, но, к огромнейшему сожалению, ещё и эффективно. Приятно слышать, что теперь эти дикари не смогут продолжать свои мерзкие ритуалы.\",\"«Ещё и эффективно».\",\"Вот что пугало меня больше всего. Не жестокость, а то, что она работает. Тролли отдают кого-то своим лоа, и лоа отвечают. Сделка. Жизнь в обмен на силу.\",\"Мьюра выдвинула из-под стола ящик. Три пары перчаток лежали в нём, как три ответа на один вопрос. Я взяла верхние, ещё пахнувшие дымом чьей-то мастерской, и прочитала вышитое на отвороте имя:\",\"\\u0001[[Ритуальные перчатки]]\",\"— Это шутка? — спросила я.\",\"— Это рифма, — сказал Раф. — Эльфы любят, когда всё рифмуется. Даже награды.\",\"Асценси взял вторые, кожаные, повертел и положил обратно, не сказав ни слова. Перчатки жулика ему, видимо, не подошли по характеру.\",\"* * *\",\"А про ведьму она сказала, впервые за всё время улыбнувшись:\",\"— Твоё умение расправляться с троллями заставило бы устыдиться даже гордых сынов Стромгарда. Приятно знать, что Странников поддерживает такая искусная Жрица.\",\"Искусная Жрица. Снова с большой буквы.\",\"Штаны провидца, на которые я положила глаз ещё тогда, когда брала задание. Простые брюки прослужили честно, но пусть уходят на покой.\",\"Я забрала штаны и монету. В журнале, помельче: {{Мьюра улыбнулась.}}\",\"* * *\",\"Свиток я положила последним.\",\"Мьюра развернула его, и глаза у неё загорелись.\",\"— Как интересно! Тебе в руки попал свиток со сказаниями троллей, причём описывающий совсем недавние события. — Она нахмурилась над строчками. — Я попробовала перевести, но моё знание зандали далеко от идеала, так что за точность ручаться не стану. В любом случае, если найдёшь другие свитки, подобные этому, можешь смело нести их мне.\",\"«Совсем недавние события».\",\"Значит, это не древняя легенда, не пыльный миф времён Войн Троллей, а то, что случилось недавно. В этом лесу, с этими троллями. И, возможно, это связано с храмом, где я только что была.\",\"Она отсчитала пятьдесят медяков и протянула мне свой перевод, переписанный на чистый лист: «Сказания троллей».\",\"* * *\",\"Всё полное. Только внутри, где-то под новой мантией, было пусто и тихо.\",\"Раф стоял у костра. Асценси смотрел за частокол, туда, где за лесом, в тумане, остались руины храма.\",\"Я встала рядом с Асценси и тоже посмотрела туда. Ничего не было видно. Только туман.\"],\"plates\":[{\"after\":13,\"alt\":\"— Это шутка? — спросила я.\",\"src\":\"/chronicle/tome/053.jpg\"},{\"after\":18,\"alt\":\"— Твоё умение расправляться с троллями заставило бы устыдиться даже гордых сынов Стромгард\",\"src\":\"/chronicle/tome/054.jpg\"},{\"after\":32,\"alt\":\"Я встала рядом с Асценси и тоже посмотрела туда. Ничего не было видно. Только туман.\",\"src\":\"/chronicle/tome/055.jpg\"}]},{\"id\":\"g2-21\",\"numeral\":\"21\",\"title\":\"Часть 21\",\"kicker\":\"Глава 2\",\"dek\":\"— Должна признать, — сказала Мьюра, пока я ещё возилась с завязками новых штанов, — магические навыки этих тро\",\"paragraphs\":[\"— Должна признать, — сказала Мьюра, пока я ещё возилась с завязками новых штанов, — магические навыки этих троллей превосходят всё, что мы когда-либо видели у Амани.\",\"Голос у неё звучал не со страхом, а с уважением к врагу, что было ещё страшнее. — Мне было бы интересно узнать, как им удалось достичь того, что не удаётся иным племенам, и, самое главное, как им помешать. Возможно, ответы содержатся в их ритуальных артефактах. Принеси мне образцы — восемь артефактов, — и я хорошо тебя награжу.\",\"Ещё одна строчка, уже привычная: {{«Знание — сила». 8 артефактов.}} Спорить не хотелось. После храма вообще мало чего хотелось.\",\"— Есть Пояс мудреца, — добавила Мьюра. — И кожаный, с письменами…\",\"Пояс. Я машинально тронула свой кушак. Кушак странника. Он был со мной уже давно.\",\"Я приняла задание и решила пока о кушаке не думать.\",\"* * *\",\"Руины Амани были рядом.\",\"Тут повсюду валялись каменные блоки, огромные, грубо обтёсанные, и некоторые ещё стояли друг на друге в виде колонн. На колоннах были резные узоры, квадратные спирали, похожие на лабиринты. Из-за колонн торчали тёмно-зелёные листья. Под ногами лежали каменные плиты, а между ними пробивалась трава.\",\"Артефакты лежали прямо у колонн. Маленькие, светлые, похожие на кувшинчики, на ритуальную утварь. Тролли оставили их здесь так, будто вышли на минутку.\",\"* * *\",\"Седьмой нашёлся в сундуке.\",\"Сундук стоял на мощёной площадке у каменного столба, рядом с грудой золотистых обломков: то ли золото, то ли просто жёлтый камень, который рассыпался от времени. Тяжёлый, деревянный, окованный, с откинутой крышкой.\",\"{{Артефакты — 7 из 8}}, — записала я, сидя на крышке сундука.\",\"Слева, у края площадки, стоял [[Следопыт Нордерона]]. Наш. Зелёная накидка, у ног трещал огонь. Значит, эльфы держали здесь пост, прямо посреди троллиных руин. Я на всякий случай подошла ближе к нему. Рядом с кем-то в зелёном было спокойнее.\",\"Восьмой нашёл Асценси. Он ни с того ни с сего полез на покосившуюся колонну, цепляясь за резные спирали, — мы с Рафом молча смотрели снизу, — и достал из ниши под самым карнизом маленький светлый кувшинчик. Спустился, сунул мне в руки и пошёл дальше, как будто так и было задумано. Я до сих пор не знаю, как он его увидел снизу. Может, и не видел. Может, просто знал, куда тролли прячут то, что им дорого.\",\"* * *\",\"Мьюра встретила меня с той же тревогой на лице.\",\"Я выложила перед ней восемь артефактов. Она перебирала их долго, бормоча:\",\"— Да, это как раз то, что н… шаг ближе к пониманию маг… Амани.\",\"Из трёх поясов ткань была одна — Пояс мудреца. Он давал здоровья ровно столько, сколько я потеряла при смене вещей. А на мне был мой кушак. Кушак странника. Его мне дала Телера.\",\"Я посмотрела на кушак. Он ни разу не порвался.\",\"— Ты чего? — спросил Раф.\",\"— Прощаюсь, — сказала я.\",\"— С поясом?\",\"— С кушаком. Это разные вещи.\",\"Асценси ничего не сказал. Но посмотрел на кушак так, будто тоже прощался.\",\"Мьюра вложила пояс мне в руки. И серебро.\",\"Новый пояс лёг на талию плотно, как будто его шили по мне. Кушак я сложила и убрала в сумку. Выбросить не смогла. Цифры говорили, что он больше не нужен. Но цифры не знают, сколько мы с ним прошли.\"],\"plates\":[{\"after\":11,\"alt\":\"Седьмой нашёлся в сундуке.\",\"src\":\"/chronicle/tome/056.jpg\"},{\"after\":15,\"alt\":\"Восьмой нашёл Асценси. Он ни с того ни с сего полез на покосившуюся колонну, цепляясь за р\",\"src\":\"/chronicle/tome/057.jpg\"}]},{\"id\":\"g2-22\",\"numeral\":\"22\",\"title\":\"Часть 22\",\"kicker\":\"Глава 2\",\"dek\":\"Раф подошёл ко мне с тем видом, с каким щитоносцы обычно просят об одолжении: будто делают одолжение тебе.\",\"paragraphs\":[\"Раф подошёл ко мне с тем видом, с каким щитоносцы обычно просят об одолжении: будто делают одолжение тебе.\",\"— Глянь, — сказал он и протянул мне на ладони одно-единственное нарукавье, бурое, в тёмных пятнах.\",\"Окровавленное нарукавье. Кольчужное, тяжёлое, крепкое, ни царапины. Такие, однажды надетые, уже не снимают и не продают.\",\"— Окровавленное, — прочитала я. — Ты уверен, что это твоя кровь?\",\"— Теперь моя, — сказал Раф.\",\"Я открыла книгу чар. Полоска навыка стояла — так я называю шёлковую закладку, которую передвигаю после каждого урока, — на жалких восьми из семидесяти пяти, и рецептов там было ровно столько, сколько пальцев на одной руке тролля, которому не повезло.\",\"«Здоровье I» — наставница в Эльдраниле показывала мне его на старом наруче, водя моими пальцами по металлу: «Вот здесь, у запястья, где бьётся жила. Пыль клади тонко. Не дави. Пусть ляжет сама». Восемь щепоток странной пыли, рунический медный жезл, и наручи держат на пять единиц жизни больше.\",\"Я положила нарукавье на колено, достала жезл и пыль. Раф стоял рядом и смотрел, как смотрят на лекаря. И спросил, как строгая ключница:\",\"— Сколько с меня?\",\"Ноль медяков. Ни я ему, ни он мне. Я начала. Пыль ложилась тонко, как учили, и пальцы у меня почти не дрожали.\",\"Странная пыль вспыхнула зелёным и ушла в кольчугу. Нарукавье осталось таким же бурым, но где-то внутри него теперь жили пять лишних единиц Рафа.\",\"* * *\",\"Мьюра стояла на том же месте, где всегда, и по тому, как она вскинула голову, я поняла: у неё снова что-то для меня есть. Рядом, как часовой, стоял капитан Келмарин.\",\"— Заклинатели троллей представляют гораздо большую угрозу, чем я предполагала, — сказала Мьюра. — Они используют магию самым отвратительным образом: смешивают силу тайной магии с силой тьмы, ни капли не задумываясь о последствиях. Хуже того, эти дикари нашли способ насыщать предметы сущностью лоа! — Она сжала кулаки. — Нельзя, чтобы они и дальше оттачивали свои гнусные навыки и распространяли эти практики среди других племён. Их знание должно умереть вместе с ними. Шестерых тёмных ведунов храма Великой Змеи, Люси. И сделай это до того, как пойдёшь к Зушолу: потом будет поздно.\",\"{{«Лучшая защита от магии». 6 тёмных ведунов. До Зушола!}}\",\"* * *\",\"Мьюра не закончила.\",\"— Творимыми в капище ритуалами руководит духовный лидер племени, верховный жрец по имени Зушол, — продолжила она, и голос у неё стал совсем тихим. — С его смертью Амани потеряют поддержку своих богов. Благодаря тому, что ты учинила в храме, сейчас Зушол уязвимее, чем когда-либо, поэтому действовать надо быстро и решительно. Но я бы не стала недооценивать этого жреца и те силы, к которым он взывает. — Она вложила мне в ладонь один из ритуальных предметов, которые я принесла, теперь гудящий изнутри. — Я зарядила его тайной магией. С ним ты сможешь противостоять трюкам Зушола. Не подведи нас, Люси.\",\"Я записала, и карандаш скользнул по бумаге криво: {{«Глас великой змеи». Сразиться с Зушолом. Одолеть Отродье Ула'тек.}}\",\"Раф дождался, пока она отойдёт к баллистам, и сказал — тихо, что для Рафа само по себе событие:\",\"— Я не хочу туда идти.\",\"Я уставилась на него. Раф, который говорит «погоди», «держу» и «я успею». Раф, который вызвался идти перед авангардом раньше, чем авангард вообще появился.\",\"— Верховный жрец, — сказал он. — Тринадцатый уровень, если я правильно чувствую. И Отродье, у которого есть имя. Мы не знаем, сколько он берёт за вход. Я знаю только, что платить будешь ты: я в доспехах, Асценси в коже, а ты — в тряпичном платье.\",\"— Мьюра сказала: «не подведи».\",\"— Мьюра не пойдёт с нами наверх.\",\"Асценси молчал. Потом сделал то, чего я от него не ожидала: отвинтил флягу и протянул её не мне, а Рафу. Раф посмотрел на флягу, на него, глотнул, поморщился и вернул.\",\"— Ладно, — сказал Раф. — Но сначала ведуны. И если я скажу «назад» — ты идёшь назад. Без «ещё одну Кару».\",\"— Без «ещё одну Кару», — пообещала я. Мы оба знали, что я вру. Но он хотя бы спросил.\",\"Тотем у храма смотрел на нас пустыми глазами, в волосах из зелёных лент шевелился ветер. Где-то там, наверху, Зушол взывал к своим богам.\"],\"plates\":[{\"after\":10,\"alt\":\"Странная пыль вспыхнула зелёным и ушла в кольчугу. Нарукавье осталось таким же бурым, но г\",\"src\":\"/chronicle/tome/058.jpg\"}]},{\"id\":\"g2-23\",\"numeral\":\"23\",\"title\":\"Часть 23\",\"kicker\":\"Глава 2\",\"dek\":\"Храм Великой Змеи встретил нас всё теми же ступенями. Широкими, каменными, уходящими вверх, будто тролли строи\",\"paragraphs\":[\"Храм Великой Змеи встретил нас всё теми же ступенями. Широкими, каменными, уходящими вверх, будто тролли строили лестницу прямо к своим богам и не собирались останавливаться.\",\"Новый пояс работал. Тридцать лишних единиц жизни, пришитых к талии. Я поймала себя на том, что считаю их, как монетки в кармане.\",\"— Ведуны, — напомнила я. — Сначала ведуны. Мьюра просила до Зушола.\",\"* * *\",\"Тёмный ведун. Двенадцатый уровень — я почувствовала его силу кожей, как жар от раскалённого камня.\",\"Стрела Тьмы. Я узнала её раньше, чем она сорвалась с его пальцев.\",\"— Ты слишком далеко! — крикнул Раф. — Далеко, Люси! Не достанешь!\",\"Ведун падал медленно, а у меня внутри уже горело, как от горячего чая, выпитого залпом.\",\"{{Ведуны — 2 из 6}}, — повторила я про себя, чтобы вечером записать.\",\"Дальше пошло быстрее, если «быстрее» вообще применимо к тому, кто кидает в тебя Стрелу Тьмы. Ещё один у груды золотистых обломков, у самых ступеней. Семь единиц здоровья у него осталось, когда Раф опять закричал, что я слишком далеко. Семь. Я почти дотянулась до него голыми руками.\",\"{{5 из 6.}}\",\"* * *\",\"Внутри храма было темно.\",\"Не так, как в лесу ночью. Темно по-храмовому: стены будто впитывали свет, а редкие огни только подчёркивали, сколько вокруг пустоты. Из тени торчали остроконечные силуэты, похожие на каменные шлемы. Или на надгробия. Я решила думать, что на шлемы.\",\"Асценси молча показал луком вверх.\",\"Наверху, в узком проёме, на постаменте стоял он.\",\"Он молился. Не нам и не против нас — просто молился, стоя к нам спиной, лицом к тёмной стене, на которой была вырезана огромная змея. Голос у него был низкий, ровный, и он не прервался, когда мы вошли. Он дочитал. Потом обернулся.\",\"— Вы пришли за моей головой, — сказал он на нашем языке. Медленно, правильно, лучше, чем говорила ведьма. — Голова — ничего. Мой народ прятался в долине, когда мёртвые жгли наши города. Мать Змей сказала: хватит прятаться. Я привёл их сюда. Я обещал им дом.\",\"Он посмотрел на меня. Не на Рафа — на меня, будто узнал во мне что-то своё: такую же, как он, которая говорит с тем, кого не видно.\",\"— Ты тоже молишься, жрица. Твой бог тебе отвечает?\",\"Я не ответила. Я не знала ответа. Он кивнул, как будто это и был ответ, и поднял руки.\",\"Верховный жрец Зушол. Я почувствовала его — и у меня подкосились колени.\",\"Жизни в нём было, как в шестерых таких, как я. Тринадцатый уровень — это я поняла уже потом, когда снова смогла думать.\",\"А ещё он был закрыт. Вокруг него переливался щит, и я понимала, что моя Кара отскочит от него, как горох от стены.\",\"Вот теперь пригодился подарок Мьюры.\",\"Заряженный артефакт троллей, мой и только мой. Мьюра объяснила, пока заряжала: «Он пробьёт его щит. Одним ударом тайной магии. Но потом ему нужно отдохнуть — пятнадцать ударов сердца, не меньше».\",\"Я сжала артефакт.\",\"Из артефакта вырвался белый луч, тонкий, как нить, прямо вверх, к Зушолу. Вокруг меня вспыхнул узор, похожий на паутину.\",\"Щит треснул, и я впервые увидела, что Зушол тоже может бояться.\",\"Пятнадцать ударов сердца. Каждые пятнадцать. Я считала их, как удары собственного сердца, и между ними била всем, что у меня было. Мана таяла. Раф держал жреца на себе, я чувствовала, как дрожит его жизнь, но не падает.\",\"Я не запомнила, чем кончился бой. Только как в нём кончилась жизнь — я почувствовала это пальцами, как обрыв нити.\",\"Он упал на колени у алтаря. Последнее, что он сделал, — провёл ладонью по краю камня, по острому, и прижал окровавленную руку к змее на стене. И прошептал одно слово. Его я поняла. «Ула'тек».\",\"Я выдохнула. Где-то внутри, тихо, как после долгого урока, легло новое понимание — немного, но ощутимо; потом, уже спокойно, я сосчитала: четыреста одиннадцать крупинок. Вечером в журнале: {{Зушол — 1 из 1.}}\",\"Рано.\",\"* * *\",\"Из темноты поднялось оно.\",\"Огромное. Зелёное. Змей, такой большой, что я видела только его кусок: чешуйчатый бок, жёлтые полосы, золотые наросты, как броня. Оно заполнило собой половину храма. Я стояла у самого его хвоста и чувствовала себя муравьём рядом с ботинком.\",\"Отродье Ула'тек. Тринадцатый уровень.\",\"Я подняла руку для Кары — и Свет не пошёл. Просто не пошёл, как будто упёрся в стену.\",\"— Не берёт! — крикнула я. — И далеко!\",\"Я отошла. Нашла угол, откуда доставала. Начала бить.\",\"Но Отродье оказалось хрупким — куда слабее, чем выглядело. После Зушола это было почти оскорбительно. Будто тролли потратили всю фантазию на размеры, а на живучесть её уже не хватило. Двести два здоровья — это я поняла уже потом, когда змей исчез.\",\"Асценси стрелял из лука, Раф стоял под самой мордой. Мана у меня ушла ниже половины, и я поймала себя на том, что считаю её, как монеты в последнем кошельке.\",\"{{Отродье — 1 из 1.}} Я записала это вечером и долго не могла поставить точку.\",\"Змей исчез, будто его и не было, только зелёный свет ещё дрожал на стенах.\",\"Асценси стоял рядом со своим луком и смотрел на то место, где было Отродье. Раф опустил щит.\",\"Асценси молча отвинтил флягу. Не отпил. Просто подержал.\",\"Я посмотрела в журнал. «Глас великой змеи» — обе цели закрыты. «Лучшая защита от магии» — всё ещё открыто. Один ведун. Мне оставался один ведун до того, как я понесу Мьюре голос великой змеи.\",\"Не сдавать. Пока не сдавать.\",\"Пока ещё есть куда.\"],\"plates\":[{\"after\":41,\"alt\":\"Но Отродье оказалось хрупким — куда слабее, чем выглядело. После Зушола это было почти оск\",\"src\":\"/chronicle/tome/059.jpg\"}]},{\"id\":\"g2-24\",\"numeral\":\"24\",\"title\":\"Часть 24\",\"kicker\":\"Глава 2\",\"dek\":\"Когда змей исчез, в храме стало очень тихо.\",\"paragraphs\":[\"Когда змей исчез, в храме стало очень тихо.\",\"Я заметила их не сразу. В полумраке стояли тёмные остроконечные камни, и на некоторых теплился жёлтый огонёк. Я раньше думала, что это каменные шлемы. Теперь я подошла ближе и поняла, что это не шлемы.\",\"Над камнем раскрылась маленькая кожаная книжка.\",\"\\u0001[[Zarimi (11-го уровня)]]\",\"\\u0001[[Zarimi, высший эльф 11-го уровня, был убит существом Верховный жрец Зушол 13-го уровня в зоне «Нордерон»]]\",\"Одиннадцатый. На один уровень выше меня.\",\"Раф подошёл к соседнему камню. Он не сказал «пошли». Он тоже открыл книжку.\",\"\\u0001[[Rastyapaluna (13-го уровня)]]\",\"\\u0001[[Rastyapaluna, высший эльф 13-го уровня, был убит существом Верховный жрец Зушол 13-го уровня в зоне «Нордерон»]]\",\"— Тринадцатый, — сказал он. — Как сам Зушол.\",\"Равный. И всё равно здесь.\",\"\\u0001[[Кровожада (12-го уровня)]]\",\"\\u0001[[Кровожада, высший эльф 12-го уровня, был убит существом Верховный жрец Зушол 13-го уровня в зоне «Нордерон»]]\",\"Кровожада. Кто-то выбрал такое имя, чтобы его боялись. Теперь оно написано на камне в тёмном храме, и прочитать его могут только те, кто дошёл досюда сам.\",\"\\u0001[[Тиург (11-го уровня)]]\",\"\\u0001[[Тиург, высший эльф 11-го уровня, был убит существом Верховный жрец Зушол 13-го уровня в зоне «Нордерон»]]\",\"\\u0001[[Аззулла (12-го уровня)]]\",\"\\u0001[[Аззулла, высший эльф 12-го уровня, был убит существом Верховный жрец Зушол 13-го уровня в зоне «Нордерон»]]\",\"\\u0001[[Ларока (10-го уровня)]]\",\"\\u0001[[Ларока, высший эльф 10-го уровня, был убит существом Верховный жрец Зушол 13-го уровня в зоне «Нордерон»]]\",\"Десятый.\",\"Я долго смотрела на эту цифру. Десятый уровень, высший эльф. Как Малкарион у Мон'земби. Как я.\",\"Ларока пришёл сюда с тем же запасом жизни, с какой пришла бы я, будь у меня на один пояс меньше. Может быть, у него тоже была группа. Может быть, нет. Книжка про это ничего не говорила. Книжки про это никогда ничего не говорят. Только имя, уровень, кто убил и где.\",\"Одна строчка на целую жизнь.\",\"\\u0001[[Санлей (12-го уровня)]]\",\"\\u0001[[Санлей, высший эльф 12-го уровня, был убит существом Верховный жрец Зушол 13-го уровня в зоне «Нордерон»]]\",\"Семь.\",\"Семь камней в одном зале. Семь человек, которые однажды кивнули Мьюре на том же задании, на «Гласе великой змеи», и услышали от Мьюры то же самое «Не подведи нас». Они вошли по тем же ступеням. И не вышли.\",\"Я прислушалась к себе. Жизнь во мне была полная. Ровно, до самого края. Минуту назад я бы гордилась этим, а теперь у меня свело горло, и, когда я наконец вдохнула, мне хотелось только одного — сберечь её, как свечку на сквозняке.\",\"— Пошли, — наконец сказал Раф. Тихо. Совсем не так, как он обычно говорит «пошли».\",\"— Пошли, — сказала я.\",\"Огоньки на камнях не дрогнули, когда мы проходили мимо. Им было всё равно. Они горели не для нас.\",\"Я шла и думала о тех, кто уже не вернулся из этих храмов. Потом подумала, что если когда-нибудь здесь появится восьмая книжка, на ней будет «Люси, высший эльф». И какой-то уровень.\",\"Я очень хотела, чтобы этой книжки не было вовсе.\"],\"plates\":[{\"after\":22,\"alt\":\"Ларока пришёл сюда с тем же запасом жизни, с какой пришла бы я, будь у меня на один пояс м\",\"src\":\"/chronicle/tome/060.jpg\"}]},{\"id\":\"g2-25\",\"numeral\":\"25\",\"title\":\"Часть 25\",\"kicker\":\"Глава 2\",\"dek\":\"Шестой ведун всё-таки нашёлся. Я не стала спрашивать у храма, сколько их там ещё осталось. Мне нужно было ровн\",\"paragraphs\":[\"Шестой ведун всё-таки нашёлся. Я не стала спрашивать у храма, сколько их там ещё осталось. Мне нужно было ровно шесть.\",\"Мьюра ждала на прежнем месте, у подножия того же храма, под тем же тотемом с зелёными лентами. Рядом, как всегда, стоял капитан Келмарин. Оба повернулись ко мне одновременно, как будто услышали мои шаги ещё у ворот. Иногда мне кажется, что эти двое никогда не спят, а просто ждут, когда я вернусь живой.\",\"* * *\",\"— Прекрасно, Жрица, — сказала Мьюра. — По… — дальше она заговорила быстро, перебивая сама себя, что-то про то, что теперь можно не опасаться их…\",\"Ритуальный нарамник из трёх наплечий я взяла не думая: моё Призрачное оплечье и было призраком. Я сняла его без сожаления. Не каждая вещь становится кушаком.\",\"* * *\",\"— Одержать верх над верховным жрецом троллиного бога в его храме… немалое достижение, но… встать лицом к лицу с отродьем лоа и… есть лишь одно слово, которым можно назвать твоё деяние: героизм. — Она кивнула на стол. — Прошу, не стесняйся, выбери, что тебе по душе.\",\"А на голову мне предложили… Шапку смотрителя. Мою я носила с шахты, ни одной дырки. Новая была та же, только постарше и поумнее. Мир явно надо мной издевался. Или поощрял преданность одному фасону.\",\"* * *\",\"Келмарин дождался, пока я закончу с Мьюрой.\",\"— Пока вы с Мьюрой разбирались с колдунами, мои следопыты устраивали мелкие набеги на цитадель троллей Зеб'Джунту, чтобы не дать им привести подкрепление к храму, — сказал он. — Настало время для серьёзной атаки. Даже без поддержки своих богов тролли Диколесья представляют серьёзную угрозу. Жрица, ты пойдёшь в авангарде сил Странников. Убей столько защитников Зеб'Джунты, сколько сможешь. Шестерых знахарей и шестерых щитоломов Амани — это минимум.\",\"Это был приказ. Такие не обсуждают. {{«Атака на Зеб'Джунту». 6 знахарей, 6 щитоломов.}}\",\"— Он сказал «в авангарде», — сказала я Рафу.\",\"— Значит, я пойду перед авангардом, — сказал Раф.\",\"— Разведчики докладывают, что в крепости троллей расположено несколько самонаводящихся клинкометов. И пусть их вид не вводит тебя в заблуждение, Люси: они очень, очень опасны. Не думаю, что сейчас, когда мы начали осаду Зеб'Джунты, Амани просто так возьмут и забудут про эти машины. — Он протянул мне факел. — Возьми и подожги все осадные орудия. Четыре клинкомета. Не должно остаться ни малейшего шанса, что их будут использовать против нас.\",\"{{«Сжечь дотла!». 4 клинкомета. Факел.}}\",\"— Подлые дикари захватили в плен нескольких следопытов из передового отряда. Если ты слышала об ужасах, которые творили Амани во время Второй войны, то можешь представить, какая судьба уготована этим несчастным. Я не позволю, чтобы уши моих товарищей висели на шеях этих мерзких тварей. Вызволи их, Люси. Пятерых. И перебей всех троллей, что посмеют мешать тебе. За это — серебро. Да хоть всё моё серебро.\",\"{{«Возвращение пленников». 5 следопытов.}}\",\"Уши.\",\"Я машинально тронула свои. Обе пары. Рысьи сверху, обычные снизу. Если тролли собирают уши, то я для них ходячая коллекция. Два трофея по цене одного.\",\"— Мы не обязаны, — сказала я Рафу вполголоса, когда Келмарин наконец замолчал. — Мы не следопыты. Нам не платят жалованье. Нам платят пятьдесят медяков и «немного времени».\",\"— Там клетки, — сказал Раф. — С нашими. И тролли собирают уши.\",\"— Я знаю, что там клетки. Я спрашиваю, сколько из нас вернётся, чтобы их открыть.\",\"Асценси, не поворачивая головы, поднял руку с тремя пальцами. Подумал. Оставил три.\",\"Я выдохнула. Спорить с тремя пальцами было невозможно.\",\"Раф уже шёл к воротам. Я пошла следом.\"],\"plates\":[{\"after\":16,\"alt\":\"— Подлые дикари захватили в плен нескольких следопытов из передового отряда. Если ты слыша\",\"src\":\"/chronicle/tome/061.jpg\"}]},{\"id\":\"g2-26\",\"numeral\":\"26\",\"title\":\"Часть 26\",\"kicker\":\"Глава 2\",\"dek\":\"Зеб'Джунта не была похожа на храм.\",\"paragraphs\":[\"Зеб'Джунта не была похожа на храм.\",\"Храм строили для богов. Зеб'Джунту строили для войны. Частокол из толстых брёвен, заострённых сверху. Хижины под крышами из огромных листьев. Над входами торчали белые бивни, изогнутые, длиннее моего роста. На столбах висели факелы, и огонь в них трещал так, будто тоже ждал драки.\",\"* * *\",\"Знахари Амани и щитоломы — одиннадцатый уровень, кое-кто двенадцатый. Я чувствовала их, как чувствуют чужое тепло через стену.\",\"— Далеко! — рявкнул Раф. — Ближе, Люси!\",\"Первый знахарь держался на последней капле жизни дольше, чем имел право. Потом капли не стало.\",\"* * *\",\"Клинкомет стоял прямо посреди лагеря.\",\"Я думала, «самонаводящийся» значит что-то хитрое, механическое, со стрекочущими шестерёнками. А это была деревянная баллиста. Огромная, грубо сколоченная, с острыми кольями по бокам, как у ежа, и с вырезанной на передке мордой. Череп. Или маска. Пустые глаза смотрели прямо на меня.\",\"Келмарин сказал: «очень, очень опасны». Глядя на эту морду, я ему поверила.\",\"Я подняла факел и ткнула им в основание. Огонь не схватился сразу: пришлось держать, считать, ждать, пока сухое дерево поймёт, чего от него хотят.\",\"Пламя ползло по дереву слишком медленно для того, кто стоит в лагере троллей с горящей палкой в руке. Вокруг дрались. Раф держал щитолома где-то справа. Асценси стрелял.\",\"Дерево занялось.\",\"* * *\",\"Клетки стояли у частокола. Деревянные, тесные, сколоченные из брёвен с железными скобами. Внутри сидели наши. Следопыты, в зелёном.\",\"Я подумала об ушах на шеях троллей. И стала открывать клетки быстрее.\",\"Дальше всё смешалось. Щитолом, раненый, но злой, лез на Рафа. Где-то вспыхивал огонь на столбе. Асценси держался чуть позади. Я перебегала от клетки к клетке и не забывала прислушиваться к себе, даже когда было некогда.\",\"Я забежала за угол хижины — и замерла.\",\"В хижине были не воины. Старуха, сгорбленная, с седыми волосами, заплетёнными в косы с бусинами, и за её спиной — трое маленьких. Тролльих детей. Клыки у них только прорезались, и глаза были такие же, как у любых детей, которые слышат, что снаружи убивают. Старуха не закричала. Она выставила вперёд руки — пустые, ладонями ко мне — и сказала одно слово. Не на нашем языке. Но я его поняла, как поняла бы «пожалуйста» на любом.\",\"Мне Келмарин велел убить шестерых знахарей и шестерых щитоломов. Про старух и детей он ничего не говорил. Я опустила руку. Задёрнула за собой полог из листьев, как задёргивают дверь в чужую спальню, и вышла.\",\"Раф видел. Он ничего не сказал. Только встал так, чтобы его щит закрывал вход в эту хижину, пока мы не ушли с площади.\",\"Зеб'Джунту называли крепостью. Ещё недавно, говорил Келмарин, это была обычная деревня. Деревня никуда не делась. Её просто обнесли частоколом.\",\"Последний следопыт выбрался из клетки, худой, бледный, и посмотрел на меня так, будто я ему снилась.\",\"Сделал шаг — и сел прямо в грязь. Ноги не держали: сколько он просидел в этой клетке, скрючившись, я не хотела знать. Я опустилась рядом, положила ладони ему на рёбра и отдала то, что было. Свет вошёл в него неохотно, как вода в пересохшую землю. Раф стоял над нами спиной, щитом к лагерю, и считал вслух — не троллей, удары сердца.\",\"— Ссс… спасибо. В моих мыслях уж было, что пришёл мой час.\",\"Он сказал это странно, запинаясь, будто давно не говорил вслух. Я понимала его лучше, чем он думал. У меня каждый день такие мысли. Просто я пока не сижу в клетке.\",\"* * *\",\"У костра Странников Раф долго молчал, и это было так непохоже на него, что я перестала писать.\",\"— У меня была сестра, — сказал он наконец. Без вступления, как будто продолжал разговор, который мы начали давно. — Мирель. Младше на семь лет. Она болела той зимой, когда отец уехал за камнем на север. Жар. Три ночи.\",\"Он поковырял палкой угли.\",\"— Я тогда собрал ей лампу. Сам. Из отцовских линз и медной проволоки — чтобы свет был мягкий и не резал глаза. Она смеялась, что лампа похожа на жука. А на вторую ночь пришла жрица. Старая, с обожжёнными руками — где-то на войне обожгла. Она ничего особенного не делала. Сидела. Держала Мирель за руку. Молилась. Иногда пела.\",\"— И?\",\"— И на третью ночь Мирель умерла. — Раф сказал это ровно, как говорят то, что выучили наизусть. — А жрица не ушла. Вот это я до сих пор не понимаю. Всё уже кончилось, она могла уходить. А она сидела до утра. Со мной. Я тогда решил, что Свет — это не когда спасают. Это когда остаются.\",\"Огонь треснул. Где-то за частоколом орал тролль. Асценси, не поднимая глаз, отвинтил флягу, плеснул немного на землю у своего сапога и только потом отпил сам.\",\"— Он так делает редко, — сказал Раф тише, кивнув на мокрое пятно. — Только когда разговор о тех, кого нет. Первый глоток — земле. Не спрашивай. Я один раз спросил. Он потом три дня не разговаривал. Хотя по нему, конечно, разницы не видно.\",\"Асценси протянул флягу Рафу. Раф взял. Это было, кажется, всё, что они друг другу сказали в тот вечер.\",\"Потом я всё-таки дописала, и строчки вышли кривые, как изгородь:\",\"\\u0001[[Сжечь дотла! — 1/4 Клинкомет Амани сожжён]]\",\"\\u0001[[Атака на Зеб'Джунту — 2/6 Знахарь Амани, 2/6 Щитолом Амани]]\",\"Три клинкомета, четыре знахаря, четыре щитолома. Зеб'Джунта была ещё большой.\"],\"plates\":[{\"after\":19,\"alt\":\"Мне Келмарин велел убить шестерых знахарей и шестерых щитоломов. Про старух и детей он нич\",\"src\":\"/chronicle/tome/062.jpg\"},{\"after\":34,\"alt\":\"— Он так делает редко, — сказал Раф тише, кивнув на мокрое пятно. — Только когда разговор \",\"src\":\"/chronicle/tome/063.jpg\"},{\"after\":35,\"alt\":\"Асценси протянул флягу Рафу. Раф взял. Это было, кажется, всё, что они друг другу сказали \",\"src\":\"/chronicle/tome/064.jpg\"},{\"after\":39,\"alt\":\"Три клинкомета, четыре знахаря, четыре щитолома. Зеб'Джунта была ещё большой.\",\"src\":\"/chronicle/tome/065.jpg\"}]},{\"id\":\"g2-27\",\"numeral\":\"27\",\"title\":\"Часть 27\",\"kicker\":\"Глава 2\",\"dek\":\"Это случилось посреди Зеб'Джунты, на мощёной дорожке между двумя частоколами.\",\"paragraphs\":[\"Это случилось посреди Зеб'Джунты, на мощёной дорожке между двумя частоколами.\",\"Впереди, за забором, топтался тролль. Здоровый, зелёный, с красными перьями.\",\"Берсерк Амани. Тринадцатый уровень. Я почувствовала его ярость раньше, чем он меня заметил.\",\"— Далеко! — крикнул Раф. — Не достанешь!\",\"И тут вокруг меня вспыхнуло золотом.\",\"Одиннадцатый уровень.\",\"Zarimi был одиннадцатым. Тиург тоже. Они дошли до этой цифры и остались лежать в храме. А я её только что перешагнула, и силы во мне снова полные.\",\"Мимо меня, щитом вперёд, пробежал Раф, прямо на берсерка. Я отмерла и пошла за ним.\",\"* * *\",\"Келмарин стоял на прежнем месте. Он был десятого уровня, а я теперь одиннадцатого. Мелочь, но приятно. За его спиной, у костра, сидели пятеро в зелёном — те самые, из клеток. Один спал сидя, привалившись к другому. Тот, которого я лечила в грязи, поднял на меня глаза и коснулся пальцами своего уха. Целого. Я не сразу поняла, что это была благодарность.\",\"— Те, кого ты спасла сегодня, безмерно благодарны тебе и выразили бы свою признательность лично, если бы не были так измотаны, — сказал Келмарин. — А наше наступление продолжается.\",\"Он дал мне серебро и протянул синий мешок: «Это от них. Джутовый мешок Следопыта. Они просили передать».\",\"* * *\",\"Келмарин выставил три пары обуви. Ткань была одна — Мерцающие сапоги, с умом внутри. А на ногах у меня были Дикарские сандалии от Эрессы, с выносливостью.\",\"Я долго держала руку над сапогами. Ум — это мана. Мана — это лишняя Кара и лишнее исцеление. А жизнь — это жизнь.\",\"Я взяла Мерцающие сапоги. Сандалии сняла. Дикари обойдутся без своих сандалий, а я как-нибудь обойдусь без тридцати единиц. Надеюсь.\",\"* * *\",\"Из наручей ткань опять была одна — Дикарские поручи.\",\"Не успела я застегнуть поручи, как Келмарин уже снова говорил, протягивая мне свиток:\",\"— Следующее. Грамотное ис… — подбежавший гонец перебил его, и конец утонул в шуме.\",\"— Отдохнём потом, — сказал Раф. — Когда-нибудь. Я слышал, так бывает.\"],\"plates\":[{\"after\":6,\"alt\":\"Zarimi был одиннадцатым. Тиург тоже. Они дошли до этой цифры и остались лежать в храме. А \",\"src\":\"/chronicle/tome/066.jpg\"},{\"after\":14,\"alt\":\"Я долго держала руку над сапогами. Ум — это мана. Мана — это лишняя Кара и лишнее исцелени\",\"src\":\"/chronicle/tome/067.jpg\"}]},{\"id\":\"g2-28\",\"numeral\":\"28\",\"title\":\"Часть 28\",\"kicker\":\"Глава 2\",\"dek\":\"Сапоги ещё жали, когда Келмарин уже нашёл мне дело.\",\"paragraphs\":[\"Сапоги ещё жали, когда Келмарин уже нашёл мне дело.\",\"— Джин'Аккар — вождь всех Амани в этих землях, — сказал он, и в голосе у него не было ни торжества, ни злости, только усталость человека, который давно ждал этой минуты. — Под его руководством Зеб'Джунта из обычной деревни превратилась в защищённую крепость, которую ты видела, а разрозненные племена троллей — в организованную армию. Хотя его подручные доставили Странникам немало бед, нам удалось обескровить его воинство. Настал момент для решающего удара. — Он посмотрел мне в глаза. — Принеси мне голову этого наглого дикаря, Люси. Сюда, в Анклав. И с угрозой Амани будет покончено.\",\"Это был не вопрос. {{«Джин'Аккар». Голову — Келмарину.}}\",\"Голову.\",\"Не «победи», не «одолей», не «сразись». Принеси голову. Келмарин говорил это так спокойно, будто просил принести хлеба.\",\"Я посчитала, пока шла от костра. Голова Сапфировой Пасти. Голова Мон'земби. Клык Шшеракса. Теперь — голова вождя. Если так пойдёт дальше, к зиме у Келмарина в шатре можно будет открыть галерею, а у меня в сумке — мясную лавку. Я пошутила это про себя и не засмеялась. Шутка вышла правдивой, а правдивые шутки не смешные.\",\"Хуже всего было то, что руки привыкали. В пещере у Пасти они дрожали. У Мон'земби — мутило. Сейчас я поймала себя на том, что прикидываю, хватит ли у меня плаща, чтобы завернуть голову тролля такого роста. Прикидываю спокойно, как прикидывают, хватит ли муки на хлеб.\",\"Вождь всех Амани. Зушол был верховным жрецом, и на его совести было семь камней. Сколько камней у вождя, мне знать не хотелось.\",\"Рядом топтался Раф, щит за спиной, смотрел куда-то в сторону храма. По его лицу было видно, что он уже прикидывает, как встанет перед вождём. Я прикидывала другое: как бы не встать рядом с ним на одну строчку в книжке-эпитафии.\",\"Я приняла задание.\",\"* * *\",\"Мьюра стояла в двух шагах, и уже открывала рот, чтобы что-то мне поручить.\",\"— Буду откровенна, — сказала она, — полевая работа не относится к моим сильным сторонам. Особенно если эта работа связана с толпами троллей.\",\"Она понизила голос и заговорила быстро, как говорят, когда план придуман на ходу и страшно, что он развалится, если замолчать. Сначала порталы, сказала она, — до того, как Зеб'Джунта падёт, иначе будет поздно.\",\"\\u0001[[На пути к Джин'Аккару мы столкнулись с неожиданным препятствием: отря… чудовищных троллей, стерегущих покои своего вождя. Уверена, тебе не составит труда вообразить, какой хаос эти переростки могут посеять на поле боя. Открытое столкновение с ними обернётся катастрофой.]]\",\"\\u0001[[Но кто сказал, что мы должны сражаться с ними в открытую?]]\",\"\\u0001[[Времени на подготовку сложных заклинаний у меня нет, но кое-что придумать можно. Как я уже говорила, в руках опытного чародея магия — ужасающая сила. Даже магия телепортации. А теперь эта магия в твоих руках.]]\",\"\\u0001[[<Мьюра протягивает Вам мешочек с …>]]\",\"«Переростки». Я посмотрела на Рафа. Он был в полтора раза шире меня, но, судя по слову, рядом с этими троллями он будет выглядеть подростком.\",\"Я кивнула. Мьюра выдохнула так, будто это она шла в бой.\",\"Мне было так страшно, что сводило живот, и я всё равно знала, что пойду. Почему — сама не знаю.\"],\"plates\":[{\"after\":12,\"alt\":\"— Буду откровенна, — сказала она, — полевая работа не относится к моим сильным сторонам. О\",\"src\":\"/chronicle/tome/068.jpg\"}]},{\"id\":\"g2-29\",\"numeral\":\"29\",\"title\":\"Часть 29\",\"kicker\":\"Глава 2\",\"dek\":\"К троллям вела мощёная тропа. Вечерело. Вдоль дороги торчали факелы на высоких шестах, и огонь в них трещал та\",\"paragraphs\":[\"К троллям вела мощёная тропа. Вечерело. Вдоль дороги торчали факелы на высоких шестах, и огонь в них трещал так уютно, будто нас ждали не тролли, а ужин.\",\"Асценси ушёл вперёд, к факелам, со своей флягой и своим молчанием. Раф шёл рядом со мной, и это значило, что молчать мне не дадут. Я достала из сумки книжку.\",\"— Это что? — спросил Раф.\",\"— «Сказания троллей». Перевод Мьюры. Она говорила, что знание — сила.\",\"— Мьюра говорила, что знание надо убить вместе с ними.\",\"— Это было в следующем задании. Тогда она уже передумала.\",\"Я открыла первую страницу.\",\"\\u0001[[Сказания троллей — 1]]\",\"\\u0001[[…в день, когда волны поднялись выше небес, явились существа, каких раньше никто не видел. Были они с драконьей головой, торсом тролля и хвостом змеи, и обрушили они на нежить великий гнев. Многие достойные пали от их рук, в том числе грозный Краг'джин. Те же, кто выжили, стали испрашивать у жрецов: как боги допустили такое? Но те могли ответить лишь молчанием, поскольку наши боги хранили молчание.]]\",\"— Драконья голова, торс тролля и хвост змеи, — повторил Раф. — Кто-то очень не мог решить, кого рисовать.\",\"— Это как наша группа, — сказала я. — Голова — я, торс — Асценси, хвост — ты.\",\"— Почему я хвост?\",\"— Потому что за тобой всё время что-то тянется. Тролли, например.\",\"Раф захохотал. Громко. Асценси впереди обернулся, посмотрел на нас долгим взглядом и решил, что ему лучше не знать.\",\"\\u0001[[Сказания троллей — 2]]\",\"\\u0001[[Тогда из пасти почтенной Матери Змей раздался голос, который явил истину: «Мы разгневали великую Ула'тек, братья и сёстры! Когда духи обрушили на головы наших недругов кару и заполонили их города мёртвыми, мы не взялись за копья и топоры и не отбили свои земли у иссохших, а спрятались, как трусы, в этой долине. Мы сошли с пути, предначертанного нам кровью, и за это сами умылись в собственной крови. Истинно вам говорю, слуги самой Ула'тек явились по наши души!»]]\",\"— Из пасти, — сказала я. — Голос раздался из пасти почтенной Матери. Это у них такая форма вежливости?\",\"— Ула'тек, — сказал Раф уже серьёзнее. — Отродье Ула'тек.\",\"Я вспомнила огромного зелёного змея. Двести два здоровья. Великую Ула'тек тролли боялись, а её отродье мы сложили втроём. Я решила, что это хорошая новость, и стала читать дальше, пока не передумала.\",\"\\u0001[[Сказания троллей — 3]]\",\"\\u0001[[Слова служителя Матери Змей посеяли великую панику, но затем он молвил: «Не бойтесь, братья и сёстры! Ула'тек сохранила нам жизни, чтобы мы могли искупить свою вину. Её слуги обрушатся на наших врагов и укажут путь к новому будущему. Веруйте в её мудрость!»]]\",\"\\u0001[[Вскоре, как и говорил служитель Матери Змей, змеелюды огнём и мечом прошли по владениям нежити, после чего скрылись прочь. Тролли же, ведомые служителем, навсегда покинули долину в поисках обещанного предназначения.]]\",\"— Классика, — сказала я. — Сначала «мы все умрём», потом «не бойтесь». И всё это один и тот же жрец, без перерыва.\",\"Асценси впереди остановился и подождал нас. Посмотрел на книжку, на нас, приподнял бровь. Это у него значило: «вы там что, анекдоты читаете?»\",\"— Историю, — сказала я. — Про то, как тролли нашли себе новый дом.\",\"\\u0001[[Сказания троллей — 4]]\",\"\\u0001[[Полузабытыми тропами тролли шли вперёд, собирая под свои знамёна выживших из других, почти уничтоженных Плетью, племён, пока их вера не была вознаграждена. Матерь Змей ниспослала своему служителю видение о древнем храме, разрушенном в великую войну, но всё ещё свободном от живых и от мёртвых. Там, среди руин, служитель, которого все почитали за пророка, обратился к шедшим за ним троллям: «Здесь, братья и сёстры, будет наш новый дом, ибо того желает Матерь Змей. Но мы не станем прятаться. Мы залижем раны, наточим топоры и бросимся в бой со старыми врагами и новыми бездушными захватчиками. Мы не посрамим предков и не покажем спины ни мёртвому, ни живому. И мы…]]\",\"Дальше страница кончалась. Нижний край был обрезан, будто кто-то оторвал его.\",\"— «И мы…», — повторил Раф. — И мы что?\",\"— Не знаю. Дальше нет.\",\"— Отличная книга, — сказал Раф. — Кончается на самом интересном.\",\"Асценси молча ткнул пальцем в строчку про «новых бездушных захватчиков», потом в себя, потом в нас. Про нас, мол.\",\"— Почему это мы бездушные? — возмутилась я. — У меня одна душа. Очень берегу.\",\"Я закрыла книжку. Смешно было до тех пор, пока я не вспомнила, что «наточим топоры» — это ровно то, что ждёт нас впереди. Тролли не показывали спины ни мёртвому, ни живому. А мы шли к ним по мощёной тропе, под факелами, и тоже не собирались поворачивать.\",\"Я убрала «Сказания» обратно в сумку. Пусть лежат. Может, когда-нибудь я узнаю, что там дальше, после «И мы…».\"],\"plates\":[{\"after\":30,\"alt\":\"— Отличная книга, — сказал Раф. — Кончается на самом интересном.\",\"src\":\"/chronicle/tome/069.jpg\"}]},{\"id\":\"g2-30\",\"numeral\":\"30\",\"title\":\"Часть 30\",\"kicker\":\"Глава 2\",\"dek\":\"Зеб'Джунта горела вечерним золотом. Солнце садилось где-то за частоколом, и длинные тени от бивней над хижинам\",\"paragraphs\":[\"Зеб'Джунта горела вечерним золотом. Солнце садилось где-то за частоколом, и длинные тени от бивней над хижинами ложились на мостовую, как когти.\",\"Я шла по этим теням и держала в руке руну Мьюры.\",\"Переростки нашлись быстро. Их невозможно было не найти.\",\"Берсерк Амани, тринадцатый уровень. Он стоял посреди дороги между двумя заборами, зелёный, горбатый, в полтора раза выше Рафа, и смотрел на нас так, будто мы были его ужином, который сам пришёл к столу. Мьюра назвала их переростками. Она была слишком вежлива.\",\"Я подняла руну.\",\"Розовый свет плеснул вокруг тролля, как волна. Закрутился. Берсерк взревел, замахнулся и исчез, будто его стёрли с картины.\",\"{{Берсерки — 1 из 5}}, — сказала я себе. Голос дрожал.\",\"* * *\",\"Дальше была лестница. Широкая, каменная, со ступенями, стёртыми тысячами троллиных ног. Наверху нас уже ждали.\",\"Щитолом Амани, тринадцатый уровень.\",\"Я потянулась к мешочку — и руна обожгла холодом: рано. Ещё рано. Я попробовала снова. Снова рано. Раф держал его на щите, пока руна не остыла, и на третий раз розовый свет всё-таки сомкнулся.\",\"{{Два из пяти.}}\",\"Третий исчез на верхней площадке. Я даже не успела рассмотреть его лица. Только розовая вспышка и пустое место там, где только что стояла гора мышц.\",\"* * *\",\"Четвёртый, берсерк помельче, вылетел на нас из-за деревьев. Асценси был рядом, Раф метнулся наперерез.\",\"Розовая сфера раскрылась вокруг тролля, как цветок. Внутри неё он корчился, размахивал руками, ревел. Я видела его жёлтые клыки и злые глаза. А потом сфера схлопнулась.\",\"{{Четыре из пяти.}}\",\"Пятый стоял у подножия последней лестницы, той, что вела к самому сердцу крепости. Последний сторож вождя.\",\"Розовый свет. Рёв. Тишина.\",\"{{Пять из пяти.}} Я записала это потом, вечером, и обвела. Ни одного не убили. Почему-то от этого было легче.\",\"Лестница вела наверх. Мы поднялись.\",\"* * *\",\"Тронный зал был синим.\",\"Не небесно-синим, а тёмным, глубоким, как вода под толщей льда. Стены из тёмного камня, резные узоры, квадратные спирали, те же, что в руинах. По бокам на высоких постаментах сидели огромные жёлтые маски-идолы с оскаленными ртами и пустыми глазницами. Они смотрели на нас сверху вниз. Они смотрели так уже сотни лет.\",\"Посередине поднималась лестница. Широкая, с массивными перилами из того же синего камня. А на вершине, на троне, под красным знаком, горящим на стене, как рана, сидел он.\",\"Вождь Джин'Аккар. Тринадцатый уровень — это я почувствовала сразу, как ожог. Четыреста десять жизней — это я сосчитала уже потом, когда всё кончилось.\",\"Он не встал, когда мы вошли. Он сидел, положив руки на колени, широкий, зелёный, в доспехах из кости и кожи. Он был вождём всех Амани в этих землях. Это он превратил деревню в крепость, а племена — в армию. Он смотрел на нас так, как смотрят на мух.\",\"— Ещё одни, — сказал он. На нашем языке, чисто, с ленивой насмешкой, будто учил его не по нужде, а чтобы понимать, что о нём говорят. — Ваш капитан всегда присылает ещё одних. И всегда за головой. Знаешь, жрица, мой дед носил на шее ожерелье из эльфийских ушей. Ваш капитан хочет мою голову на шесте. Мы с вами одинаково считаем трофеи.\",\"Он наконец поднялся. Медленно, во весь рост, и маски-идолы за его спиной будто выросли вместе с ним.\",\"— Я собрал племена, которые вы и мёртвые разогнали по лесам. Я дал им стены. Когда я умру, они опять станут добычей. А ты пойдёшь домой и получишь монету. — Он оскалился. — Иди. Попробуй взять.\",\"Я прислушалась к себе. Полная. Чистая. Одна.\",\"— Ну что, — сказал Раф. — Пошли.\",\"И пошёл вверх по лестнице. Один. Щит на руке. Асценси шагнул за ним. Я осталась внизу, у подножия, там, откуда доставала.\",\"* * *\",\"Я не запомнила, как он спустился по лестнице. Я запомнила, как загорелся воздух.\",\"Наверху, у трона, всё вспыхивало жёлтым и золотым, удары сыпались, как искры из горна. Раф держал его на себе. Я чувствовала, как дрожит его жизнь, а я била снизу и не отпускала её ни на миг, как держат за руку в темноте. Маски-идолы смотрели. Красный знак на стене горел.\",\"В нём оставалось совсем немного. Я чувствовала это, как чувствуют, что свеча вот-вот догорит.\",\"Внизу, у моих ног, на синих плитах растекалась кровь. Я не знала, чья. Я не стала смотреть.\",\"Кара.\",\"Свет ударил наверх, в самое сердце этого вихря. И вихрь кончился.\",\"* * *\",\"Он лежал у подножия трона, огромный, неподвижный. Рядом валялось его оружие: длинное, с красно-оранжевым узорным лезвием. Только что оно было смертью. Теперь это было просто железо на полу.\",\"Я наклонилась над ним. Келмарин просил голову.\",\"Голова Джин'Аккара. Теперь — моя ноша, и никому её не передать. Я посмотрела на это лицо. На нём застыла ярость: оскаленные клыки, сведённые брови, взгляд, который даже сейчас не признавал поражения. Он не показал спины ни мёртвому, ни живому. Как и обещали «Сказания».\",\"Я завернула её в плащ и подумала, что он был прав в одном: мы одинаково считаем трофеи. Только у него на шее были бы уши, а у меня в сумке — голова, и разница между нами в том, кому за это заплатят.\",\"Битва для него не закончена. Я убрала голову в сумку. Пусть он доругается с Келмарином, когда мы её принесём.\",\"Раф стоял рядом, опустив щит. Асценси молчал. Маски-идолы всё так же смотрели вниз, на пустой трон.\",\"Я была на месте, живая. Я села прямо на ступени, у ног мёртвого вождя, и меня затрясло, мелко, неостановимо, как от холода. Раф сел рядом и ничего не сказал. Асценси положил руку мне на плечо. Так мы и сидели.\"],\"plates\":[{\"after\":27,\"alt\":\"— Ещё одни, — сказал он. На нашем языке, чисто, с ленивой насмешкой, будто учил его не по \",\"src\":\"/chronicle/tome/070.jpg\"},{\"after\":43,\"alt\":\"Голова Джин'Аккара. Теперь — моя ноша, и никому её не передать. Я посмотрела на это лицо. \",\"src\":\"/chronicle/tome/071.jpg\"}]},{\"id\":\"g2-31\",\"numeral\":\"31\",\"title\":\"Часть 31\",\"kicker\":\"Глава 2\",\"dek\":\"Голова Джин'Аккара лежала у меня в сумке и, кажется, всё ещё злилась. Но сначала я пошла к Мьюре. Красная стро\",\"paragraphs\":[\"Голова Джин'Аккара лежала у меня в сумке и, кажется, всё ещё злилась. Но сначала я пошла к Мьюре. Красная строчка: порталы раньше Зеб'Джунты.\",\"Мьюра встретила меня той же фразой, что и в прошлый раз, будто с тех пор ничего не случилось:\",\"— Буду откровенна, полевая работа не относится к моим сильным сторонам. Особенно если эта работа связана с толпами троллей.\",\"Она протянула руку за мешочком с волшебными рунами и заговорила, не дожидаясь ответа:\",\"— Изменение одной из координат объекта для его перемещения в пространстве — само по себе несложная задача. Другое дело, что заклинание телепортации, да ещё и самоподдерживаемое, требует немалого количества магической энергии. — Она подняла на меня глаза. — Пожалуйста, скажи, что ты избавилась от всех громил Джин'Аккара…\",\"Я протянула ей мешочек. Пустой или нет, я не проверяла. Руны своё отработали.\",\"— Всех, — сказала я. — Пятерых.\",\"— Надеюсь, тролли видели, какая участь постигла лучших воинов их драгоценного вождя, — сказала Мьюра, и глаза у неё блеснули. — Пусть знают, что магия всё ещё на нашей стороне!\",\"Она вложила мне в ладонь серебряную монету.\",\"Я сжала монету так, что ребро врезалось в ладонь. Голова в сумке ждала Келмарина. А я ещё немного постояла у палатки, просто чтобы постоять.\"],\"plates\":[{\"after\":9,\"alt\":\"Я сжала монету так, что ребро врезалось в ладонь. Голова в сумке ждала Келмарина. А я ещё \",\"src\":\"/chronicle/tome/072.jpg\"}]},{\"id\":\"g2-32\",\"numeral\":\"32\",\"title\":\"Часть 32\",\"kicker\":\"Глава 2\",\"dek\":\"Асценси остановился на краю поляны так резко, что я чуть не врезалась ему в спину.\",\"paragraphs\":[\"Асценси остановился на краю поляны так резко, что я чуть не врезалась ему в спину.\",\"Он молча вытянул руку.\",\"Поляна была светлая, тёплая, вся в мягкой траве, с оранжевыми искорками цветов. Сосны вокруг стояли высокие, рыжие от вечернего солнца. А посреди травы, никуда не торопясь, бродил медведь.\",\"Медведь Диколесья. Десятый уровень, двести сорок восемь жизней.\",\"Бурый, лохматый, круглый, как бочка с мёдом. Он что-то вынюхивал в траве и не обращал на нас никакого внимания.\",\"Асценси показал на медведя, потом на Рафа, потом на меня. Подстрахуете, мол.\",\"Раф уже снимал щит со спины.\",\"— Подстрахуем, — сказал он. — Только не дай ему меня съесть, пока ты там с ним договариваешься.\",\"Медведь наконец поднял голову, посмотрел на нас и решил, что мы ему не нравимся.\",\"Он пошёл прямо на меня.\",\"Я не побежала. Я стояла, а медведь сопел мне в бок, огромный, тёплый, пахнущий хвоей и землёй, и я думала только об одном: не бить. Только не бить. Его здоровье нужно Асценси целым. Раф встал рядом, плечом к плечу со зверем, и медведь отвлёкся на него.\",\"Асценси что-то делал. Тихо, сосредоточенно. Я не знаю, как охотники разговаривают со зверями. Наверное, так же, как я с собственной жизнью: терпеливо и с надеждой.\",\"И медведь вдруг перестал сопеть.\",\"Он тяжело, по-медвежьи сел прямо в траву и посмотрел на Асценси, а Асценси — на него.\",\"Что-то между ними случилось. Я не услышала ни слова. Я увидела лицо Асценси.\",\"Губы у него шевельнулись — беззвучно. Я и так поняла: «мой».\",\"Медведь подошёл к нему и встал рядом. Как будто всегда там стоял.\",\"Пока Асценси знакомился с медведем, Раф исчез. Вернулся он нескоро, с озера — мокрый по колено, сияющий и с таким количеством рыбы, что нёс её в щите, как в корыте.\",\"— Куда?! — спросила я. — Раф, у меня четыре сумки, и в двух уже рыба. Твоя. С прошлого раза.\",\"— Это не нам, — сказал Раф с достоинством и вывалил щит перед медведем.\",\"Медведь посмотрел на рыбу. На Рафа. Снова на рыбу. И, кажется, впервые в жизни понял, что такое любовь.\",\"Асценси, не говоря ни слова, ушёл к тому же озеру. Вернулся с тремя рыбинами — небольшими, вёрткими, — выпотрошенными и уже ободранными от чешуи. Положил их рядом с горой Рафа. Три против сорока.\",\"Асценси кивнул на свои: мелкие, жилистые, из быстрой воды. Потом на Рафовы: жирные, сонные, из тины.\",\"— Он опять про ловкость, — вздохнул Раф. — Мол, медведь должен быть быстрым. Медведь, Асценси! Медведь должен быть толстым. Это в медведе главное.\",\"Медведь съел обе кучи, не делая различий, и лёг спать посреди спора. Мне кажется, это было самое мудрое решение за весь вечер.\",\"— Как ты его назовёшь? — спросила я.\",\"Асценси задумался. Медведь тоже задумался, кажется.\",\"Асценси помотал головой и положил ладонь медведю на загривок. Сначала, мол, познакомиться.\",\"Медведь чихнул. Асценси улыбнулся — я видела это второй раз за всё время, что мы ходили вместе.\"],\"plates\":[{\"after\":15,\"alt\":\"Губы у него шевельнулись — беззвучно. Я и так поняла: «мой».\",\"src\":\"/chronicle/tome/073.jpg\"},{\"after\":15,\"alt\":\"Губы у него шевельнулись — беззвучно. Я и так поняла: «мой».\",\"src\":\"/chronicle/tome/074.jpg\"},{\"after\":21,\"alt\":\"Асценси, не говоря ни слова, ушёл к тому же озеру. Вернулся с тремя рыбинами — небольшими,\",\"src\":\"/chronicle/tome/075.jpg\"}]},{\"id\":\"g2-33\",\"numeral\":\"33\",\"title\":\"Часть 33\",\"kicker\":\"Глава 2\",\"dek\":\"Голову Джин'Аккара я несла сама. Не потому, что так требовал героический канон, а потому что Раф сказал: «Ты з\",\"paragraphs\":[\"Голову Джин'Аккара я несла сама. Не потому, что так требовал героический канон, а потому что Раф сказал: «Ты задание брала — ты и неси». Логика паладина: всё тяжёлое и неприятное должно быть на ком-то другом, а щит — это святое.\",\"Капитан Келмарин встретил нас у тех же деревянных подмостков, будто и не сходил с места всё это время. Может, и не сходил. Лицо человека, который давно перестал ждать хороших новостей. Я положила перед ним трофей. Он посмотрел на голову долго, без радости, как смотрят на счёт, который наконец оплачен, но денег всё равно жалко.\",\"— Нам никогда не удавалось истребить троллей полностью, и я сомневаюсь, что когда-нибудь удастся. Они затихают на десятилетия, а потом возвращаются с новыми… — Дальше его слова утонули где-то у меня за плечом и вынырнули только обрывком: — …крайней мере, сегодня… победу.\",\"Келмарин отсчитал мне серебряную монету и не отпустил мою руку сразу. Я почувствовала, что он хочет сказать что-то ещё. Не сказал.\",\"Зато сказал другой. Пока я стояла у подмостков, мимо прошли двое следопытов с мешками — к северу, к Зеб'Джунте, где ещё дымился частокол. Один из них был из клеток; я узнала его по тому, как он берёг левую ногу. Он остановился, посмотрел на мешок у меня в руках, где лежала голова, и сказал: «Мы туда за своими. Там остались те, кого не успели вывести». Сказал и пошёл. Не «спасибо», не «прощай». Просто — что дело ещё не закончено и у них тоже одна жизнь.\",\"Я долго смотрела им вслед. Мы убили вождя. А они шли собирать то, что после вождя осталось.\",\"Тот, из клеток, на прощание задержал взгляд на моих ушах — на верхних, рысьих, с кисточками. Долго, так что мне стало неловко.\",\"— У нас в Эльдраниле есть старый гобелен, — сказал он. — Там у одной жрицы такие же. Бабка говорила, это знак. Только не помнила, чей — Света или наоборот.\",\"И ушёл, не дожидаясь, пока я спрошу. Я потрогала кисточку. Обычная шерсть. Тёплая.\",\"Келмарин выложил на стол на выбор: Боевой топор Амани, Палица Амани, Кинжальчик, Короткий меч ополченца. Кинжальчик я рассматривала ровно один вдох — исключительно из-за названия. Есть что-то трогательное в оружии, которое заранее извиняется за своё существование.\",\"Взяла палицу.\",\"Келмарин сам подал её мне, рукоятью вперёд. Палица Амани. Одноручная, тяжёлая, и даже немного прибавляет ума. Взяв её, я поняла: теперь она моя и только моя.\",\"Кулак правосудия перекочевал в сумку. Палица легла в ладонь тяжело и честно, без всяких иллюзий насчёт того, кем я являюсь. Жрица. С дубиной троллей. Если кто-то из Высокого Совета это увидит, мне придётся объяснять, что это культурный обмен.\",\"Асценси посмотрел на палицу, на меня и закашлялся.\",\"— Я в курсе, что ты смеёшься.\",\"Он кашлянул ещё раз. Смешно.\",\"Медведь замер первым. Опустил морду, повернул её к зелени за постом и тихо, утробно заворчал. Только после этого у меня дёрнулись рысьи уши — где-то там треснула ветка. Асценси положил ладонь зверю на загривок, и медведь умолк, но с места не сдвинулся, пока из кустов не вышла косуля и не умчалась прочь. Просто лес. Но медведь его услышал раньше меня, а я раньше всех привыкла слышать.\",\"* * *\",\"Чародей Таэдрис ждал своего отчёта с видом человека, который заранее знает, что новость ему не понравится, но всё равно хочет услышать её первым. Я передала ему то, что мы добыли об Ан'балоре. Он читал. Я смотрела, как у него меняется лицо, и думала, что в этом мире лица меняются только в одну сторону.\",\"— Высокий Совет разобрал записи лорда-чародея Ан'балора, Люси. Он занимался расшифровкой Чарономикона — вернее, тех отрывков, что когда-либо попадали в руки смертных, — и, судя по всему, преуспел. Но если бы дело ограничилось этим! Этот гордец вздумал перенаправить энергию силовых линий Нордерона в одну точку, открыть пространственный разлом невероятного масштаба и призвать великую чародейскую сущность!\",\"Он отсчитал пятьдесят медяков.\",\"— Нам с этим что-то делать? — спросил Раф.\",\"— Нам с этим жить, — сказала я. — Пока что.\",\"* * *\",\"Мы вышли на дорогу, когда солнце уже садилось. Свет ложился на деревья золотом, таким густым, что его хотелось потрогать. Медведь Асценси топал рядом, всё ещё без имени, сопел и косился на меня, будто помнил, как мы познакомились. Раф поправил щит. Асценси наклонился к зверю, будто что-то сказал, — я не расслышала. А может, слов и не было.\",\"Я шла и чувствовала себя целиком: каждую царапину, каждую усталую мышцу. Одиннадцатый уровень. Палица на поясе, голова тролля сдана, чей-то великий план записан на чужих листах и лежит теперь на столе у чародея, который не знает, что с ним делать.\",\"Тролли вернутся. Ан'балор чего-то хотел. Где-то в этом мире уже растёт то, что однажды попробует меня убить, — и у него, в отличие от меня, будет сколько угодно попыток.\",\"Иногда я думаю ночью о своей жизни. Как о свече, которую несёшь через ветер, прикрывая ладонью. Ладонь обжигает, рука затекает, а опустить нельзя. И самое странное — я до сих пор не знаю, чья это свеча. Я проснулась с ней в руках на тёплых камнях и не помню, кто мне её дал. Но рядом сопит медведь без имени, Раф поправляет щит, Асценси держит ладонь у зверя на загривке, и мне не хочется, чтобы они шли дальше без меня.\",\"Вечером у костра Раф спросил меня — впервые прямо, без шутки, — что я помню. Я сказала: камни. Тёплые. Небо. И всё. Он кивнул и не стал расспрашивать дальше, только подбросил в огонь ветку.\",\"— А я помню всё, — сказал он. — Иногда это хуже.\",\"Асценси сидел напротив, медведь спал, привалившись к его ногам. Он отвинтил флягу, поднёс к губам — и не отпил. Посмотрел на меня. Открыл рот, будто собирался что-то сказать, и я замерла, как замирают, когда птица садится на руку. Он закрыл рот. Завинтил флягу. Отвернулся к медведю.\",\"Но он почти сказал. Я это видела. Раф тоже — он смотрел в огонь и очень старательно делал вид, что ничего не заметил.\",\"Я посмотрела на дорогу, уходящую вперёд, в сумерки. Может быть, однажды я перестану думать «чья». Может быть, это и есть — начать жить свою.\"],\"plates\":[{\"after\":16,\"alt\":\"Медведь замер первым. Опустил морду, повернул её к зелени за постом и тихо, утробно заворч\",\"src\":\"/chronicle/tome/076.jpg\"},{\"after\":28,\"alt\":\"Вечером у костра Раф спросил меня — впервые прямо, без шутки, — что я помню. Я сказала: ка\",\"src\":\"/chronicle/tome/077.jpg\"},{\"after\":32,\"alt\":\"Я посмотрела на дорогу, уходящую вперёд, в сумерки. Может быть, однажды я перестану думать\",\"src\":\"/chronicle/tome/078.jpg\"}]},{\"id\":\"g3-01\",\"numeral\":\"1\",\"title\":\"Часть 1\",\"kicker\":\"Глава 3\",\"dek\":\"— Люси, — сказал чародей Таэдрис, и это прозвучало не как приветствие, а как подпись под приказом. — Нам нужно\",\"paragraphs\":[\"— Люси, — сказал чародей Таэдрис, и это прозвучало не как приветствие, а как подпись под приказом. — Нам нужно найти Лорда-Чародея. Это не просьба. Это то, что просто должно быть сделано.\",\"— «Если нечто подобное явится в этот мир, хаос в шпиле Рассвета покажется детской забавой. Лучшие силы сейчас брошены на то, чтобы выяснить местонахождение Антариса и остановить его.\",\"Поскольку ты участвовала в расследовании инцидента в замке и вдобавок проявила себя в Диколесье, Верховная Чародейка решила привлечь тебя к участию в нынешнем предприятии.\",\"Увы, лорд Антарис многое почерпнул из свитков Митры, а его защитные чары подпитываются чистой энергией чародейских разломов, и нам потребовалось прибегнуть к магии этой силовой станции. Однако теперь мы знаем, где скрывается мятежный волшебник: в карманном пространстве среди множества силовых туннелей…»\",\"— А если не пойдём?\",\"Он спросил это легко, как спрашивают про погоду. Но щит точить перестал.\",\"— Тогда пойдёт кто-нибудь другой, — сказала я. — И, может быть, не вернётся. А я потом буду думать, что это было моё место.\",\"Раф подумал и снова взялся за точило. Это у него значит «ладно». Асценси ничего не сказал, только протянул руку и почесал медведя за ухом. Медведь зевнул так, что стало видно, сколько у него зубов. Много. Я тоже коснулась его тёплого бока, и он не отодвинулся. Мелочь. Но у меня от неё почему-то защипало в глазах.\",\"* * *\",\"Силовая станция встретила нас светом. Не солнечным, а магическим: в центре площади, в круглой чаше, бил столб сияния, и воздух вокруг него звенел, как натянутая струна. Мои рысьи уши прижались к голове сами, человеческие честно пытались делать вид, что всё в порядке. Пахло грозой, которая никак не может начаться.\",\"Верховная чародейка Илнурия Ар'нарет оказалась на четыре уровня выше меня и, по ощущениям, лет на четыреста. Она взглянула на мою группу: жрица, паладин со щитом, охотник с медведем. Видимо, решила, что лучшего ей сегодня не пришлют.\",\"— «Крепись, Люси: мы стоим на грани катастрофы».\",\"Она выслушала про Таэдриса, не глядя вложила мне в ладонь пятьдесят медяков, тяжёлых и холодных, и тут же забыла о них. Так платят не за подвиг, а за то, что ты пришла вовремя.\",\"— «Всё гораздо хуже, чем мы думали: хаотический разлом разрастается с невероятной скоростью, выпуская порождений эфира, а его нестабильные энергии обращают подручных Антариса в Презренных.\",\"Мы будем пытаться пробить щит Антариса и остановить рост разлома, пока это ещё возможно, а вам с гвардейцами придётся защищать нас».\",\"Она помолчала, глядя на чашу, и добавила тише, будто только для меня:\",\"— Вы будете стоять рядом со мной, пока я останавливаю ритуал разрыва. А потом вам придётся убить Антариса. И одолеть Астранимуса. Я не знаю, как сказать это мягче.\",\"— Не надо мягче, — ответила я. — Мягко я всё равно не поверю.\",\"Свет в чаше пульсировал, словно у мира сбилось сердце. Где-то за разломом прятался эльф, который хотел вытащить в наш мир что-то огромное. А передо мной стояла женщина, которая собиралась его остановить, и ей были нужны щит, лук, медведь и одна жрица с одной жизнью.\",\"Нормальная компания для конца света.\",\"Раф поймал мой взгляд и одними губами сказал: «Держись за меня». Я кивнула. Колени у меня всё равно дрожали.\"],\"plates\":[{\"after\":7,\"alt\":\"Раф подумал и снова взялся за точило. Это у него значит «ладно». Асценси ничего не сказал,\",\"src\":\"/chronicle/tome/079.jpg\"},{\"after\":11,\"alt\":\"— «Крепись, Люси: мы стоим на грани катастрофы».\",\"src\":\"/chronicle/tome/080.jpg\"}]},{\"id\":\"g3-02\",\"numeral\":\"2\",\"title\":\"Часть 2\",\"kicker\":\"Глава 3\",\"dek\":\"Перед спуском Илнурия зачитала нам предупреждение.\",\"paragraphs\":[\"Перед спуском Илнурия зачитала нам предупреждение.\",\"— «Это место наполнено нестабильной дикой магией. Помни всё, чему тебя обучили, и не теряй концентрации, иначе разделишь судьбу слуг Антариса».\",\"У меня был выбор. Честный: можно было остаться наверху, у чаши, с гвардейцами, и никто бы не назвал меня трусихой вслух. Я подумала о маме, которой здесь нет и никогда не будет. О том, что если я сейчас упаду в этих катакомбах, то некому даже будет рассказать, какой я была. И кивнула.\",\"— Я иду с вами, — сказала я Илнурии.\",\"* * *\",\"В середине зала висела сфера. Не стояла, не лежала, а именно висела, без всякой опоры и без всякого уважения к законам природы. От неё тянулись лиловые лучи к двум розовым сферам по бокам. Лучи гудели. От этого гула ныли зубы.\",\"Я оглянулась на своих. Асценси, четыреста тринадцать здоровья. Раф, пятьсот шесть. Я знала эти числа так же, как знают дыхание близкого человека во сне: по ним можно было понять, всё ли хорошо. Медведь пыхтел позади, и в этом пыхтении было больше уверенности, чем во всех нас троих вместе взятых. Свет моих ладоней ложился на камень бледным пятном. В этом зале он смотрелся как ночник в склепе. Я сжала пальцы, чтобы они не дрожали. Не помогло, но хотя бы со стороны выглядело решительно.\",\"— Мне тут не нравится, — сказал Раф.\",\"— Тебе нигде не нравится, где нет таверны.\",\"— Тут особенно.\",\"Не поспоришь.\",\"Илнурия шагнула прямо в лиловый луч. Свет облепил её, как вода, мантия вспыхнула, и голос у верховной чародейки зазвенел на весь зал:\",\"— «Не подпускайте их сюда некоторое время! Я попробую развеять защиту Антариса!»\",\"И сфера ответила. Не звуком даже, а давлением, от которого зачесалось где-то за глазами:\",\"— «Ваши потуги бесплодны, ибо меня питает чистая энергия!»\",\"Из темноты кто-то шёл.\",\"Презренный-исследователь. Одиннадцатый уровень, как у меня. Когда-то он, наверное, был одним из нас: эльф с книгами, с перьями, с планами на жизнь. Потом подошёл к разлому слишком близко. Теперь от него осталось только искривлённое тело и голод.\",\"Раф встретил его щитом. Удар, лязг, искры в лиловом полумраке. Я подняла руки и начала колдовать, стараясь не думать ни о чём, кроме заклинания. Не терять концентрации. Не терять. Где-то за спиной гудел луч, в котором стояла Илнурия, и я чувствовала его затылком, как чувствуют чужой взгляд.\",\"Презренный бросился на Рафа в последний раз, и я подняла руки.\"],\"plates\":[{\"after\":17,\"alt\":\"Раф встретил его щитом. Удар, лязг, искры в лиловом полумраке. Я подняла руки и начала кол\",\"src\":\"/chronicle/tome/081.jpg\"}]},{\"id\":\"g3-03\",\"numeral\":\"3\",\"title\":\"Часть 3\",\"kicker\":\"Глава 3\",\"dek\":\"Сфера в центре зала треснула светом, и голос, который до этого только огрызался, вдруг стал торжественным. Так\",\"paragraphs\":[\"Сфера в центре зала треснула светом, и голос, который до этого только огрызался, вдруг стал торжественным. Так говорят люди, которые долго репетировали перед зеркалом.\",\"— «Узрите Астранимуса, великую сущность магии!»\",\"Из сияния выплыло нечто. Бело-голубое, светящееся, без чётких краёв, как будто кто-то взял кусок зимнего неба и научил его ненавидеть. Тринадцатый уровень. На два выше меня. Почему от этих двух уровней у меня похолодели пальцы, я объяснить не могла.\",\"— «В нём — наше будущее. В нём надежда на процветание всего рода кель'дорай! Ужели мы не заслужили надежды на мир и благоденствие? Ужели мы обречены страдать от жестокости иноземных варваров и козней горе-союзников?»\",\"Самое неприятное, что звучало это почти разумно. Почти. Мой народ действительно много страдал. Мой народ действительно устал. И мой народ, судя по всему, всегда найдёт среди себя одного гения, который решит, что лучшее лекарство от усталости — это конец света в отдельно взятой провинции.\",\"— «Астранимус обеспечит нас энергией, достаточной, чтобы надежно оградить Нордерон от остального Азерота на следующие сотни… нет, тысячи лет! Под защитой барьера высшие эльфы смогут оправиться от бедствий, обрушившихся на наш многострадальный народ. А мир… пусть он катится в Круговерть Пустоты!»\",\"Илнурия выдохнула: «Щит пал». Ровно два слова. Мы удержали. Я смотрела на неё и не верила, что можно услышать такие слова и остаться живой.\",\"А потом из-за щита выступил сам Лорд-Чародей Антарис. Тринадцатый уровень. Мантия, высокомерие, полный набор.\",\"Я не буду врать, что помню каждый миг того боя. Помню свет. Помню, как гудит воздух. Помню, что всё время слушала собственное здоровье, как считают ступени, спускаясь в темноте. Помню, что в какой-то момент Раф пошатнулся, и у меня внутри всё оборвалось: так быстро, что я даже не успела испугаться, только уже лечила. Испугалась я потом. Через минуту. Когда стало можно.\",\"Антарис упал на колено. Я видела его лицо совсем близко: не злое, а растерянное, как у человека, который до последнего был уверен, что прав.\",\"И тут разлом дрогнул. Он начал закрываться, сворачиваться, как свиток, и потянул за собой того, кто его открыл.\",\"Медведь Асценси стоял рядом, широко расставив лапы, и тяжело дышал. Раф поднял щит. Я вдохнула и поняла, что, кажется, не дышала с самого «узрите».\",\"Потому что Антариса больше не было. А то, что он призвал, никуда не делось.\",\"Бело-голубое сияние висело посреди зала и смотрело на нас. Без глаз. Без лица. Просто смотрело. И мне вдруг стало так холодно, будто я снова стою босиком на камнях у той повозки, в самый первый день, и не помню, как там оказалась.\",\"— Люси, — тихо сказал Раф. — Щит. Сейчас.\"],\"plates\":[{\"after\":10,\"alt\":\"И тут разлом дрогнул. Он начал закрываться, сворачиваться, как свиток, и потянул за собой \",\"src\":\"/chronicle/tome/082.jpg\"}]},{\"id\":\"g3-04\",\"numeral\":\"4\",\"title\":\"Часть 4\",\"kicker\":\"Глава 3\",\"dek\":\"Разлом схлопнулся, как вода в сливе. Сначала в нём исчез Антарис. Потом погасло бело-голубое сияние Астранимус\",\"paragraphs\":[\"Разлом схлопнулся, как вода в сливе. Сначала в нём исчез Антарис. Потом погасло бело-голубое сияние Астранимуса, словно кто-то задул свечу размером с дом. Без грома. Без последнего слова. Было, и нет.\",\"Я пересчитала своих. Раф здесь, Асценси здесь, медведь здесь, я… кажется, тоже. Пересчитала ещё раз. Сама не знаю, откуда у меня эта привычка. Но пересчитываю.\",\"— Всё? — спросил Раф.\",\"— Всё, — сказала я. И сама не поверила.\",\"Асценси отвинтил флягу, глотнул и протянул её Рафу. Раф выпил. Потом медведь фыркнул и сел, и почему-то именно от этого у меня наконец подогнулись колени.\",\"* * *\",\"Илнурия ждала. Собранная, как в луче, только теперь в голосе была усталость, которую она там себе не позволяла.\",\"— «До уничтожения Солнечного Колодца мы наивно считали, что наша цивилизация достигла высшей точки своего развития. За это заблуждение наш народ заплатил непомерную цену и теперь стоит на краю забвения».\",\"— «Великая гордыня и великая глупость Антариса едва не стоили жизни всему нашему роду. Пусть он и считал, что действует из благих побуждений, это не умаляет причиненных им бедствий. Но даже если бы Антарис преуспел, какую пользу это принесло бы Нордерону? Наш народ однажды уже совершил подобную ошибку, отринув все связи с союзниками после Второй Войны, и в итоге был вынужден в одиночку противостоять армии Плети. Не это ли стало причиной краха Кель'Таласа? Твой вклад в сегодняшнюю победу неоценим, Жрица. Позволь предложить тебе заслуженную награду».\",\"Пока она говорила, по залу шли люди. Гвардейцы, которые стояли с нами у чаши, теперь просто сидели вдоль стены, сняв шлемы, и один из них смеялся, слишком громко, как смеются те, кто только что понял, что жив. Юный маг пересчитывал раненых и сбивался. Кто-то принёс воды. Разлом закрылся, а у мира ещё долго дрожали руки.\",\"«Неоценим». И тут же оценили. Я не жалуюсь, я просто отмечаю.\",\"Илнурия сама отсчитала мне серебряную монету и пятьдесят медных. Пальцы у неё были сухие и горячие, будто она всё ещё держала тот луч. Она задержала мою руку на секунду дольше, чем требовал этикет, и ничего не сказала. Мне хватило.\",\"Вечером рука сама вывела на странице одну строчку, раньше, чем я решила, что писать:\",\"{{Мы все живы.}}\",\"И обвела её. Дважды. Потом долго сидела, прижав журнал к груди, как будто это он меня спас.\",\"— Есть хочу, — сказал Раф в тишину.\",\"Никто не засмеялся. Но все пошли за ним.\"],\"plates\":[{\"after\":15,\"alt\":\"— Есть хочу, — сказал Раф в тишину.\",\"src\":\"/chronicle/tome/083.jpg\"}]},{\"id\":\"g3-05\",\"numeral\":\"5\",\"title\":\"Часть 5\",\"kicker\":\"Глава 3\",\"dek\":\"— Нет, — сказал Раф. — Сегодня — нет.\",\"paragraphs\":[\"— Нет, — сказал Раф. — Сегодня — нет.\",\"Мы стояли в стороне от золотого кольца, и принц Кат'ранис только что закончил говорить. Илнурия и какой-то Верховный Следопыт, чьё имя я так и не разобрала, вежливо смотрели в другую сторону, чтобы не мешать нам ссориться.\",\"А принц сказал вот что:\",\"— «К западу от Эльдранила, у подножия горного хребта, отделяющего Нордерон от Тирисфаля, расположен древний город, известный как Норалас.\",\"Некогда крупнейший бастион Высокорожденных в этой части материка, теперь он лежит в руинах, и причины его падения остаются для нас загадкой. Вместе с тем под городом пролегает обширная сеть силовых туннелей, что делает Норалас невероятно ценным местом.\",\"Группа исследователей во главе с Майт'алом Певцом Преданий встала лагерем неподалеку от руин, но им нужна помощь умелой мастерицы, как ты, Жрица, на случай, если развалины Нораласа скрывают какую-то опасность. Без сомнений, ты, Люси, лучше других подходишь для этого задания…»\",\"— Мы сегодня уже были в силовых туннелях, — сказал Раф. — Там жил Антарис. Помнишь, чем кончилось?\",\"— Антарис кончился.\",\"— И мы почти. Ты видела свои руки? Они до сих пор трясутся. А теперь город, который умер непонятно от чего, и учёные, которым нужна охрана «на случай опасности». Люси, когда пишут «на случай», опасность уже сидит и ждёт.\",\"— А если там правда что-то есть, — сказала я, — и учёные пойдут без нас?\",\"— Учёные сами выбрали.\",\"— Я тоже.\",\"Раф посмотрел на Асценси, ища поддержки. Асценси долго молчал, потом пожал плечами и сказал:\",\"— Не сегодня. Завтра.\",\"* * *\",\"Равелия Этрезил встретила меня так, будто я не пропадала полдня в катакомбах с призванной сущностью магии, а просто вышла за булочками.\",\"— «Конечно же, я помню про заказ хранителей рун! Да хранит их Вечное Солнце: пока они работают, мой магазин процветает!»\",\"Она ссыпала мне в ладонь пятьдесят медяков, звонко, по одной, будто пересчитывала вслух собственную благодарность.\",\"Честная торговка. Мне нравятся люди, которые не притворяются, что их благодарность бескорыстна.\",\"И тут же, без паузы, понизила голос:\",\"— «Для выполнения заказа хранителей рун требуются особые компоненты, достать которые можно только на границе рощи Вечной Весны с Диколесьем. Постоянные нападения троллей сильно сказывались на моей работе, и я благодарна Странникам, что они наконец отбросили этих дикарей от наших рубежей.\",\"Я как раз закончила работу над чернилами. Если хочешь, можешь лично отвезти заказ хранителям рун. Залезай на Руногрива: он мигом доставит тебя к Нимриэлю.\",\"Об обратном пути не беспокойся: мой скакун сам найдет дорогу домой».\",\"«Странники отбросили дикарей». Это, между прочим, про нас. Голова Джин'Аккара, палица у меня на поясе. Я впервые увидела, что из этого вышло: у Равелии снова полные полки, к ней снова ходят за чернилами, и границу рощи она называет просто «границей», без «опасной». Мы там чуть не умерли, а для неё это теперь дорога за товаром. Наверное, так и выглядит победа, когда смотришь на неё не изнутри.\",\"Руногрив был белым, как первый снег, пока по нему никто не прошёл. Я положила ладонь ему на шею, и под шкурой билась тёплая жилка. Он скосил на меня глаз и не отстранился, и я вдруг поняла, как давно ко мне никто не прикасался просто так, без боя, без лечения, без нужды.\"],\"plates\":[{\"after\":18,\"alt\":\"Честная торговка. Мне нравятся люди, которые не притворяются, что их благодарность бескоры\",\"src\":\"/chronicle/tome/084.jpg\"},{\"after\":24,\"alt\":\"Руногрив был белым, как первый снег, пока по нему никто не прошёл. Я положила ладонь ему н\",\"src\":\"/chronicle/tome/085.jpg\"}]},{\"id\":\"g3-06\",\"numeral\":\"6\",\"title\":\"Часть 6\",\"kicker\":\"Глава 3\",\"dek\":\"— Слушай, — сказал Раф, поравнявшись со мной. — А этот Норалас. Город в руинах, никто не знает, почему он пал.\",\"paragraphs\":[\"— Слушай, — сказал Раф, поравнявшись со мной. — А этот Норалас. Город в руинах, никто не знает, почему он пал. Тебя это не смущает?\",\"— Меня смущает всё, — честно ответила я. — Просто это смущает чуть больше.\",\"— Может, там просто землетрясение было, — сказал Раф без особой надежды.\",\"— Может, — сказала я. — А может, кто-то вроде Антариса. Только успешный.\",\"Раф посмотрел на Асценси, потом на медведя, как будто кто-то из них мог рассудить нас. Асценси молча отпил из фляги.\",\"* * *\",\"Я вспомнила, как наставница в Эльдраниле когда-то говорила мне: «Свет не приходит к тем, кто его требует. Он приходит к тем, кто его зовёт по имени». Тогда я фыркнула. Сейчас я позвала. Тихо, про себя, дважды, как учили, и оба раза он отозвался, и я отдала ему ещё немного себя, а он мне — себя.\",\"* * *\",\"Хранитель рун Нимриэль принял флаконы так бережно, будто это были не чернила, а чьи-то души. Проверил каждый на свет. Кивнул сам себе.\",\"— «Флаконы в целости, чернила, как всегда, на высоте. Леди Этрезил знает своё дело. А ты неплохо справляешься с ролью возничего, Люси. Вот твоя награда: всякий труд должен оплачиваться».\",\"Он отсчитал пятьдесят медных монет и вложил мне в руки свою сумку, старую, в синих чернильных пятнах, как пальцы ученика-переписчика. Отдал не глядя, как отдают вещь, с которой давно сроднились и потому не умеют прощаться долго. Честная вещь: сразу видно, что ею пользовались.\",\"Руногрив фыркнул, развернулся и, не дожидаясь прощаний, пошёл обратно, сам находя дорогу домой. Хорошо ему. У него дом есть, и дорога туда известна.\",\"У меня пока только дорога. И те, кто идёт рядом. Я обернулась на Рафа и Асценси, на медведя, который как раз пытался съесть куст, и подумала, что, может быть, дом — это не место. Может быть, это когда тебя ждут. Мысль была слишком нежная, и я быстро спрятала её подальше.\",\"— Куст несъедобный, — сказал Раф медведю.\",\"Медведь посмотрел на него и откусил ещё.\"],\"plates\":[{\"after\":1,\"alt\":\"— Меня смущает всё, — честно ответила я. — Просто это смущает чуть больше.\",\"src\":\"/chronicle/tome/086.jpg\"},{\"after\":9,\"alt\":\"— «Флаконы в целости, чернила, как всегда, на высоте. Леди Этрезил знает своё дело. А ты н\",\"src\":\"/chronicle/tome/087.jpg\"}]},{\"id\":\"g3-07\",\"numeral\":\"7\",\"title\":\"Часть 7\",\"kicker\":\"Глава 3\",\"dek\":\"Камень фамильяра треснул светом у меня в ладони раньше, чем я успела передумать.\",\"paragraphs\":[\"Камень фамильяра треснул светом у меня в ладони раньше, чем я успела передумать.\",\"Мьюра дала мне его утром в Анклаве, по дороге от Нимриэля: «Усиленный камень фамильяра. Выпусти его у Лазурного пути, пусть посмотрит, что там. А потом возвращайся ко мне». «Разведка без риска», — добавила она так легко, что я почему-то не поверила.\",\"Раф и Асценси остались у входа в пещеру. Каменный зев, факел на стене, темнота внутри густая, как остывший суп. Медведь понюхал воздух и отступил на шаг. Я его понимаю.\",\"Фамильяр нырнул в темноту, и я увидела пещеру его глазами. Свет от его тельца скользил по стенам, выхватывал из мрака то одно, то другое. Светящиеся грибы на камнях, бледные, как утопленники. А на полу — кости. Рёбра скелета, выгнутые, как прутья сломанной клетки. Чьи — непонятно. Кто их обглодал — тоже. И самое неприятное: внутри было тихо. Совсем.\",\"Иногда тишина пугает сильнее рыка. Рык хотя бы честный.\",\"Фамильяр покружил ещё немного и вернулся. Я выдохнула и только тогда заметила, что всё это время стискивала посох.\",\"— Ну что там? — спросил Раф.\",\"— Кости, грибы и никого, — сказала я. — Никого — это хуже всего.\",\"* * *\",\"Мьюра Яркопряд выслушала меня внимательно, наклонив голову, как птица.\",\"— «Пещера? Ты уверена, что она была пуста? И никаких признаков жизни? Как странно… Возможно, эти существа просто спустились с гор в поисках пропитания? Как бы то ни было, Люси, ты оказала мне большую услугу. По крайней мере, в тех краях станет гораздо спокойнее».\",\"Она достала из пояса серебряную монету и положила мне на ладонь, прижав сверху своими пальцами, будто запечатывала. «Спасибо, Люси». Просто так. Без «да хранит тебя» и без пафоса. От этого стало теплее, чем от монеты.\",\"И тут меня накрыло.\",\"Золотой свет поднялся от земли, пробежал по телу, вспыхнул где-то под сердцем и отдался в кончиках пальцев. Ощущение такое, будто внутри кто-то зажёг ещё одну свечу, и всё стало на ступеньку выше: и сила, и запас прочности, и, честно говоря, самоуважение.\",\"Двенадцатый. Я прислушалась к себе и почувствовала разницу раньше, чем сосчитала: триста восемьдесят семь здоровья вместо трёхсот двенадцати. Каждая лишняя единица — это лишний вдох в бою, лишний шанс дотянуть до следующего лечения. Цифры здесь не тщеславие. Цифры — это броня.\",\"Лагерь Странников вокруг жил своей жизнью: шатры, золотые деревья, неспешные разговоры. Рядом стояли Асценси, Раф и медведь. Раф хлопнул меня по плечу так, что я чуть не села:\",\"— С двенадцатым.\",\"Асценси, не отрываясь от медведя, поднял флягу в мою сторону. Один глоток за двенадцатый. Больше от него и не требовалось.\",\"А потом подумала о пещере. Мьюра сказала: «станет спокойнее». Но кости там кто-то обглодал, и этот кто-то ушёл, сытый, куда-то, где его никто не ищет. Мой двенадцатый уровень пришёл за то, что я посмотрела в пустую темноту и не нашла там ответа. Хорошо, что везёт. Страшно, что я не знаю, сколько ещё.\",\"Ночью я записала мелко, будто кто-то мог подсмотреть: {{Мне страшно, что везение кончится. Но сегодня я счастлива.}}\",\"Перечитала. Ничего не стала зачёркивать.\"],\"plates\":[{\"after\":17,\"alt\":\"Асценси, не отрываясь от медведя, поднял флягу в мою сторону. Один глоток за двенадцатый. \",\"src\":\"/chronicle/tome/088.jpg\"}]},{\"id\":\"g3-08\",\"numeral\":\"8\",\"title\":\"Часть 8\",\"kicker\":\"Глава 3\",\"dek\":\"— Я не буду их убивать, — сказала я. — Не так. Не по счёту.\",\"paragraphs\":[\"— Я не буду их убивать, — сказала я. — Не так. Не по счёту.\",\"Кин Светлоокий моргнул. Он, кажется, ждал чего угодно, только не этого. Костёр между нами потрескивал, за синими шатрами стоял красный лес, и где-то в нём, за деревьями, лежал Норалас.\",\"Но это я забегаю вперёд.\",\"* * *\",\"Здесь осень была другой. Не золотой, как в Эльдраниле, а красной. Листья горели над головой цветом свежей раны, и даже небо казалось подкрашенным. Так выглядит место, которое ещё не решило, убить тебя или просто напугать.\",\"Майт'ал Певец Преданий оказался двадцатого уровня, на восемь выше меня. Он сунул мне пятьдесят медных за то, что я вообще добралась, ласково и рассеянно, глазами уже в руинах, и сразу заговорил о главном. Для него главным было искусство.\",\"— «Старые города Высокорожденных хранят множество произведений искусства, представляющих значительную историческую ценность. Тебе, например, известно, что филигрань, которой украшены волшебные лампы в Нораласе, не встречается более нигде во всем северном Лордероне?\",\"Люси, если найдешь среди руин неповрежденные лампы — приноси мне. Наследие наших предков не должно валяться под ворохом листьев».\",\"Десять мерцающих ламп. За них Сребротканый плащ или Нораласский, на выбор. А ещё маячок: отнести в руины, измерить плотность силовых полей. Эльдранил эльфы покинули, когда основывали Кель'Талас, а Норалас жил ещё по меньшей мере пять столетий, пока что-то не превратило его в руины. Догадки у Майт'ала есть, данных нет. Мимоходом он предупредил про «локальные аномалии». Что это значит, он и сам, кажется, не знал.\",\"Кин был моложе, нервнее и искреннее. Пауков он видел. Много.\",\"— «Люси, тебе когда-нибудь доводилось видеть таких жутких пауков? Не удивлюсь, если окажется, что эти твари и погубили город. Они здесь повсюду! Ты окажешь неоценимую помощь делу экспедиции, если уменьшишь число ползучих гадов в округе».\",\"Десяток тенепутов. «Пожалуйста», — добавил он, так по-детски, что я записала это слово в журнал вместе с числом.\",\"— «Майт'ал говорит, здесь покоятся Высокорожденные, не пережившие тягот путешествия по землям Лордерона, и те, кто отказался покинуть Норалас вслед за королем Дат'Ремаром. Их души ныне ослеплены яростью, обращенной против тех, кто осмелился ступить в их город.\",\"Наша спутница, служительница Света, не хочет признавать очевидное, но этим несчастным уже не помочь. Срази всех, кто встретится тебе на пути. Пусть хотя бы так они обретут заслуженный покой».\",\"Восемь скорбящих плакальщиц. Восемь обречённых призраков. Он назвал числа так, будто ему самому было стыдно.\",\"* * *\",\"— Я не буду их убивать, — сказала я. — Не так. Не по счёту.\",\"— Люси, — тихо сказал Кин. — Они нападут первыми. Они нападают на всех.\",\"— Это мой народ. Те, кто остался, когда все ушли. Они до сих пор ждут кого-то в городе, где некого ждать. А мне говорят: восемь и восемь, и они обретут покой. Откуда вы знаете, что обретут? Может, это просто удобная фраза, чтобы спать по ночам.\",\"Кин опустил глаза. Ответа у него не было. Ответ нашёлся у Рафа, и мне он не понравился.\",\"— А если не мы, — сказал он, — то кто? Леанин? Она им молитвы читает, а они её чуть не утащили на прошлой неделе. Мне Феверас рассказал. — Он помолчал. — Я тоже не хочу. Но я лучше подниму щит перед призраком, чем потом буду поднимать Леанин.\",\"— Ты правда так думаешь?\",\"— Нет, — честно сказал Раф. — Я думаю, что это мерзко. Но кто-то пойдёт туда в любом случае. Пусть хотя бы тот, кому их жалко.\",\"Асценси сидел у огня, крутил в пальцах стрелу и молчал. Потом поднял голову и посмотрел на меня. Без слов. Он умеет так смотреть: «решай сама, я пойду за тобой в любом случае».\",\"Я кивнула. Не потому, что согласилась. Потому что Раф был прав в самом страшном: если туда пойдёт кто-то, кому их не жалко, им будет хуже.\",\"Вечером я записала: {{8 плакальщиц, 8 призраков.}} Перо остановилось на слове «призраков» так надолго, что на бумаге расплылась клякса. Я её не стёрла. Пусть будет. Медведь улёгся у костра. Раф молча проверял ремни на щите. В красном лесу было тихо.\",\"Слишком тихо. Я долго лежала с открытыми глазами и слушала, сама не знаю что. Под утро мне показалось, что я слышу шорох многих лап. Может быть, показалось.\"],\"plates\":[{\"after\":17,\"alt\":\"— Люси, — тихо сказал Кин. — Они нападут первыми. Они нападают на всех.\",\"src\":\"/chronicle/tome/089.jpg\"},{\"after\":26,\"alt\":\"Слишком тихо. Я долго лежала с открытыми глазами и слушала, сама не знаю что. Под утро мне\",\"src\":\"/chronicle/tome/090.jpg\"}]},{\"id\":\"g3-09\",\"numeral\":\"9\",\"title\":\"Часть 9\",\"kicker\":\"Глава 3\",\"dek\":\"Норалас встретил нас белыми колоннами.\",\"paragraphs\":[\"Норалас встретил нас белыми колоннами.\",\"Они стояли вдоль мостовой, высокие, гордые, будто их ещё вчера мыли к празднику. Только праздник закончился несколько веков назад, а гости так и не разошлись. По камням стелилась красная листва, шуршала под ногами, как старая бумага. Впереди темнели эльфийские залы с зелёными арками. Когда-то там, наверное, смеялись. Сейчас там было тихо так, что я слышала, как бьётся моё собственное сердце.\",\"Это был город моего народа. И он был мёртв.\",\"* * *\",\"Первая лампа нашлась у одного из тех, кто тут обитал. Я вынула её из холодных пальцев, которые уже не были пальцами, и мне пришлось на секунду закрыть глаза. Мерцающая магическая лампа. Изящный светильник, навсегда угасший несколько столетий назад.\",\"Я повертела её в руках. Тонкая филигрань, та самая, которой больше нигде во всём Нордероне не встретишь. Красиво. И мёртво. Навсегда угасший. Не «погасший», а «угасший», как угасают люди. Я положила её в сумку осторожно, будто она могла обидеться.\",\"* * *\",\"Скорбящая плакальщица выплыла из-за колонны, и воздух вокруг неё стал холоднее. Тёмная призрачная фигура, четырнадцатый уровень. На два выше меня. Она не кричала и не рычала, а скорбела, и это было хуже любого рыка.\",\"Раф шагнул вперёд в своей красной тунике, поднял щит и принял её на себя. Звук удара был глухой, как стук в закрытую дверь склепа. Асценси натянул тетиву. Медведь глухо заворчал.\",\"Я подняла руки.\",\"Кара. Свет собрался в ладонях, тяжёлый, горячий, и сорвался вперёд. Странное ощущение — бить Светом в тех, кого он когда-то, может быть, согревал. Кин говорил, что служительница Света не хочет признавать очевидное. Я признавала. Я просто не обязана была от этого радоваться.\",\"* * *\",\"К привалу счёт был такой: четыре лампы, три призрака. Никогда ещё счёт не был таким тяжёлым.\",\"Где-то впереди, за зелёными арками, кто-то тихо плакал. Не живой. Давно уже не живой. И я вдруг поняла, что плачу вместе с ней, молча, сквозь зубы, потому что плакать в бою нельзя. Слёзы мешают целиться. Я вытерла лицо рукавом.\",\"— Туда? — спросил Раф.\",\"— Туда.\"],\"plates\":[{\"after\":7,\"alt\":\"Скорбящая плакальщица выплыла из-за колонны, и воздух вокруг неё стал холоднее. Тёмная при\",\"src\":\"/chronicle/tome/091.jpg\"}]},{\"id\":\"g3-10\",\"numeral\":\"10\",\"title\":\"Часть 10\",\"kicker\":\"Глава 3\",\"dek\":\"Чаромантический маячок оказался маленьким, прохладным и неприятно живым. Он тихо пульсировал в ладони, как вто\",\"paragraphs\":[\"Чаромантический маячок оказался маленьким, прохладным и неприятно живым. Он тихо пульсировал в ладони, как второе сердце, только чужое. Майт'алу нужны были данные. Мне нужно было, чтобы данные не кусались.\",\"* * *\",\"Восток, юг, запад. Круглый зал с колоннами, где маячок дрогнул и успокоился. Ступенька на юге, где я села и записала всё сразу, пока не стало слишком больно помнить, а Раф стоял рядом и ничего не спрашивал. За это я его люблю. Тенепуты лезли из трещин в мостовой деловито, как рабочие на смене; плакальщицы проступали из воздуха, как пятна сырости на стене. Кара — и короткая пустота под рёбрами, пока Свет возвращается; щит, лечение, снова щит, и к вечеру руки гудели, как после целого дня у корыта. Пальцы пахли гарью и паутиной.\",\"К закату пауков было десять. Кин будет доволен. Я, честно говоря, тоже, хотя не скажу ему об этом. Плакальщиц и призраков оставалось уже немного.\",\"Последнюю лампу я нашла в детской. Я поняла, что это детская, по маленькой кроватке из белого камня. Я долго держала лампу в руках и не могла положить её в сумку рядом с остальными. Десять угасших огоньков. Майт'ал получит свою филигрань. А город так и останется тёмным.\",\"На западе маячок замолчал. Всё, что он хотел узнать, он узнал. Я — нет.\",\"* * *\",\"Среди обломков, у подножия рухнувшей колонны, что-то блеснуло. Я присела. Странная конструкция, похожая на астролябию: в центре гранёный кристалл, всё ещё светящийся мягко, как уголь под пеплом, а вокруг золотые изогнутые лезвия, застывшие на полуобороте. Сломанное устройство Высокорожденных. Единственная вещь в этом городе, которая ещё светилась.\",\"Майт'ал обещал за такое на выбор Шляпу смотрителя, Убор рыскателя или Чёрный барбют. Я сразу подумала о шляпе.\",\"— Не трогай, — сказал Раф.\",\"— Мне надо его осмотреть.\",\"— Люси. В этом городе всё, что светится, плохо кончается.\",\"— Я только посмотрю.\",\"Сначала, по-хорошему, надо было его послушать.\",\"Кристалл был тёплый. Как щека спящего. Я осмотрела его, провела пальцами по лезвиям и убрала руку слишком поздно.\",\"Город, кажется, только этого и ждал.\",\"Из-за колонн шагнул Страж Высокорожденных. Пятнадцатый уровень. На три выше меня. Он не скорбел, как плакальщицы, и не метался, как призраки. Он просто пришёл охранять то, что ему велели охранять века назад. Добросовестный. Хуже не придумаешь.\",\"— Устройство не покидает зала, — сказал он. Голос был сухой, как пыль на постаменте. — Первый Чародей вернётся за ним.\",\"— Он не вернётся, — сказала я. — Простите.\",\"— Устройство не покидает зала, — повторил Страж и поднял клинок. Он не спорил. Ему было не с чем спорить: всё, что у него осталось, — одна фраза и пост, с которого никто так и не снял.\",\"Раф встал между нами раньше, чем я успела испугаться как следует. Щит, удар, гул по всему залу. Медведь рядом, Асценси за спиной, я с Карой в ладонях. Я не буду пересказывать каждый удар. Я слушала свою жизнь и жизнь Рафа, как слушают дыхание больного ночью, и больше ни о чём не думала. Один раз Страж достал меня, и боль прошла через плечо, белая и горячая, до самых зубов. Я не закричала. Не потому что сильная. Потому что не было воздуха.\",\"Когда всё стихло, на камнях остались обломки.\",\"Я собрала их осторожно, как собирают осколки чужой разбитой чашки. Теперь их надо отнести Майт'алу. Пусть он разбирается, что за технологии ушли вместе с этим городом, и почему их до сих пор кто-то стережёт.\",\"— Я же говорил, — сказал Раф. Без злости. Он сидел на ступени и дул на разбитые костяшки.\",\"— Говорил.\",\"— В следующий раз послушаешь?\",\"— Нет, — честно сказала я. — Но в следующий раз сначала поставлю на тебя щит.\",\"Плечо ныло, но лечение уже затянуло его. Я прислушалась к себе: всё вернулось, до последней капли. Руки дрожали ещё долго. Все живы.\",\"А город всё молчал о том, что его убило.\",\"Я держала в руках обломки и не могла отделаться от ощущения, что Страж был не последним. Откуда оно — не знаю.\"],\"plates\":[{\"after\":4,\"alt\":\"Последнюю лампу я нашла в детской. Я поняла, что это детская, по маленькой кроватке из бел\",\"src\":\"/chronicle/tome/092.jpg\"},{\"after\":18,\"alt\":\"— Он не вернётся, — сказала я. — Простите.\",\"src\":\"/chronicle/tome/093.jpg\"}]},{\"id\":\"g3-11\",\"numeral\":\"11\",\"title\":\"Часть 11\",\"kicker\":\"Глава 3\",\"dek\":\"Я сжала камень возвращения.\",\"paragraphs\":[\"Я сжала камень возвращения.\",\"Мир дрогнул, вывернулся наизнанку и собрался обратно уже без Нораласа: без пыли, без плакальщиц, без призраков, которые никак не могут решить, умерли они или просто обиделись. Под ногами оказалась мощёная площадь. Тёплый камень, ровный, без единой паутины. Даже непривычно.\",\"Гавань Эльдранила. Исходная точка. Место, где я когда-то очнулась, не помня, как сюда попала, и с весьма смутным представлением о том, что делать дальше. Это была чья-то чужая жизнь, и я донашивала её, как чужое платье.\",\"Я посмотрела вниз. На себя.\",\"Длинная чёрная роба до самых камней, с золотой отделкой, которая ловила солнце и отдавала его обратно скромно, без хвастовства. Пояс. На плече золотой наплечник, такой, будто его носят люди, у которых есть свита. Тёмные волосы. Шрамов не видно, но я их помню.\",\"Я честно попыталась вспомнить ту девочку, которая вышла отсюда в первый раз. Не получилось. Вместо неё на площади стояла какая-то строгая особа в чёрном с золотом, которая выглядела так, словно знает, что делает. Она не знала, конечно. Но выглядела.\",\"Хотя нет. Кое-что от неё осталось. Страх. Тот самый, первый, когда я поняла, что жизнь у меня одна и запасной не выдадут. Он никуда не делся, просто перестал кричать. Теперь он сидит тихо, где-то под рёбрами, и каждый раз, когда я делаю шаг в темноту, вежливо напоминает о себе. Я научилась с ним ходить. Не победить, нет. Просто ходить рядом.\",\"Я оглянулась по привычке, ища Рафа и Асценси. Их здесь не было: они остались там, за порталом, и я вдруг почувствовала это не головой, а телом, как пустое место у плеча, где обычно стоит щит. Только я, площадь и листва, которая падала медленно, никуда не торопясь. Ей-то можно. У неё этих осеней много.\",\"Я села на край ограды, достала журнал и, как делала каждый раз после долгой дороги, записала себя целиком, чтобы убедиться, что я есть:\",\"{{Люси. Двенадцатый уровень. Здоровье 437, всё. Мана 869, вся. Опыт 3494 из 9800.}}\",\"Иногда по ночам, перед тем как уснуть, я представляю, что умерла и открываю глаза снова, у той же повозки, и это не облегчение, а ужас: потому что тогда всё, что я любила здесь, было бы ненастоящим. Я гоню эту мысль и радуюсь, что жизнь одна. А потом пугаюсь, что радуюсь.\",\"Я поправила наплечник, хотя он в этом не нуждался.\",\"Платье, кажется, начинало садиться по фигуре.\"],\"plates\":[{\"after\":5,\"alt\":\"Я честно попыталась вспомнить ту девочку, которая вышла отсюда в первый раз. Не получилось\",\"src\":\"/chronicle/tome/094.jpg\"},{\"after\":5,\"alt\":\"Я честно попыталась вспомнить ту девочку, которая вышла отсюда в первый раз. Не получилось\",\"src\":\"/chronicle/tome/095.jpg\"}]},{\"id\":\"g3-12\",\"numeral\":\"12\",\"title\":\"Часть 12\",\"kicker\":\"Глава 3\",\"dek\":\"Предмет в моих ладонях наполовину превратился в свет и пыль, когда я дёрнулась. Совсем чуть-чуть. Этого хватил\",\"paragraphs\":[\"Предмет в моих ладонях наполовину превратился в свет и пыль, когда я дёрнулась. Совсем чуть-чуть. Этого хватило: свет погас, пыль осыпалась обратно, а вещь осталась целой и смотрела на меня из ладоней с некоторым укором.\",\"Четыре сумки: шахтёрская, испачканная чёрная, рюкзак и большая, и все полны барахла. Что-то ушло торговцу. Остальное я распыляла, стоя смирно, как приличная жрица: держать вещь, слушать магию внутри и отпускать её без рывка. В мешочек ссыпалась Странная пыль, мерцающая, как растёртые звёзды, рядом легла Малая магическая субстанция, пахнущая грозой. Три малые слипаются в одну Большую, Большая снова распадается на три.\",\"Потом мне попался он. Кулак правосудия. Одноручная булава, удар от девяти до тринадцати, два и семь десятых на замах, плюс два к интеллекту, вещь шестнадцатого уровня, прочность пятьдесят пять из пятидесяти пяти. Я знала о нём всё, как знают о старом друге.\",\"— Двенадцать серебра и тридцать меди, — сказал торговец. И добавил другим голосом, мастерским: — Таких я у вас ещё не видел, леди. У вас ещё нет такой модели в гардеробе. Жаль будет, если уйдёт.\",\"«У вас еще нет такой модели». Игра, как всегда у торговцев, в вежливость и в выгоду одновременно. Модели у меня нет, а воспоминания есть. Этим кулаком я отмахивалась от первых волков, пока кто-то другой их убивал. С ним в руке я впервые поняла, что могу не умереть.\",\"Я покачала головой. Торговец понимающе отвернулся. В кошельке осталось около золотого и тринадцати серебряных. Для меня почти состояние. Для любого нормального эльфа — сходить на рынок за хлебом.\",\"Кстати, о хлебе.\",\"* * *\",\"Аллинар Янтарный Взор стоял под стеной у очагов и не обернулся.\",\"— Готовить хочешь? Тогда сначала вымой руки. Потом понюхай вот это.\",\"Он заставил меня назвать каждую траву в чаше и ни разу не засмеялся, даже когда я перепутала тмин с чем-то, что, кажется, было кормом для лошадей. Потом взял мои руки в свои, тёплые, в муке: «Тесто, как и люди, не любит, когда на него злятся».\",\"Четыре рецепта: Жареная кабанина, Яйцо с травами, Волчатина на углях, Хлеб с пряностями. Мука и травы у меня были, сорок того и сорок другого. Значит, сорок буханок.\",\"Жрица Света, гроза пауков Нораласа, повелительница четырёх сумок стояла в чёрной робе с золотом и пекла хлеб. Все сорок испеклись, ни одна не подгорела. Аллинар отломил корочку, пожевал и кивнул. Мне хватило.\",\"{{Кулинария. 1 из 75. Аллинар говорит, у меня лёгкие руки. Врёт, наверное. Но приятно.}}\",\"Сумка впервые за всё время пахла не кровью и не паутиной. Хлеб не может меня убить. Впервые за много дней я полчаса ни к чему не прислушивалась.\",\"Запах хлеба на секунду сделал что-то странное. Мне показалось — показалось! — что я вижу окно, утро и чью-то руку, которая отламывает горбушку и протягивает мне. Я потянулась за этой картинкой, как за горячим, — и она погасла. Остался только хлеб. И, к моему удивлению, не грусть, а что-то тёплое. Как будто кто-то когда-то меня кормил, и этого мне пока достаточно.\",\"Аллинар снял с огня последнюю буханку и протянул мне. Горячую. Я обожгла пальцы и не выпустила.\"],\"plates\":[{\"after\":4,\"alt\":\"«У вас еще нет такой модели». Игра, как всегда у торговцев, в вежливость и в выгоду одновр\",\"src\":\"/chronicle/tome/096.jpg\"},{\"after\":10,\"alt\":\"Он заставил меня назвать каждую траву в чаше и ни разу не засмеялся, даже когда я перепута\",\"src\":\"/chronicle/tome/097.jpg\"}]},{\"id\":\"g3-13\",\"numeral\":\"13\",\"title\":\"Часть 13\",\"kicker\":\"Глава 3\",\"dek\":\"— Хлеб ты уже знаешь, — сказал Аллинар и сам, пальцами в муке, перелистнул страницу моей книги рецептов. — Рук\",\"paragraphs\":[\"— Хлеб ты уже знаешь, — сказал Аллинар и сам, пальцами в муке, перелистнул страницу моей книги рецептов. — Руки запомнили. Дальше он тебя не научит, только накормит.\",\"Тридцать восемь из семидесяти пяти. Хлеб с пряностями поблёк на странице, как старая выцветшая гравюра. Вместо него Аллинар продиктовал Волчатину с пряностями и Блестящую рыбку. Сырых блестящих рыбок у меня оказалось тридцать две. Когда я их насобирала, не помню.\",\"— И не отходи от огня, — сказал он. — Рыба не прощает, когда о ней забывают.\",\"Рыбка шкворчала на огне, чешуя блестела даже поджаренная, жар от углей наполнял ладони и отпускал снова. Знаешь, что будет дальше: ещё одна рыбка. Никаких Стражей Высокорождённых из-за угла.\",\"Раз уж рыба теперь моя тема, логично было научиться её ловить.\",\"Финдейн, светловолосый эльф с лицом человека, которому некуда спешить, посмотрел на меня и сказал:\",\"— Привет! Готова учиться?\",\"— Ученица. Пятый уровень у тебя есть, это видно по тому, как ты стоишь. Одно серебро. — Он вложил мне в руки удочку и поправил хват. — Ты держишь её, как оружие. Отпусти. Она не враг.\",\"В кошельке лежали золотой, девятнадцать серебряных и сорок четыре медяка. Я отдала одно серебро, и Финдейн убрал его, не глядя, как будто дело было не в монете.\",\"Я отпустила леску. И впервые за много дней мои руки перестали ждать удара.\",\"Поплавок дрогнул. Я не дёрнула. Сама не знаю, откуда руки это поняли.\"],\"plates\":[{\"after\":3,\"alt\":\"Рыбка шкворчала на огне, чешуя блестела даже поджаренная, жар от углей наполнял ладони и о\",\"src\":\"/chronicle/tome/098.jpg\"},{\"after\":5,\"alt\":\"Финдейн, светловолосый эльф с лицом человека, которому некуда спешить, посмотрел на меня и\",\"src\":\"/chronicle/tome/099.jpg\"},{\"after\":9,\"alt\":\"Я отпустила леску. И впервые за много дней мои руки перестали ждать удара.\",\"src\":\"/chronicle/tome/100.jpg\"}]},{\"id\":\"g3-14\",\"numeral\":\"14\",\"title\":\"Часть 14\",\"kicker\":\"Глава 3\",\"dek\":\"— Повар-подмастерье, — громко сказал Аллинар, чтобы слышали у соседних очагов. — Поздравляю, Люси.\",\"paragraphs\":[\"— Повар-подмастерье, — громко сказал Аллинар, чтобы слышали у соседних очагов. — Поздравляю, Люси.\",\"Раф и Асценси появились у очага, как только запахло готовым, — точно, как медведь.\",\"— Повар, — сказал Раф с уважением. — Значит, теперь можно заказывать. Мне — чтобы держало. Что-нибудь, после чего паук может хоть весь день кусать в плечо.\",\"Асценси молча выложил на стол рядом с моей мукой свежую шкурку — ободранную аккуратно, как он умеет, — и маленькую серебристую рыбку из гаванского пруда. Рыбку подвинул ко мне. Шкурку — себе.\",\"— Рыбка — значит, лёгкое, — перевёл Раф. — Шкурка — значит, ему некогда, он шьёт новые наручи. Из той кожи, что ты ему тогда, на дороге у Элессара, в руки сгрузила. Он до сих пор её режет. Экономный.\",\"— Я испекла хлеб, — сказала я. — Просто хлеб. Он не для выносливости и не для ловкости. Он для того, чтобы его ели.\",\"Они переглянулись. Раф отломил кусок. Асценси отломил кусок. Спор закончился сам собой, как заканчиваются все споры, в которые положили горячий хлеб.\",\"На последних страницах журнала я веду отдельный список: то, чем горжусь. Завела его в шутку, потом перестала шутить. Каждая строчка стоит столько очков, сколько я сама себе назначу. Я вписала: {{Повар-подмастерье. 20.10.26. +10.}} Итог: {{340.}}\",\"Свежее всего сверху сиял «Повар-подмастерье». Под ним вчерашние: «50 заданий» и «10-й уровень». Вчерашние, а будто год назад. Пятьдесят раз кто-то просил меня сходить, принести, убить, вернуться, и я каждый раз возвращалась живая. За это я себе очков не ставлю. Боюсь сглазить.\",\"А ниже, отдельно, — «Стиляга: запястья III», сто разных наручей. Дата давняя, раньше, чем я себя помню здесь. Как она туда попала, я не знаю. Кто-то до меня носил эти руки и менял наручи сто раз. Теперь руки мои, и я учусь ими печь хлеб.\",\"Руки пахли хлебом и дымом. А здесь было тепло. И мне вдруг стало так страшно потерять это тепло, что я сидела и грела над углями пальцы, пока страх не улёгся обратно под рёбра.\",\"Хватит. Отдохнула.\",\"Я встала, отряхнула муку с робы и пошла собирать сумки. В сумке лежали обломки чужой технологии, в журнале висели незакрытые строчки, и Норалас ждал.\"],\"plates\":[{\"after\":6,\"alt\":\"Они переглянулись. Раф отломил кусок. Асценси отломил кусок. Спор закончился сам собой, ка\",\"src\":\"/chronicle/tome/101.jpg\"}]},{\"id\":\"g3-15\",\"numeral\":\"15\",\"title\":\"Часть 15\",\"kicker\":\"Глава 3\",\"dek\":\"— Она вернулась, — объявил Раф медведю. — Я же говорил. Ставь.\",\"paragraphs\":[\"— Она вернулась, — объявил Раф медведю. — Я же говорил. Ставь.\",\"Лагерь Певца Преданий, то же рыжее небо, те же синие шатры. У огня сидели мои. Раф, щит прислонён к бревну, как спящая собака. Асценси, у его ног медведь, растянувшийся во весь рост.\",\"Асценси, не поднимая головы, отпил из фляги. Это у него вместо «привет».\",\"— Медведь ничего не ставил, — сказала я. — У него нет денег. У него даже имени нет.\",\"— Мы как раз решали, — сказал Раф. — Я предложил «Палица». В честь Палицы Амани. Тяжёлый, бьёт больно, Келмарин бы одобрил.\",\"— Келмарин бы спросил, где голова.\",\"Я сказала это легко, и только потом услышала. Где голова. Я несла Келмарину голову вождя в мешке, и мешок бил меня по бедру всю дорогу, и к вечеру я перестала это замечать. Вот что меня напугало: не голова. То, что я перестала замечать.\",\"— Нет, — сказал Асценси про «Палицу». Первое его слово за вечер, и оно закрыло тему.\",\"Я засмеялась, и смех был настоящий, а под ним, как под тонким льдом, стояла чёрная вода.\",\"* * *\",\"Лампы стояли у Майт'ала вдоль стола, все десять, и арканолог-исследователь сидел над ними с лупой и что-то зарисовывал, высунув кончик языка. Над одной, той, из детской, Майт'ал повесил табличку: «Норалас. Жилой квартал». Город всё ещё был тёмным. Но у него появилась первая строчка в чьей-то книге.\",\"За лампы, «Искусство прошлого», я выбрала накидку смотрителя, тонкую и тёмную, как вечерний воздух. За замеры маячка он добавил пояс Ночного Ветра. Обломки устройства Майт'ал принял, как принимают из рук ребёнка разбитую семейную чашу.\",\"— Мастера, которые это делали, считали себя выше смерти. А мы собираем их по кусочкам из паутины.\",\"За «Технологии ушедших» я взяла Шляпу смотрителя. Ту самую, о которой думала у колонны, пока Страж не вышел.\",\"Кин за пауков протянул обгоревший жезл, тёплый, будто огонь в нём не до конца уснул.\",\"— Мне они тоже снятся, — сказал он вдруг. — Возьми. Он помнит пламя.\",\"— Жрица с огнём, — сказал Раф. — Мир сошёл с ума.\",\"* * *\",\"Фолианты не нужно было таскать на себе: достаточно было коснуться их руной, и они уходили, как вода в песок, туда, к Майт'алу, в лагерь, в безопасность. Так он объяснил, вкладывая мне в ладонь плоскую холодную руну. Четыре книги в башне на востоке. Он не объяснил, что книги будут против.\",\"Лестница вилась вверх, ступени истёрты посередине тысячами ног, которые давно стали пылью. Медведь шёл первым и чихал каждый раз, когда задевал носом паутину. Это было единственное смешное в этой башне.\",\"Библиотека открылась внезапно: полки до потолка, пыль в луче света, как снег, который забыл упасть. Мне было больно видеть, сколько книг здесь брошено.\",\"А потом одна взлетела с полки. Страницы захлопали, как крылья, и из неё полился колючий свет. Первое же заклинание обожгло меня так, что я отшатнулась за Рафа.\",\"— Я пришла с уважением!\",\"— Скажи ей, что ты прилежная, — отозвался Раф, принимая страницы на щит. — Книги любят прилежных.\",\"Из угла выполз Руинный тенепут, и мне стало не до смеха. Я лечила Рафа и чувствовала, как сердце колотится о рёбра. Под потолком башни, где до выхода далеко.\",\"Когда первый фолиант упал и затих, я коснулась его руной, и он исчез. Мне вдруг стало его жалко: столько веков стеречь свои страницы. Остальные три ушли так же, после такой же драки.\",\"* * *\",\"Леанин Рождённая Звёздами просила о тихом: фляга священного масла, связка благовоний, сундук с саванами. «Последние ритуалы. Им нужно проводить, Люси». Сундук стоял под деревом, и Раф поднял его, как поднимают гроб: молча, двумя руками.\",\"Кто-то когда-то шил эти саваны, стежок к стежку, на будущее. Будущее наступило, только надевать стало некому.\",\"* * *\",\"Тайник арканиста мы нашли случайно: сундук в стене, а в нём жезл, весь в камнях, хрупкий, как чужой младенец.\",\"Хозяйка проступила из воздуха, как пятно на ткани. Призрачная эльфийка с лицом, на котором навсегда застыло «ну и кто это у нас тут». Деллиана Свет Затмения.\",\"— Ты, я вижу, несколько огорчена подобным поворотом событий, — сказала она, и улыбка вышла, будто её вырезали ножом. — Да, обычно именно так и выходит, когда некомпетентные идиоты суют носы в дела за пределами их понимания.\",\"— Это она нам, — шёпотом сказал Раф.\",\"— Хочешь исправить свою ошибку и восстановить жезл? Я могу помочь тебе, но… От тебя потребуется кое-что взамен.\",\"Кристалл сдерживания, который носит Чародей Тиш'алан. Элемент питания. Пять горстей магической пыли. И убить Десницу Чародея.\",\"— Голем, — пояснила она с удовольствием. — Большой. Его строил мой учитель, Первый Чародей, чтобы никто не трогал его вещи. Я тоже не могла. Тысячу лет смотрела на свой жезл и не могла.\",\"— Не верю ей, — сказал Асценси. Коротко, глядя туда, где она висела в воздухе.\",\"А мне было её жалко. Вот в чём беда.\",\"Тиш'алан отдал кристалл только мёртвым. Пыль я собирала по крупице. Десница Чародея ждала в нижнем зале: каменная, с руками, как ворота, и с пустым гнездом для кристалла в груди. Когда мы вошли, в гнезде вспыхнуло, и голос, не её, скрипучий, как старая дверь, сказал: «Вещи Первого Чародея не покидают зал». Он повторял это, пока бил. Один и тот же приказ, тысячу лет, на одной ноте. Раф упирался, сапоги скользили по камню. Я лечила и считала вдохи. Когда голем рухнул, фраза оборвалась на середине, и от этого стало хуже, чем от удара.\",\"Деллиана приняла всё, и лицо её засветилось.\",\"— Да, да! Тысячелетия ожидания наконец завершены! — Она смотрела не на меня. На Асценси. — И всё благодаря тебе, Асценси. Пришла пора отблагодарить тебя как следует!\",\"И исчезла. Не отблагодарив. Утащила кристалл, силу и свою тысячелетнюю мечту.\",\"Асценси смотрел на пустое место. Потом отвинтил флягу.\",\"— Говорил же. — И выпил.\",\"— Она назвала его по имени, — сказала я. — Откуда она знала его имя?\",\"Никто не ответил. Асценси тоже.\",\"Тринадцатый уровень пришёл прямо среди обломков, тёплой волной от затылка до пальцев. Ночью я долго думала, куда направить этот новый Свет, и выбрала светлую магию, чтобы Кара иногда била вдвое злее. Сначала почувствуй, потом решай, так меня учили.\",\"— Почему тринадцатый? — спросил Раф, когда я сказала. — Откуда ты знаешь, что не двенадцать с половиной?\",\"— Знаю. Как знаю, что рука моя.\",\"— Мой отец говорил, что Странники меряют себя ступенями, а мы — годами. — Он пожал плечами. — Я так и не понял, кто прав.\",\"Я тоже.\",\"— Асценси, — спросила я. — Ты бы ей поверил ещё раз?\",\"Он долго молчал. Потом закрутил флягу и лёг спать, так и не ответив.\"],\"plates\":[{\"after\":25,\"alt\":\"Когда первый фолиант упал и затих, я коснулась его руной, и он исчез. Мне вдруг стало его \",\"src\":\"/chronicle/tome/102.jpg\"},{\"after\":27,\"alt\":\"Леанин Рождённая Звёздами просила о тихом: фляга священного масла, связка благовоний, сунд\",\"src\":\"/chronicle/tome/103.jpg\"},{\"after\":31,\"alt\":\"Хозяйка проступила из воздуха, как пятно на ткани. Призрачная эльфийка с лицом, на котором\",\"src\":\"/chronicle/tome/104.jpg\"},{\"after\":44,\"alt\":\"— Говорил же. — И выпил.\",\"src\":\"/chronicle/tome/105.jpg\"}]},{\"id\":\"g3-16\",\"numeral\":\"16\",\"title\":\"Часть 16\",\"kicker\":\"Глава 3\",\"dek\":\"Утром я разносила долги, и каждый долг, оказывается, что-то менял.\",\"paragraphs\":[\"Утром я разносила долги, и каждый долг, оказывается, что-то менял.\",\"Леанин провела ладонью по крышке сундука с саванами, и пальцы у неё дрогнули. «Вот наглядное свидетельство того, что методы консервации Высокорождённых не имеют себе равных», — сказала она учёным голосом, а потом уже своим: «Духи будут рады. Наконец-то». К полудню у края руин горели благовония, и призраки на ближних улицах, говорят, впервые за века не вышли навстречу. Мне она отдала Проклятое око из Нораласа, для левой руки, тёмный шар с фиолетовым отливом. «Оно смотрит в прошлое, а не на тебя». Через минуту око согрелось от моей ладони.\",\"Майт'ал над фолиантами смеялся, как ребёнок на ярмарке, и выдал мне свиток интеллекта. А за «Собрать по крупинкам», хотя Деллиана и сбежала, он отдал хрустальный медальон солнца. «Всё, что осталось после коварной эльфийки, — магические компоненты её жезла».\",\"Асценси при имени Деллианы отвернулся и отпил из фляги. Заноза ещё сидела.\",\"* * *\",\"В полдень, на привале у руин, Раф снял щит и перевернул его. На внутренней стороне, под ремнём, куда никто никогда не смотрит, был вделан маленький камень — зелёный, гладкий, огранённый неумелой рукой.\",\"— Тот самый? — спросила я. — С берега, где Шшеракс?\",\"— Нет. Тот я так и не дорезал, — сказал Раф. — Этот — первый. Я его гранил, когда мне было двенадцать, для Мирель. Криво, видишь? Отец сказал, что это худшая огранка в истории Кель'Таласа. Мирель сказала, что это самый красивый камень на свете. Они оба были правы.\",\"— Когда я принимал клятву, старый паладин спросил, что я буду защищать. Все говорили красиво: королевство, Свет, народ. А я сказал: тех, кто рядом. Он посмотрел на меня, как на дурака, и всё равно принял. — Раф пожал плечами и снова надел щит. — Поэтому я всегда стою впереди. Не из храбрости. Просто я один раз уже был сзади. Мне не понравилось.\",\"Я вспомнила пещеру Сапфировой Пасти и его «я успею». Теперь я знала, почему он так уверенно это говорит. Он не уверен. Он просто однажды не успел.\",\"— Ладно, — сказал Раф, потянувшись. — Там справа, кажется, оловянная жила. Я на две минуты.\",\"Он ушёл на сорок. Вернулся с полными карманами и счастливым лицом. Иногда я думаю, что Свет держит его не молитвами, а рудой.\",\"* * *\",\"— Должное уважение, — сказал Рельтир Звездочёт.\",\"Он был очень старый, с прозрачными, как вода в горном ручье, глазами, и говорил медленно, будто каждое слово доставал со дна. Восемь мемориалов по городу и монумент в храме Закатного Солнца. Обряд у каждого.\",\"Потом он посмотрел на мои уши. Не мельком, как все, а долго.\",\"— У кель'дорай не бывает кисточек, — сказал он. — Ни у кого из тех, кого я знал. А я знал многих.\",\"— Я не знаю, откуда они, — честно сказала я. — Проснулась с ними.\",\"— Вот как, — сказал Рельтир. И больше ничего не спросил, но я видела, что он запомнил.\",\"Мемориалы стояли под рыжими деревьями, белые, на постаментах. Я клала ладонь на камень и пыталась прочитать надпись. Буквы превратились в мягкие впадины, и пальцы проваливались в них, как в чужие следы на снегу. Ни одного имени.\",\"У третьего мемориала я села на ступеньку и не могла встать.\",\"— Люси? — Раф присел рядом. Щит лязгнул о камень.\",\"— Тут никого нет, — сказала я. — Понимаешь? Даже имени. Жил кто-то. Любил кого-то. Пёк хлеб. А теперь ямка в камне.\",\"— Ну, — сказал Раф. Подумал. — Зато ты к нему пришла.\",\"— Он не знает.\",\"— Ты знаешь. Этого достаточно.\",\"— Если я умру, — сказала я, — напиши на камне моё имя. Глубоко. Чтобы ветер не стёр.\",\"— Ты не умрёшь.\",\"— Раф.\",\"— Ладно. Глубоко. Топором выбью, если надо. — Он помолчал. — Но ты не умрёшь. У меня на тебя планы. Ты мне ещё должна рыбу.\",\"— Какую рыбу?\",\"— Узнаешь.\",\"Храмовый зал стоял в глубине руин. Высокий, белый, с колоннами, уходящими вверх, где свет падал столбом прямо на статую. Монумент. Женщина из камня, с опущенным лицом. У её ног горели две жаровни, и пламя в них было бледно-голубым, как будто огонь тоже скорбел.\",\"Восемь камней без имён. Один монумент. Мне кажется, она слышала.\",\"* * *\",\"Для Майт'ала, «Всматриваясь в пламя», нужны были десять осколков солариевого кристалла. Порождения Света бродили по рыжим лугам, сияющие, с шаровыми сердцами, и были бы красивы, если бы не пытались нас убить. Из каждого павшего Раф выковыривал осколок, тёплый и янтарный, как чистят рыбу.\",\"Я держала десятый на ладони и думала, что выковыриваю сердца из того, что светится. Пусть оно и пыталось нас убить. Майт'ал заплатил за них Оплечьем горя. Оно легло на плечи тяжело, как чужая рука, которая хочет утешить. Название я сочла честным.\",\"* * *\",\"Вечером Раф подошёл ко мне с мешком.\",\"— Вот, — сказал он. — Я говорил: рыба.\",\"В мешке лежала сырая блестящая рыбка. Много. Холодная, скользкая, с серебряными боками. Раф наловил её где-то у воды, пока я ходила по мемориалам.\",\"— Это ты зачем?\",\"— Обмен. Ты готовишь, я ловлю, Асценси шьёт. Мы — экономика.\",\"— Мы — что?\",\"— Отец так говорил. Торговое слово, из гильдии огранщиков. — Раф смутился. — Значит, когда все нужны друг другу.\",\"Асценси хмыкнул. Слово ему, кажется, понравилось больше, чем рыба. Я засмеялась и взяла мешок. Рыба пахла рекой. Рекой, которая течёт где-то там, где не бывает пауков, где не бывает мемориалов без имён. Я подумала, что когда-нибудь пожарю её всю, сразу, и мы будем есть у огня, и будет тепло.\",\"* * *\",\"Рельтир ждал меня у монумента. Он стоял, опираясь на посох, и смотрел на статую.\",\"— Я наблюдал за тобой, — сказал он, не оборачиваясь. — И ты была добра к этим камням.\",\"— В шуме ветра я слышу плач детей Нораласа, — сказал Рельтир. Тихо. — Закончится ли он когда-нибудь?\",\"Я не ответила. Я не знала ответа. Я стояла и слушала ветер, и мне тоже вдруг показалось, что я слышу. Тонкий, далёкий, бесконечный плач. Детский. Не громкий. Просто такой, который не прекращается, потому что никто не пришёл утешить.\",\"У меня перехватило горло. Я не знаю, была ли я когда-нибудь маленькой. Не помню. Но плакать так, тихо, чтобы никто не слышал, я откуда-то умею.\",\"— Им нужно, чтобы кто-то пришёл, — сказала я наконец.\",\"— Да, — сказал он. — Именно это им и нужно.\",\"Он отдал мне поручи. Эластичные, тканые, мягкие. Я застегнула их на запястьях и почувствовала, как они обнимают руки. Как будто кто-то держит меня за запястья и говорит: «Ты здесь. Ты не одна».\",\"{{Я слышала. Честно. Не хочу больше слышать. Хочу, чтобы они перестали.}}\",\"* * *\",\"— Ты почтила память жителей, — сказал Рельтир на следующее утро. — Увы, мы не заслужили подобной милости. Тяжесть наших грехов слишком велика. — Он отвёл глаза. — Но ты должна знать историю. Четыре записи Первого Чародея, в залах храма.\",\"Почерк был ровный и уверенный. Почерк человека, который всегда знал, как лучше.\",\"Первая запись. Великий лорд Дат'Ремар, ведя народ из-под тени Тирисфаля. Норалас достаточно далеко от прежних мест. Норалас — новый дом. Он писал это с надеждой. С такой надеждой пишут письма в будущее, которое обязательно будет лучше.\",\"Вторая. Кристаллизация. Древние создания, превращённые в кристаллы. Неисчерпаемый источник силы. Он писал «неисчерпаемый» и, кажется, улыбался.\",\"Третья. Митра. Синие драконы. Кто-то, кто пришёл и предупредил. И кого, кажется, не послушали.\",\"Четвёртая. Солариевые кристаллы. «Игрушка жрецов Белор'алара», писал он. Свысока. С тем же ровным почерком.\",\"Асценси молча протянул мне флягу. Я не взяла, но поняла вопрос.\",\"— Человек, который был очень умный, — сказала я. — И очень уверенный. И который погубил всех.\",\"— Я так говорю каждый день, — сказал Раф. — «Я знаю, что делаю». — Он поднял щит. — Но я хоть стою впереди. Если ошибусь, первым и получу.\",\"Рельтир выслушал меня, не поднимая глаз, и протянул лазурный пояс старейшины. Руки у него дрожали. Тогда я решила, что от старости.\",\"{{Фрагменты. Четыре записи. Почерк красивый. Человек — нет. Записываю, чтобы не забыть: уверенность — не то же самое, что правота.}}\",\"Я закрыла журнал. Снаружи опять поднимался ветер, и я не стала прислушиваться.\"],\"plates\":[{\"after\":19,\"alt\":\"Мемориалы стояли под рыжими деревьями, белые, на постаментах. Я клала ладонь на камень и п\",\"src\":\"/chronicle/tome/106.jpg\"},{\"after\":32,\"alt\":\"Храмовый зал стоял в глубине руин. Высокий, белый, с колоннами, уходящими вверх, где свет \",\"src\":\"/chronicle/tome/107.jpg\"},{\"after\":45,\"alt\":\"Асценси хмыкнул. Слово ему, кажется, понравилось больше, чем рыба. Я засмеялась и взяла ме\",\"src\":\"/chronicle/tome/108.jpg\"}]},{\"id\":\"g3-17\",\"numeral\":\"17\",\"title\":\"Часть 17\",\"kicker\":\"Глава 3\",\"dek\":\"Вниз.\",\"paragraphs\":[\"Вниз.\",\"— Отголоски бедствий, — сказал Рельтир, и мне не понравилось, что он избегает моего взгляда. — В поисках великой силы Первый Чародей овладел тайнами, позволявшими извлекать магическую энергию живых существ, обращая их в кристаллы. Помочь им уже нельзя. Но можно избавить от страданий. Собери семь кристаллизованных останков.\",\"Мы спускались долго. Раф впереди, щит над головой, чтобы на него, а не на нас, сыпалась пыль с потолка. Асценси сзади, лук наготове. Я посередине, считая ступени, потому что когда считаешь, не думаешь.\",\"— Ты кричал «БЕГИ», — напомнила я Рафу на сорок второй ступеньке. Мы спорили о гиганте у Гавани.\",\"— Стратегически кричал.\",\"Асценси сзади звякнул крышкой фляги. Это у него вместо смеха. А я подумала: как хорошо, что мы можем вот так. Внизу, в темноте. Болтать о ерунде. Потому что если замолчать, тишина подступает к горлу.\",\"Останки лежали в нишах. Кристаллы, в которых проступали очертания. Руки. Плечо. Лицо. Я собирала их, и каждый раз, когда касалась, внутри что-то сжималось. Это были люди. Когда-то. Пока кто-то очень умный не решил, что они — источник.\",\"У одного из тел, у кристаллизованного воителя, мы нашли брюки. Кожаные, лазутчика, с вышитым орлом.\",\"— Не моё, — сказала я, повертев. — Я в коже не хожу.\",\"— Распыли, — сказал Раф. — Лучшее слово в языке. Вещь была — и нет её. Только пыль. И из пыли что-то новое.\",\"— Как мы, — добавил он.\",\"— Не начинай, — сказала я.\",\"— Я серьёзно. Мы тоже из пыли. И в пыль. А посередине — немного рыбы.\",\"Я засмеялась, и смех гулко отразился от стен катакомб, и мне сразу стало стыдно, что я смеюсь здесь. Потом стало не стыдно. Мёртвым, наверное, тоже приятно, когда кто-то рядом смеётся. Хоть кто-то.\",\"Рельтир дал мне плащ. Плащ энергии. Лёгкий, мерцающий, будто в ткань вплели кусочек того света, который мы только что освободили.\",\"* * *\",\"— Падение Нораласа, — сказал Рельтир. И впервые за всё время посмотрел мне прямо в глаза.\",\"Он рассказал, как Элдрагоса, синяя драконица, пришла в город в смертном облике — тихой эльфийкой, которую никто не замечал. Она видела, что творится, и пыталась остановить. Не успела: ритуал, взрыв, и город, разорванный изнутри.\",\"— Сила, заключённая в собранных тобой кристаллах, имеет ту же природу, что и магия детей Малигоса, — сказал он. — Только с её помощью можно снять заклинание, которым Элдрагоса запечатала храм, покидая разрушенный город.\",\"Он дал мне кристаллизованный симулякр, маленький и гудящий: поднести к барьеру, и он откроет брешь. Небольшую. Ненадолго.\",\"Барьер стоял в конце коридора, синий, мерцающий, как вода, вставшая стеной. Я подняла симулякр и почувствовала, как он тянет из меня что-то. Не ману. Что-то глубже. Брешь открылась с тихим звоном.\",\"— Осторожнее, Высшая эльфийка, — сказал Рельтир, когда я вернулась. — Сюда много веков не ступала нога смертных.\",\"Рельтир отдал мне перчатки. Чародейские. Тонкие, как вторая кожа. Я надела их и подумала: вот, теперь у меня руки, как у того, кто всё это начал. Чародея. Надо не забыть, что руки — это не голова. Руки делают, что велят.\",\"* * *\",\"За барьером начинались залы фал'дорай.\",\"— Это что-то вроде нас? — спросил Раф шёпотом.\",\"— Это то, во что можно превратиться, — сказала я, — если очень долго сидеть в темноте и очень сильно бояться.\",\"Нечестивое избавление. Рельтир объяснил: тысячи лет эти изувеченные создания обживали священные залы Нораласа. Проклятые выжившие. Те, кто не умер, когда всё рухнуло. Кто остался. Кто превратился. Нужно было убить восемь стражей выводка и прядильщиц.\",\"И разорить гнездо. Двадцать яиц.\",\"«Ожидая часа освобождения, чтобы обрушиться на Нордерон подобно чуме», — читала я вслух его слова из журнала, пока мы спускались. И думала: они ведь тоже были эльфами. Нашими. Тролли в Диколесье, фал'дорай под Нораласом, мы. Где кончаются «они» и начинаемся «мы», если всё решает, кто дольше сидел в темноте?\",\"* * *\",\"Рельтир нашёл нас в нижнем зале. Он шёл медленно, тяжело опираясь на посох, но шёл.\",\"— Теперь ты знаешь, что стало с Нораласом и его гордым народом, — сказал он. — Что же ты выберешь, Люси? Сбежишь, чтобы однажды умереть в своей постели… или последуешь за мной во тьму?\",\"Он не знал, что это значит для меня. Что у меня одна жизнь, и если я сейчас уйду наверх, к рыжим деревьям, к лагерю, к рыбе, которую мне дал Раф, то, может быть, и правда умру в своей постели. Старой. Через много лет.\",\"— Если осмелишься идти дальше, — добавил Рельтир, — не забудь своих друзей. Тебе понадобится любая доступная помощь.\",\"Я обернулась. Раф стоял со щитом. Асценси — с луком. Медведь — с мордой, полной паутины.\",\"Асценси молча закрутил флягу и взял лук. Ответ.\",\"Я выдохнула. И пошла вниз.\",\"* * *\",\"Яйца лежали в нижних залах. Кладками, гроздьями, белыми и влажными, облепленными паутиной. Они были тёплые. Я положила руку на одно и почувствовала, как внутри кто-то шевелится.\",\"Меня затошнило. Асценси молча отвёл мою руку от кладки и кивнул на Рафа: работай.\",\"Раф крушил кладки щитом, Асценси бил стрелами в самые крупные, а я держала их обоих живыми и изредка добавляла Кару туда, где яйцо шевелилось сильнее других. Яйцо лопалось, и из него выплёскивалась зелёная слизь, и иногда — иногда — оттуда выползал паучок. Тёмный, новорождённый, злой.\",\"А потом пришли стражи. Большие. Прядильщица спустилась с потолка на нити, прямо надо мной, и я увидела её брюхо в паре ладоней от лица.\",\"— Раф!\",\"Он был уже там. Щит вверх, удар, она отлетела. Но паучки не отлетели. Они облепили его. Облепили меня. Я лечила, и лечила, и лечила, и чувствовала, как сила утекает.\",\"Я посмотрела на Асценси. Он стоял у стены, выпускал стрелы одну за другой, и лицо у него было белое. Мана у него почти кончилась. Я видела это по тому, как дрожали у него руки.\",\"Мне было больно. Везде. Яд в крови, укусы на руках, на шее, жжение под рёбрами. Я пыталась вдохнуть и не могла. Пол качнулся. Свет в глазах стал серым, и я села на камень, потому что ноги кончились.\",\"Что-то тяжёлое и тёплое накрыло меня сверху. Медведь. Он встал надо мной, расставив лапы, как крыша, и паучки, которые лезли мне к горлу, полезли к нему. Никто ему не командовал: Асценси был у стены, без стрел. Медведь просто решил сам. Я слышала, как он рычит от боли и не уходит.\",\"Вот так, подумала я сквозь серое. Вот так это и бывает. Не красиво. Не героически. Просто паучки. Мелкие паучки в тёмном подвале. И никто не узнает. И Раф не успеет выбить моё имя мечом.\",\"— ЛЮСИ!\",\"Я не помню, что сделала. Помню только, что Свет вдруг стал горячим. Очень горячим. Он вспыхнул во мне, как будто кто-то распахнул окно, и я увидела всё ясно: где Раф, где Асценси, где медведь, где каждый паучок. И я лечила. Щит на Рафа, свет на Асценси, щит на себя, и снова Раф. Одна Кара туда, где паучков было гуще всего, — не золотая, а белая, рваная, и ладони после неё жгло, как от крапивы. Одно Слово Тьмы: Боль на прядильщицу, холодное и вязкое, будто я выдохнула его из собственных лёгких. И снова лечила.\",\"И среди яиц, среди слизи и паутины, мне стало легко.\",\"Четырнадцатый.\",\"Он пришёл, как глоток воды в пустыне. Тело стало крепче. Раны затянулись чуть быстрее. Свет — чуть ярче. Ещё одна капля в светлую магию, пятая из пяти. Я довела её до конца прямо там, в мыслях, пока Асценси стрелой прибивал к полу последнего паучка.\",\"Асценси подошёл, держась за бок, упал рядом на колени и взял меня за плечи. Больно. Пальцы у него были ледяные.\",\"— Не смей, — сказал он. Голос сорвался, как будто им давно не пользовались. — Слышишь? Не смей уходить первой. У меня был брат. Громкий. Всегда лез первым, всегда смеялся. Я каждый раз думал: успею. Стоял сзади, с этой флягой, и думал: успею. — Он сунул флягу мне в руки, не отпуская. — Я не знаю, где он теперь. Знаю, что не успел. Я больше не буду стоять сзади. Я не могу ещё раз.\",\"Он замолчал так же резко, как начал. Отвернулся. Плечи у него ходили.\",\"— Я, кажется, умерла, — сказала я, потому что не знала, что ещё сказать.\",\"— Нет. — Он уже взял себя в руки, почти. — Мёртвые не дрожат.\",\"Медведь, весь в укусах, привалился к нему боком. Асценси положил ладонь ему на загривок и не убирал.\",\"Раф сел на пол, прямо в слизь, положил щит рядом и долго сидел так, прежде чем поднять голову.\",\"— Я думал, всё, — сказал он тихо. — Честно. Я думал, ты всё.\",\"— Я тоже, — сказала я.\",\"— Бывает, — сказал он. И поднялся. И протянул мне руку.\",\"Я взяла его руку. Она была тёплая и тяжёлая. Настоящая.\",\"Медведь ткнулся мне мокрым носом в бедро, и я села прямо на камень и разревелась. Не от боли. От того, что живая.\",\"Журнал я открыла только ночью, и руки всё ещё не слушались:\",\"{{Живая. Раф думал, что всё. Я тоже. Мы ошиблись. Хорошо, что мы ошиблись.}}\",\"А ниже, мелко, когда смогла: {{яйца — двадцать, стражи — восемь. Четырнадцатый.}}\",\"* * *\",\"Рельтир смотрел на нас, как смотрят на огонь, который давно не видели.\",\"— Когда ты очнулась, ты сказала «четырнадцатый», — сказал он. — В моё время так говорили о кругах посвящения. Кто тебя посвящал, дитя?\",\"— Никто. Я просто знаю.\",\"— Все Странники «просто знают», — тихо сказал он. — Я тысячу лет не могу понять, кто им говорит.\",\"Он дал мне королевские штаны, тканые, с вышивкой по краю, и надёжные сапоги. Я сидела на ступеньке и переобувалась, а руки всё ещё дрожали, и я никак не могла попасть в петлю.\",\"— Дай, — сказал Раф. И завязал мне шнурки. Сам. Большими неловкими пальцами.\",\"— Ты как мама, — сказала я.\",\"— Не говори так, — сказал он. — Я разревусь.\",\"— Ты не разревёшься.\",\"— Не разревусь, — согласился он. — Но могу.\",\"Пока ещё есть куда.\"],\"plates\":[{\"after\":41,\"alt\":\"Раф крушил кладки щитом, Асценси бил стрелами в самые крупные, а я держала их обоих живыми\",\"src\":\"/chronicle/tome/109.jpg\"}]},{\"id\":\"g3-18\",\"numeral\":\"18\",\"title\":\"Часть 18\",\"kicker\":\"Глава 3\",\"dek\":\"Внизу, на дне катакомб, был лагерь.\",\"paragraphs\":[\"Внизу, на дне катакомб, был лагерь.\",\"Я не поверила, когда увидела. Костёр. Настоящий, живой, с треском. Вокруг него Майт'ал, Кин, Леанин. Они спустились за нами, пока мы дрались с пауками. Сидели в темноте, на камнях, будто так и надо, будто это не дно мёртвого города, а поляна у озера.\",\"— Вперёд и вниз, — сказал Майт'ал, когда я подошла, и улыбнулся. — Подумать только, всё это время такое зло было буквально у нас под ногами. Что ещё таит эта земля?\",\"Работы было много, и раздали её тут же, у огня, не вставая. Кину — пять древних големов: «Непокорённые храмовые часовые исправно несут свою службу даже по прошествии тысяч лет. Только вот служат они теперь иным господам». Леанин вложила мне в ладонь благословлённую реликвию, маленькую и тёплую, и восемь исчадий тьмы в придачу: «Тьма многолика. И знает, где мы слабее». Майт'алу — десять тёмных кристаллов на бронзовых шпилях, «угасших светил», в которых раньше было солнце, а теперь клокочет тьма.\",\"Я слушала и смотрела не на них, а на Рафа. Он сидел, положив щит на колени, и большим пальцем гладил камень Мирель. Медленно, по кругу, как гладят того, кто спит.\",\"— Мы только что оттуда, — сказала я тихо. — Из яиц.\",\"— Знаю.\",\"— Можно сказать «завтра».\",\"— Можно, — согласился Раф. — А исчадия до завтра подождут? — Он поднял на меня глаза. — Я не геройствую, Люси. Я просто не хочу, чтобы Леанин потом пошла туда одна со своей реликвией.\",\"Асценси молча проверил тетиву. Это был его голос.\",\"Мы встали. Где-то рядом капала вода.\",\"* * *\",\"Големы были огромные и медленные, и честные: просто били. Кристаллы стояли в нишах, тёмные, с фиолетовым дымом внутри, и когда я разбивала их, на секунду становилось светлее, будто кто-то выдыхал.\",\"Исчадия были другими. Они не рычали. Они говорили. Тихо, голосами, которых я не знала, но которые почему-то узнавала: «Ты тоже уйдёшь. Все уходят наверх, а мы остаёмся». Одно прошептало Рафу что-то, от чего он побелел и ударил щитом так, что треснул камень. Что именно, он мне не сказал. Леанин была права: тьма знает, где мы слабее.\",\"У костра Раф вывалил на камень ворох из своей сумки: «Не всё ж распылять». Асценси вытянул пару кожаных перчаток, кивнул и убрал. Сделка закрыта. Награды раздали там же: Леанин — оплечье старейшины, легче Оплечья горя, и с плеч будто сползла тень; Майт'ал — чародейский убор; Кин — облачение волшебника. Я переоделась за камнем в чёрную робу с золотом. Асценси оглядел меня и молча поднял флягу.\",\"Леанин сидела у огня и смотрела в пламя.\",\"— Что же тогда скрывается под Тирисфалем? — сказала она вдруг. Ни к кому. Просто в воздух.\",\"* * *\",\"— Искупление Нораласа, — сказал Рельтир.\",\"Королева фал'дорай, Фалрисса, ждала за барьером. Барьер держал силовой пилон, огромный, гудящий, весь в синих разрядах. Вокруг лежали кладки яиц.\",\"— Не опять, — сказал Раф, увидев моё лицо. — Последний раз.\",\"Мы разрушили пилон. Он лопнул, будто порвалась струна размером с дерево, барьер ослаб, и я увидела её.\",\"Фалрисса. Шестнадцатого уровня. Высокая, многоногая, с телом эльфийки там, где у пауков должна быть голова. Лицо у неё было почти красивое. Почти. Она не бросилась на нас. Она смотрела мимо меня, на Рельтира, и паучьи лапы медленно переступали по кладкам, будто укрывали их.\",\"— Ты, — сказала она. Голос был человеческий, усталый, с нораласским выговором, как в тех записях. — Ты погубил нас… Я пела в твоём храме, чародей. Я держала на руках детей, когда твой свет разорвал город. Мы ушли вниз, потому что наверху было некуда. А внизу была только твоя тьма. И она нас переделала.\",\"Посох Рельтира дрожал. Он ничего не ответил.\",\"— Эти, — она коснулась лапой яиц, — последние дети Нораласа. Других у меня нет. Уходите. Или останьтесь с нами навсегда.\",\"Я поняла, что не хочу её убивать. И поняла, что сейчас убью. Если она выйдет наверх, вместе с выводком, на рыжие луга, к лагерю, к Кину и Леанин, детей там не останется ни у кого.\",\"— Прости, — сказала я. Не знаю, кому.\",\"Бой был тяжёлым. Я помню, как Раф держал её и как скрипели его сапоги на камне. Помню, как утекала мана. Щит на Рафа, лечить, щит, лечить. Кару я бросила дважды, и после второй в глазах поплыло, а руки налились такой тяжестью, будто я держала не Свет, а мокрое бельё. Дышать. Палица Амани висела у меня на поясе и пугала Фалриссу исключительно своим видом. Не испугала. Медведь держался у кладок, и ни один паучок не прошёл мимо него к Асценси.\",\"Она упала. Тяжело, с хрустом. До последнего лапы тянулись к яйцам.\",\"Раф наклонился над ней. Отрезал голову. Так было нужно, так просили. Поднял её, посмотрел ей в лицо.\",\"— Может, ещё руку ей пожать? — сказал он хрипло. — Всё-таки королева. Этикет.\",\"— Раф.\",\"— Что? Я нервничаю. Когда я нервничаю, я шучу.\",\"— Ты всегда шутишь.\",\"— Значит, я всегда нервничаю. — Он завернул голову в тряпку. — Пошли отсюда.\",\"Я шла за ним и смотрела на свёрток. Когда-то она пела в храме. Теперь она — доказательство для Совета. Я третий раз за эту осень иду куда-то с чужой головой, и, кажется, я уже научилась не смотреть. Вот этому я учиться не хотела.\",\"* * *\",\"Рельтир принял голову. Долго смотрел на свёрток. Потом поднял на меня глаза.\",\"— Да, Люси, некогда я был первым чародеем Нораласа, — сказал он.\",\"— Всё зло, что обрушилось на эти земли, — сказал он, — целиком и полностью моя вина. Я благодарю тебя за то, что ты дала мне шанс на искупление. Ты — истинный друг Нораласа.\",\"Старик с прозрачными глазами, который слышал плач детей в шуме ветра. Ровный уверенный почерк: «неисчерпаемый источник», «игрушка жрецов». «Ты погубил нас». Это был он. Всё это время.\",\"Я хотела злиться. Правда хотела. Он погубил город, детей, тех, чьих имён не осталось даже на камнях. Но я посмотрела на его руки, на то, как они держали посох, и поняла: он уже наказан. Века. Века он ходил по этим руинам и слушал плач. Это хуже, чем смерть. Это одна жизнь, растянутая на тысячу лет. Без права закончиться.\",\"Он разложил передо мной оружие: Клеймор Нораласа, Короткий меч детей Солнца, Радужный скипетр. Я взяла скипетр, лёгкий, с камнем, который раскладывал свет на радугу. Палицу Амани убрала в сумку. Палица за голову вождя, скипетр за голову королевы. Если так пойдёт дальше, мне придётся завести отдельную сумку для благодарностей за головы. Шутка вышла плохая. Я её оставила себе.\",\"* * *\",\"— Послание в Эльдранил, — сказал Майт'ал. — Высокий Совет должен узнать о том, что здесь произошло. Мы срубили зверю голову, но кто знает, сколько этих многоногих чудовищ ещё скрывается там, во тьме?\",\"— Мы останемся, — сказал он. — С Леанин и Кином. Проведём обряды. Катакомбы должны быть полностью зачищены и благословлены Светом. А ты — иди. Да хранит тебя Свет.\",\"— Последняя просьба, Люси, — сказал Рельтир, подойдя последним. — Много веков я храню коготь, который Элдрагоса потеряла в битве под сводами храма. Этот коготь позволил мне сохранить рассудок и не поддаться гневу и боли. Служил вечным напоминанием о моих прегрешениях.\",\"Он протянул мне коготь. Длинный, синий, тяжёлый. Холодный, как лёд в горном озере.\",\"— В горах Нордерона, у истоков реки Тондрорил, есть небольшое плато. Там, в пещере, логово Элдрагосы. Отнеси его туда. Мне он больше не нужен.\",\"— Этот край теперь ваш, дети Солнца, — сказал он. — Не повторяйте ошибок прошлого.\",\"* * *\",\"Дальше в катакомбах ждало Исчадие тьмы. Последнее. Оно вышло из угла и заговорило с Асценси голосом, громким и весёлым, которого я никогда не слышала, но сразу поняла, чей он. «Опять сзади, братишка?» Асценси стрелял, бледнея, пальцы скользили по тетиве, и стрелял, пока не кончились силы. Раф держал. Я лечила.\",\"Оно упало.\",\"Я бросилась к Асценси раньше, чем поняла, что бегу. Он сидел на полу, белый, и тяжело дышал, и пальцы у него всё ещё искали тетиву.\",\"— Ты как?\",\"— Пусто, — сказал он.\",\"Я положила ладони ему на плечи и держала, пока он не перестал дрожать. Только потом заметила, что во мне самой что-то сдвинулось.\",\"Я почувствовала его иначе. Не только силой. Голова стала яснее, на одну каплю, и Свет внутри — ровнее, на одну каплю. Ум и дух. Как будто кто-то бережно поправил мне выбившуюся прядь. Пятнадцатый.\",\"— Отдохни, — сказала я. — А мне теперь можно не отдыхать.\",\"Он просто посмотрел на меня.\",\"— Вру, — призналась я.\",\"* * *\",\"Горы Нордерона. Река Тондрорил, тонкая и холодная, бежала по камням, и вода в ней была такой прозрачной, что видно было каждый камушек на дне. Плато. Пещера.\",\"В пещере пахло костями. Кости и лежали — повсюду, белые, огромные. Скелет кого-то такого большого, что рёбра торчали из земли, как колонны разрушенного храма.\",\"А посреди костей, в зелёном свете, ждал дракон.\",\"Огромный, синий, из рода Малигоса — Баццит, двадцатого уровня, на пять выше меня. Я не умею считать такие разницы. Тело посчитало само: ноги стали ватными.\",\"— Как ты посмела явиться к порогу моей госпожи, смертное существо? — Голос был как гул под землёй. Как камнепад. Стены дрожали. — И как ты прошла через барьер?\",\"Раф шагнул вперёд. Щит вверх. Я видела, как напряглась его спина. Он знал, что если дракон захочет, щит не поможет. Он всё равно шагнул.\",\"Медведь стоял рядом с Асценси, и шерсть у него на загривке поднялась.\",\"Баццит смотрел на меня. В его глазах не было злобы. Только древность.\",\"— То, что случилось в городе эльфов, тяжким грузом легло на душу госпожи, — сказал он. — Она отошла от дел смертных на тысячи лет, и лишь великая нужда вынудила её вновь откликнуться на их зов. Улетая, она наказала мне оберегать эту обитель, и вот уже двадцать веков я исправно несу свою службу.\",\"Я достала коготь.\",\"— Я… — сказал Баццит, и голос у него вдруг стал другим. Тише. — Я узнаю этот коготь. Где ты взяла его?\",\"Я рассказала про Рельтира и Норалас, про ритуал и взрыв. Про то, что коготь хранил рассудок того, кто всё это начал. Голос у меня дрожал, и я ничего не могла с этим сделать.\",\"Он слушал. Долго. Потом опустил голову к самому полу, так близко, что я почувствовала холод его дыхания.\",\"— Тот, кто начал это, — сказал он. — Он жив?\",\"Вот тут я и поняла, что пришла не только отдать коготь. Одно слово, и двадцать веков ожидания найдут себе цель. Рельтир внизу, у лагеря, с посохом, который дрожит. Я могла соврать. Дракон бы не узнал.\",\"— Жив, — сказала я. — Он тысячу лет слушает, как плачут дети, которых он убил. Он сам отдал мне коготь. Сказал, что тот держал его в рассудке. Если вы полетите к нему, вы оборвёте наказание, а не продлите его.\",\"— Не тебе судить, смертная.\",\"— Не мне, — согласилась я. Голос дрожал. — Но вы спросили.\",\"— Госпожа тоже не полетела, — сказал он наконец, очень тихо. — Тогда я её не понимал.\",\"Он отдал мне сумку. Синюю, из драконьей кожи, лёгкую и прочную. Сумку синих драконов. Я так и не узнала, правильно ли сделала. Иногда ночью думаю об этом до сих пор.\",\"— А теперь ступай, смертное существо, — сказал он, — и никогда больше не возвращайся!\",\"Голос ударил в грудь, как волна. Я отступила на шаг. Ноги не слушались. Через всю пещеру, через кости, спиной к нему, я бы не дошла.\",\"— Камень, — сказал Раф сквозь зубы, не отрывая глаз от дракона. — Сейчас. Мы выйдем сами.\",\"— Я вас не брошу.\",\"— Он смотрит на тебя, не на нас. Уйдёшь ты — он ляжет. Люси. Пожалуйста.\",\"Асценси ничего не сказал. Он просто кивнул мне и сделал шаг назад, к выходу, медленно, не поворачиваясь, и медведь шагнул вместе с ним.\",\"Я достала камень возвращения. Прямо у его лап. Сжала в кулаке и посмотрела на Рафа. Он подмигнул мне. Губы у него были белые.\",\"Камень потеплел. Мир вокруг поплыл.\",\"Последнее, что я увидела, — синий глаз дракона и две спины, медленно пятящиеся к свету. Мне показалось, в глазу было что-то вроде усмешки. Я надеялась, что это значит «иди», а не «жди».\",\"* * *\",\"Эльдранил встретил меня золотом, как в первый раз.\",\"Раф и Асценси добрались своим ходом. Пришли по рыжей осенней дороге, мимо колонн, мимо деревьев, роняющих листья. Раф к тому времени стал шестнадцатым. Асценси — пятнадцатым, как я.\",\"Я ждала их до вечера у ворот, и это было хуже пещеры. Когда они показались на рыжей дороге, я сначала пересчитала: двое, медведь. Потом уже побежала.\",\"— Ты нас бросила, — сказал Раф. — С драконом.\",\"— Ты сам сказал «пожалуйста».\",\"— Сказал. А ты послушалась. Я до сих пор не решил, обижаться ли. — Он обнял меня так, что хрустнуло наплечье. — Не решил. Потом решу.\",\"Асценси сел на ступеньку и отвинтил флягу.\",\"Я пошла к очагу. Достала из сумки рыбу. Ту самую. Сырую блестящую рыбку, которую мне дал Раф. Всю. Пятьдесят три штуки.\",\"Я жарила их одну за другой, не отходя от огня, потому что рыба не прощает, когда о ней забывают. Масло шипело. Пахло рекой и дымом. Асценси сидел рядом и молча смотрел в огонь. Раф стоял, опираясь на щит.\",\"Мы ели рыбу у огня. Медведь положил морду мне на колено и получил три рыбки. Четыре. Пять. Я перестала считать.\",\"Перед сном я полистала журнал. Под рецептом блестящей рыбки кто-то, кажется я сама, вывел: {{Кулинария — 84 из 150}}. Не знаю, кто придумал мерить ужин дробью. Но рыба была вкусная.\",\"— С перцем было бы быстрее, — сказал Раф, глядя на Асценси. — Это я за тебя сказал, чтобы ты не утруждался.\",\"Асценси молча посолил свою рыбу так, что она стала белой.\",\"— Видишь? Ловкость, — сказал Раф. — Я же говорил: острое для быстрых, сытное для тех, кто стоит впереди. Мы так с Анклава спорим.\",\"— А я ем всё, — сказала я. И это была правда: я ела всё, что давали, быстро и до конца, будто завтра может не дать никто. Я до сих пор не знаю, откуда это. Но сегодня рыбы было пятьдесят три, и страх впервые промолчал.\",\"— Имя-то придумали? — спросила я.\",\"Асценси прожевал, посмотрел на медведя.\",\"— Не надо. Он знает, кто он.\",\"Медведь вздохнул. Довольно.\",\"Асценси отвинтил флягу. Плеснул на каменный пол у очага — первый глоток. А потом, не глядя, протянул её мне.\",\"Я взяла. Внутри было то же ужасное, жгучее, что я пробовала у Келмарина в Анклаве, когда решала про Сапфировую Пасть.\",\"— Брата, — сказал Асценси. Тихо, в огонь. — Он любил, чтобы пили вдвоём.\",\"Больше он ничего не сказал. Всё остальное он уже сказал там, среди разбитых яиц, и, кажется, до сих пор не мог себе этого простить. Раф перестал жевать. Я отпила, вернула флягу и тоже ничего не сказала. Иногда молчание — единственное, что можно положить рядом с чужим горем, не уронив.\",\"Где-то на краю памяти что-то шевельнулось — то ли мотив, то ли окно с хлебом. Раньше я бы кинулась за ним. Сейчас я только улыбнулась ему, как знакомому на улице, и осталась у огня. Мне было здесь хорошо.\",\"* * *\",\"Принц Кат'ранис, Глава Высокого Совета, принял голову Фалриссы в библиотеке. Он развернул тряпку, посмотрел и не поморщился. Я хотела сказать ему, что она пела в храме. Не сказала. В отчётах для Совета, наверное, не бывает такой графы.\",\"— Порой мне кажется, что каждое поколение эльфов обречено разыгрывать одну и ту же трагедию, — сказал он. — Всё та же жажда силы, всё те же ошибки. — Он поднял на меня глаза. — Но я уверен, что Высшим эльфам удастся разорвать порочный круг. Отряды следопытов и магов зачистят катакомбы. Ты сделала достаточно.\",\"— Старый союз, — сказал он. — Кель'дорай были частью Альянса. Мы не отворачиваемся от старых соратников так же легко, как эльфы крови. Отнеси это королю Вариану Ринну. В Штормград.\",\"— Наши маги откроют тебе портал. Отправляйся через него в Штормград и отнеси послание королю.\",\"* * *\",\"Двое верховных магов Эльдранила встали в рунный круг посреди библиотеки и подняли руки. Пол под ними вспыхнул синим. Руны поплыли по кругу, как рыбы в воде, и в центре закрутился свет. Сначала тонкой нитью. Потом вихрем. Потом аркой.\",\"Я смотрела в синюю гладь и видела в ней себя. Высокая женщина в тёмной робе. Скипетр на поясе. Сумка синих драконов. Письмо королю. Глаза, в которых — Норалас, и мемориалы без имён, и Фалрисса, и Рельтир, и дракон, который ждал двадцать веков.\",\"— Штормград, — сказал Раф. — Говорят, там стены выше, чем здесь деревья.\",\"— И таверн, — сказал Асценси. Встряхнул пустую флягу. И впервые за весь день улыбнулся.\",\"Я вспомнила ту девочку у повозки. Босую. Без журнала, без друзей, без памяти о том, как она туда попала. Она тогда жила чью-то чужую жизнь: чужое имя в чужих устах, чужой Свет, которому ещё надо было научиться, чужая дорога. Она ходила по ней осторожно, как по чужому дому, где боишься что-нибудь разбить.\",\"Я до сих пор не знаю, как оказалась на тех камнях. Наверное, никогда не узнаю.\",\"Но этот Свет мне не дали. Я его выучила, ошибаясь, у наставницы в Эльдраниле, у костров, в катакомбах. Этих двоих мне не выдали вместе с робой. Я их нашла. Медведь без имени положил морду мне на колени не потому, что так положено. Мемориалы без имён я гладила своими руками. Хлеб у Аллинара пекла я.\",\"Жизнь у меня одна. И она — моя.\",\"Я достала журнал и написала на последней странице этого тома, крупно, как пишут то, что важно:\",\"{{Пятнадцатый. Все живы. Иду дальше.}}\",\"И закрыла его.\",\"Раф шагнул в портал первым, как всегда. Щит, широкая спина. Асценси следом, рука на загривке медведя. Я — последней. Жрица всегда идёт последней.\",\"Я обернулась. Книги до потолка. Пыль в луче света. Золотые деревья за окном. Гавань, где я очнулась чужой и откуда ухожу собой.\",\"Мне было страшно. Мне было больно. Мне было так хорошо, что хотелось плакать.\",\"Я шагнула в синий свет. Уши останутся — почему-то я в этом уверена.\",\"Пока ещё есть куда.\"],\"plates\":[{\"after\":22,\"alt\":\"Фалрисса. Шестнадцатого уровня. Высокая, многоногая, с телом эльфийки там, где у пауков до\",\"src\":\"/chronicle/tome/110.jpg\"},{\"after\":31,\"alt\":\"— Может, ещё руку ей пожать? — сказал он хрипло. — Всё-таки королева. Этикет.\",\"src\":\"/chronicle/tome/111.jpg\"},{\"after\":48,\"alt\":\"Он протянул мне коготь. Длинный, синий, тяжёлый. Холодный, как лёд в горном озере.\",\"src\":\"/chronicle/tome/112.jpg\"},{\"after\":58,\"alt\":\"Я почувствовала его иначе. Не только силой. Голова стала яснее, на одну каплю, и Свет внут\",\"src\":\"/chronicle/tome/113.jpg\"},{\"after\":66,\"alt\":\"Огромный, синий, из рода Малигоса — Баццит, двадцатого уровня, на пять выше меня. Я не уме\",\"src\":\"/chronicle/tome/114.jpg\"},{\"after\":73,\"alt\":\"— Я… — сказал Баццит, и голос у него вдруг стал другим. Тише. — Я узнаю этот коготь. Где т\",\"src\":\"/chronicle/tome/115.jpg\"},{\"after\":107,\"alt\":\"— А я ем всё, — сказала я. И это была правда: я ела всё, что давали, быстро и до конца, бу\",\"src\":\"/chronicle/tome/116.jpg\"},{\"after\":115,\"alt\":\"Больше он ничего не сказал. Всё остальное он уже сказал там, среди разбитых яиц, и, кажетс\",\"src\":\"/chronicle/tome/117.jpg\"},{\"after\":134,\"alt\":\"Раф шагнул в портал первым, как всегда. Щит, широкая спина. Асценси следом, рука на загрив\",\"src\":\"/chronicle/tome/118.jpg\"},{\"after\":138,\"alt\":\"Пока ещё есть куда.\",\"src\":\"/chronicle/tome/119.jpg\"}]}]");
var videos_default = {
	Готика: [{
		"name": "YouTube · Готика",
		"href": "https://www.youtube.com/playlist?list=PLtGnEHCh_VGmUbQz1driM1KzNM_5tuG5d",
		"videos": [
			{
				"title": "Gothic 1 Remake ЛЮСИ В ГОТИКЕ, Хардкор. Высокая сложность. Попали в замок за броней",
				"href": "https://www.youtube.com/watch?v=jgc-Rw-Q_u4",
				"poster": "https://i3.ytimg.com/vi/jgc-Rw-Q_u4/hqdefault.jpg",
				"note": "Пришло время для настоящего испытания. Мы начинаем новую главу в Рудной долине, и на этот раз всё будет по-настоящему жестко. 🎯 Что нас…"
			},
			{
				"title": "GOTHIC REMAKE: 1 УРОВЕНЬ → КОРОЛЕВСКАЯ БРОНЯ ЗА 1 ЧАС | ХАРДКОРНЫЙ МАГ РУН (ГАЙД) #shorts",
				"href": "https://www.youtube.com/shorts/E_iNWP0NYac",
				"poster": "https://i2.ytimg.com/vi/E_iNWP0NYac/hqdefault.jpg",
				"note": "этом ролике я показываю полный путь от появления в Старом лагере до получения Королевской брони стража (48+ защиты) в Gothic Remake на…"
			},
			{
				"title": "Gothic 1 Remake ЛЮСИ В ГОТИКЕ, Хардкор. Высокая сложность. Попали в замок за броней",
				"href": "https://www.youtube.com/watch?v=LOj8mItbhjA",
				"poster": "https://i1.ytimg.com/vi/LOj8mItbhjA/hqdefault.jpg",
				"note": "Пришло время для настоящего испытания. Мы начинаем новую главу в Рудной долине, и на этот раз всё будет по-настоящему жестко. 🎯 Что нас…"
			},
			{
				"title": "Gothic 1 Remake ЛЮСИ В ГОТИКЕ, Хардкор. Высокая сложность. Попали в замок за броней",
				"href": "https://www.youtube.com/watch?v=di4rCMeWJTo",
				"poster": "https://i1.ytimg.com/vi/di4rCMeWJTo/hqdefault.jpg",
				"note": "Пришло время для настоящего испытания. Мы начинаем новую главу в Рудной долине, и на этот раз всё будет по-настоящему жестко. 🎯 Что нас…"
			},
			{
				"title": "ПОЛНОЕ ПРОХОЖДЕНИЕ Gothic 1 Remake ЛЮСИ В ГОТИКЕ, Хардкор. Безобразие, Высокая сложность.",
				"href": "https://www.youtube.com/watch?v=EhTEJLbMF9I",
				"poster": "https://i2.ytimg.com/vi/EhTEJLbMF9I/hqdefault.jpg",
				"note": "Люси снова закинуло — теперь в мрачный мир Готики (ремейк 2026). Без магии, без имперского титула, даже без штатного оружия. Только…"
			},
			{
				"title": "ЛЮСИ В ГОТИКЕ: РУДНИКИ, ГРЯЗЬ И КОШАЧЬИ УШИ 😼 | ПОЛНОЕ ПРОХОЖДЕНИЕ Gothic 1 Remake",
				"href": "https://www.youtube.com/watch?v=jo22gxosAZk",
				"poster": "https://i3.ytimg.com/vi/jo22gxosAZk/hqdefault.jpg",
				"note": "Люси снова закинуло — теперь в мрачный мир Готики (ремейк 2026). Без магии, без имперского титула, даже без штатного оружия. Только…"
			},
			{
				"title": "ЛЮСИ В ГОТИКЕ: РУДНИКИ, ГРЯЗЬ И КОШАЧЬИ УШИ 😼 | ПОЛНОЕ ПРОХОЖДЕНИЕ Gothic 1 Remake",
				"href": "https://www.youtube.com/watch?v=uX800pkasXE",
				"poster": "https://i2.ytimg.com/vi/uX800pkasXE/hqdefault.jpg",
				"note": "Люси снова закинуло — теперь в мрачный мир Готики (ремейк 2026). Без магии, без имперского титула, даже без штатного оружия. Только…"
			},
			{
				"title": "Gothic Remake: КОРОЛЕВСКАЯ БРОНЯ ЗА 1 МИНУТ! Полный маршрут (квест, магия, лут) #short #shrots",
				"href": "https://www.youtube.com/shorts/Ml_ydrnnYyo",
				"poster": "https://i2.ytimg.com/vi/Ml_ydrnnYyo/hqdefault.jpg",
				"note": "В этом гайде я покажу, как с нуля в Gothic Remake (2026) получить топовую Королевскую броню, магию огня, кольца на манну и почти 5…"
			}
		]
	}],
	Кальрадия: [{
		"name": "YouTube · Кальрадия",
		"href": "https://www.youtube.com/playlist?list=PLtGnEHCh_VGlhdYxB5yvh7G0xlMsFvY6f",
		"videos": [
			{
				"title": "Calradia — I'm Tired. A cinematic tribute to Mount & Blade II: Bannerlord",
				"href": "https://www.youtube.com/watch?v=pfSX6vHtQDA",
				"poster": "https://i1.ytimg.com/vi/pfSX6vHtQDA/hqdefault.jpg",
				"note": "Кальрадия. Дождь. Грязь. Бесконечные походы, битвы и снова походы. Это не трейлер героя. Это взгляд на войну глазами того, кто устал…"
			},
			{
				"title": "(Финал - Победа) ЛЮСИ В КАЛЬРАДИИ: ПУТЕШЕСТВИЕ ЛОРДА | Mount & Blade II: Bannerlord",
				"href": "https://www.youtube.com/watch?v=zM9z42PrZJY",
				"poster": "https://i3.ytimg.com/vi/zM9z42PrZJY/hqdefault.jpg",
				"note": "Люси очнулась в жестоком мире Mount & Blade II: Bannerlord. Магии больше нет — только сталь, грязь и наёмники. Уши остались, Свет…"
			},
			{
				"title": "(Финал) ЛЮСИ В КАЛЬРАДИИ: ПУТЕШЕСТВИЕ — ОТ НАЁМНИЦЫ ДО ЛОРДА | Mount & Blade II: Bannerlord",
				"href": "https://www.youtube.com/watch?v=afjI7ZsDG6Y",
				"poster": "https://i2.ytimg.com/vi/afjI7ZsDG6Y/hqdefault.jpg",
				"note": "Люси очнулась в жестоком мире Mount & Blade II: Bannerlord. Магии больше нет — только сталь, грязь и наёмники. Уши остались, Свет…"
			},
			{
				"title": "МЕНЯ УБИЛИ, НО Я ПРОСНУЛАСЬ ЗА ДЕНЬ ДО БИТВЫ 😨 (Bannerlord) #Shorts",
				"href": "https://www.youtube.com/shorts/u_Xq8NN6Nv8",
				"poster": "https://i2.ytimg.com/vi/u_Xq8NN6Nv8/hqdefault.jpg",
				"note": "Люси атакует отряд лучников — и падает, пронзённая стрелами. Но вместо вечности она открывает глаза в своей палатке. Всё выглядит так…"
			},
			{
				"title": "ЛЮСИ В КАЛЬРАДИИ: ПУТЕШЕСТВИЕ — ОТ НАЁМНИЦЫ ДО ЛОРДА | Mount & Blade II: Bannerlord",
				"href": "https://www.youtube.com/watch?v=mxg_YLfw9dk",
				"poster": "https://i2.ytimg.com/vi/mxg_YLfw9dk/hqdefault.jpg",
				"note": "Люси очнулась в жестоком мире Mount & Blade II: Bannerlord. Магии больше нет — только сталь, грязь и наёмники. Уши остались, Свет…"
			},
			{
				"title": "ЛЮСИ В КАЛЬРАДИИ: ПУТЕШЕСТВИЕ — ОТ НАЁМНИЦЫ ДО ЛОРДА | Mount & Blade II: Bannerlord",
				"href": "https://www.youtube.com/watch?v=Hy-5BULhWIY",
				"poster": "https://i1.ytimg.com/vi/Hy-5BULhWIY/hqdefault.jpg",
				"note": "Люси очнулась в жестоком мире Mount & Blade II: Bannerlord. Магии больше нет — только сталь, грязь и наёмники. Уши остались, Свет…"
			},
			{
				"title": "ЛЮСИ В КАЛЬРАДИИ: ПУТЕШЕСТВИЕ — ОТ НАЁМНИЦЫ ДО ЛОРДА | Mount & Blade II: Bannerlord",
				"href": "https://www.youtube.com/watch?v=61iNK2IIJZw",
				"poster": "https://i3.ytimg.com/vi/61iNK2IIJZw/hqdefault.jpg",
				"note": "Люси очнулась в жестоком мире Mount & Blade II: Bannerlord. Магии больше нет — только сталь, грязь и наёмники. Уши остались, Свет…"
			},
			{
				"title": "ЛЮСИ В КАЛЬРАДИИ: ПУТЕШЕСТВИЕ — ОТ НАЁМНИЦЫ ДО ЛОРДА | Mount & Blade II: Bannerlord",
				"href": "https://www.youtube.com/watch?v=ptAjbg4ZQNo",
				"poster": "https://i1.ytimg.com/vi/ptAjbg4ZQNo/hqdefault.jpg",
				"note": "Люси очнулась в жестоком мире Mount & Blade II: Bannerlord. Магии больше нет — только сталь, грязь и наёмники. Уши остались, Свет…"
			}
		]
	}],
	Pathfinder: [{
		"name": "YouTube · Pathfinder",
		"href": "https://www.youtube.com/playlist?list=PLOku197whkiw",
		"videos": [
			{
				"title": "Просто поешь Говядины! 🍖 Гоблинская вечеринка на мельнице #shorts  #games",
				"href": "https://www.youtube.com/shorts/MponHwbPkB4",
				"poster": "https://i2.ytimg.com/vi/MponHwbPkB4/hqdefault.jpg",
				"note": "Мы исследуем захватывающие миры фэнтези, разгадываем головоломки, сражаемся с монстрами и принимаем решения, влияющие на ход сюжета.…"
			},
			{
				"title": "Lucy in Pathfinder: Kingmaker — Война с Королём-Варваром: Питакс, интриги и вождь, рождённый дважды",
				"href": "https://www.youtube.com/watch?v=JeyCPgDaaos",
				"poster": "https://i3.ytimg.com/vi/JeyCPgDaaos/hqdefault.jpg",
				"note": "Глава 5: Война с Королём-Варваром начинается. Варварские орды отступили, но на севере появилась новая угроза — безумный вождь Армаг…"
			},
			{
				"title": "Мудрецы в шоке от секретной техники Люси 🧘‍♀️💀",
				"href": "https://www.youtube.com/shorts/CwduFnC4yTM",
				"poster": "https://i4.ytimg.com/vi/CwduFnC4yTM/hqdefault.jpg",
				"note": "Мы исследуем захватывающие миры фэнтези, разгадываем головоломки, сражаемся с монстрами и принимаем решения, влияющие на ход сюжета.…"
			},
			{
				"title": "Lucy in Pathfinder: Kingmaker — Гробница Вордакая: смерть или служение? 😼",
				"href": "https://www.youtube.com/watch?v=8xJgAQahUWE",
				"poster": "https://i1.ytimg.com/vi/8xJgAQahUWE/hqdefault.jpg",
				"note": "Ворон сказал: «Ты умрёшь здесь и будешь служить». Люси стоит у входа в Гробницу Вордакая — древнюю усыпальницу циклопического лича,…"
			},
			{
				"title": "Самый потный гайд по выживанию в RPG Маги скрывали ЭТОТ лайфхак по выживанию... #shorts",
				"href": "https://www.youtube.com/shorts/ALdOSoQ_85I",
				"poster": "https://i2.ytimg.com/vi/ALdOSoQ_85I/hqdefault.jpg",
				"note": "Мы исследуем захватывающие миры фэнтези, разгадываем головоломки, сражаемся с монстрами и принимаем решения, влияющие на ход сюжета.…"
			},
			{
				"title": "Люси в Pathfinder: Kingmaker — Варвары? Дипломатия или кулаки?😼",
				"href": "https://www.youtube.com/watch?v=uGm_UJnvZM8",
				"poster": "https://i2.ytimg.com/vi/uGm_UJnvZM8/hqdefault.jpg",
				"note": "Люси стоит на пороге варварского лагеря. Вопрос только один: варвары? Они враги или союзники? Ответ зависит от неё. Келлидские племена —…"
			},
			{
				"title": "Lucy in Pathfinder: Kingmaker — Исчезновение Варнхолда: город-призрак и древняя тайна 😼",
				"href": "https://www.youtube.com/watch?v=AQWZ6L8VCt8",
				"poster": "https://i2.ytimg.com/vi/AQWZ6L8VCt8/hqdefault.jpg",
				"note": "Целый город. Все жители. Испарились без следа. Джаманди Алдори требует ответов, а Эдрист Ханваки просит найти его брата Томина. Люси…"
			},
			{
				"title": "Lucy in Pathfinder: Kingmaker — Исчезновение Варнхолда: город-призрак и древняя тайна 😼",
				"href": "https://www.youtube.com/watch?v=3lQ5WQAiOgk",
				"poster": "https://i4.ytimg.com/vi/3lQ5WQAiOgk/hqdefault.jpg",
				"note": "Целый город. Все жители. Испарились без следа. Джаманди Алдори требует ответов, а Эдрист Ханваки просит найти его брата Томина. Люси…"
			}
		]
	}],
	"Path of Exile": [{
		"name": "YouTube · Path of Exile",
		"href": "https://www.youtube.com/playlist?list=PLZgiDszCsfE0",
		"videos": [{
			"title": "LUCY IN PATH OF EXILE: ОДИН ДЕНЬ В ШКУРЕ ДВОРЯНКИ 😼",
			"href": "https://www.youtube.com/watch?v=yGGTDKVeJJQ",
			"poster": "https://i2.ytimg.com/vi/yGGTDKVeJJQ/hqdefault.jpg",
			"note": "Люси случайно закинуло в Path of Exile. Всего на один день она стала Дворянкой (Scion) — изгнанной аристократкой, дочерью…"
		}]
	}],
	"Tomb Raider": [{
		"name": "YouTube · Tomb Raider",
		"href": "https://www.youtube.com/playlist?list=PLQ8b-rX6kysE",
		"videos": [
			{
				"title": "LUCY IN RISE OF THE TOMB RAIDER: ГЕОТЕРМАЛЬНАЯ ДОЛИНА — СОЮЗНИКИ И ОПАСНОСТЬ 😼",
				"href": "https://www.youtube.com/watch?v=iJaXYKmhTAs",
				"poster": "https://i2.ytimg.com/vi/iJaXYKmhTAs/hqdefault.jpg",
				"note": "Люси продолжает путь в Сибири. Она добралась до Геотермальной долины — одного из самых больших и важных регионов в игре. Это не просто…"
			},
			{
				"title": "LUCY IN RISE OF THE TOMB RAIDER: ДОЛИНА БАБЫ ЯГИ — ТАЙНА ВЕДЬМЫ 😼",
				"href": "https://www.youtube.com/watch?v=SLrjGiV5tKU",
				"poster": "https://i4.ytimg.com/vi/SLrjGiV5tKU/hqdefault.jpg",
				"note": "Люси попала в Долину Бабы Яги. Она встречает перепуганную девушку Надю, которая прячется от солдат «Троицы» на старой лесопилке. Надя…"
			},
			{
				"title": "LUCY IN RISE OF THE TOMB RAIDER: СОВЕТСКАЯ БАЗА — МЕДЕПЛАВИЛЬНЫЙ ЗАВОД И ВСТРЕЧА С ЯКОВОМ 😼",
				"href": "https://www.youtube.com/watch?v=Wpi8QTLYlD8",
				"poster": "https://i4.ytimg.com/vi/Wpi8QTLYlD8/hqdefault.jpg",
				"note": "Люси продолжает путь в Сибири. Она добралась до советской базы — огромного промышленного комплекса, затерянного в снегах. Её цель —…"
			},
			{
				"title": "LUCY IN RISE OF THE TOMB RAIDER: СИБИРЬ, СНЕГ И НОВАЯ ЗАГАДКА 😼",
				"href": "https://www.youtube.com/watch?v=cRDEWwOsqFg",
				"poster": "https://i4.ytimg.com/vi/cRDEWwOsqFg/hqdefault.jpg",
				"note": "Люси покинула остров Яматай, но ответы так и не пришли. Она чувствовала, что за этим миром стоит что-то большее, и теперь она в Сибири.…"
			},
			{
				"title": "LUCY IN TOMB RAIDER: ХРАМ, ТОЧКА НЕВОЗВРАТА И ВЕТЕР ПЕРЕМЕН 😼 (финал)",
				"href": "https://www.youtube.com/watch?v=OBwtfBhAAME",
				"poster": "https://i4.ytimg.com/vi/OBwtfBhAAME/hqdefault.jpg",
				"note": "Люси достигла храма. Это точка невозврата. Дальше — только вперёд. Игра предупреждает: после этого момента не будет возможности…"
			},
			{
				"title": "LUCY IN TOMB RAIDER: СВОИХ НЕ БРОСАЕМ — СПАСТИ КОМАНДУ \"ЭНДЬЮРАНС\" 😼",
				"href": "https://www.youtube.com/watch?v=ENiWTbwC4uw",
				"poster": "https://i2.ytimg.com/vi/ENiWTbwC4uw/hqdefault.jpg",
				"note": "Люси не бросает своих. Она прошла гробницы, выжила в джунглях и пережила засаду. Теперь у неё новая цель — найти и спасти команду…"
			},
			{
				"title": "ЛЮСИ В TOMB RAIDER: ВИСЕЛА, ВЫЖИЛА, ПОДПИШИСЬ 😼 #Shorts  #games #TR",
				"href": "https://www.youtube.com/shorts/DZZCdI14VMU",
				"poster": "https://i1.ytimg.com/vi/DZZCdI14VMU/hqdefault.jpg",
				"note": "Самолёт разбился. Люси бежит к месту крушения — и попадает в засаду. Её бьют по голове, и она просыпается висящей вверх ногами в древней…"
			},
			{
				"title": "LUCY IN TOMB RAIDER: ПУТЬ НА БАЗУ БРАТСТВА — 30% ПРОЙДЕНО 😼",
				"href": "https://www.youtube.com/watch?v=J2lHcg0kYV8",
				"poster": "https://i3.ytimg.com/vi/J2lHcg0kYV8/hqdefault.jpg",
				"note": "Люси добралась до бункера, забралась на вышку и вызвала самолёт. Он прилетел. И разбился. В очередной раз. Теперь она внутри древней…"
			}
		]
	}, {
		"name": "Rutube · Tomb Raider",
		"href": "https://rutube.ru/plst/1731250/",
		"videos": [{
			"title": "LUCY IN TOMB RAIDER: ВЫЖИВАНИЕ НА ОСТРОВЕ ЯМАТАЙ 😼",
			"href": "https://rutube.ru/video/9b1e7b3a01cb36a2ef6f9eec1bba50cc/",
			"poster": "https://pic.rtbcdn.ru/video/2026-07-17/07/c5/07c5d59d4a4b60abc9d361fb6fa8ac09.jpg",
			"note": "Люси снова в новом мире. Она не знает, как сюда попала. Она не знает, кто такая Лара Крофт. И она точно не знает, что происходит на этом…"
		}, {
			"title": "ЛЮСИ В TOMB RAIDER: ПЕРВЫЙ ДЕНЬ НА ОСТРОВЕ 😼 #Shorts  #games",
			"href": "https://rutube.ru/video/f5eb501b60e528602eda6c508a03f937/",
			"poster": "https://pic.rtbcdn.ru/video/2026-07-20/78/37/78371e8eed2ab878d9a2d7685f44be71.jpg",
			"note": "Люси разбилась на корабле и очнулась на берегу загадочного острова. Мокрая, грязная, без обуви и без связи. Она выживает, находит лук,…"
		}]
	}],
	Fallout: [
		{
			"name": "YouTube · Fallout",
			"href": "https://www.youtube.com/playlist?list=PLtGnEHCh_VGnTpCV2d5i0z5epscDC0zJZ",
			"videos": [
				{
					"title": "Люси: История прохождения Fallout 1 — Финал и Создатель #shorts #games  #games #fallout #shortsvideo",
					"href": "https://www.youtube.com/shorts/MHEyy2LHzps",
					"poster": "https://i2.ytimg.com/vi/MHEyy2LHzps/hqdefault.jpg",
					"note": "Финал истории выживания Люси в культовом мире Fallout 1! Удастся ли спасти Убежище 13, победить армию супермутантов и остановить…"
				},
				{
					"title": "Люси путешественница меж миров история первая часть 1 Мир Fallout #shorts",
					"href": "https://www.youtube.com/shorts/zsciJwUUirI",
					"poster": "https://i3.ytimg.com/vi/zsciJwUUirI/hqdefault.jpg",
					"note": "Люси просыпается в Убежище 13 без памяти о прошлом, но поломка водяного чипа заставляет её выйти в опасную Пустошь... Удастся ли спасти…"
				},
				{
					"title": "📻 Я НАШЛА СЧЁТЧИК ГЕЙГЕРА. ТЕПЕРЬ Я ЗНАЮ, ЧТО ВСЁ ВОКРУГ МЕНЯ — РАДИАЦИЯ. 📻  #fallout  #falloutlore",
					"href": "https://www.youtube.com/shorts/tW4KkA54SAo",
					"poster": "https://i1.ytimg.com/vi/tW4KkA54SAo/hqdefault.jpg",
					"note": "Ян остался в городе, я одна в пустоши. И что я делаю в первую очередь? Нахожу старый счётчик Гейгера и начинаю проверять всё подряд.…"
				},
				{
					"title": "🦂 КОРОЛЕВА СКОРПИОНОВ. МЫ С ЯНОМ ПРОТИВ НЕЁ. СПОЙЛЕР: Я ЖИВА. 🦂",
					"href": "https://www.youtube.com/shorts/W1ZcpmKNm9w",
					"poster": "https://i4.ytimg.com/vi/W1ZcpmKNm9w/hqdefault.jpg",
					"note": "прошлой серии мы нашли пещеру. В этой — королева нашла нас. 0:00 – Она огромная. У неё план? Нет. У меня? Тоже нет 0:10 – Ян стреляет! Я…"
				},
				{
					"title": "🦂 Я ЗАШЛА В ПЕЩЕРУ. СКОРПИОНЫ ТОЖЕ ЗАШЛИ. НО ОНИ ЗАШЛИ, ЧТОБЫ МЕНЯ СЪЕСТЬ. 🦂  #fallout  #falloutlore",
					"href": "https://www.youtube.com/shorts/MSTEk7k38m4",
					"poster": "https://i2.ytimg.com/vi/MSTEk7k38m4/hqdefault.jpg",
					"note": "В прошлой серии мы взяли задание зачистить пещеру. В этой — я чуть не стала ужином. 0:00 – Пещера пахнет смертью. Ян, проходи первый…"
				},
				{
					"title": "🦂 ЗАДАНИЕ: ЗАЧИСТИТЬ ПЕЩЕРУ ОТ РАДСКОРПИОНОВ. НАГРАДА: КРЫШКИ. И ВЫЖИТЬ. 🦂  #fallout",
					"href": "https://www.youtube.com/shorts/dki2Bd54evY",
					"poster": "https://i1.ytimg.com/vi/dki2Bd54evY/hqdefault.jpg",
					"note": "Я – Люси Кошечка, девушка с кошачьими ушами, напарником Яном и полным отсутствием опыта в уничтожении гигантских радиоактивных…"
				},
				{
					"title": "Я нашла деревню в пустоши и познакомилась с Яном 🏜️ #fallout #short  #falloutlore #gaming #стрим",
					"href": "https://www.youtube.com/shorts/vAWgFhoaTrQ",
					"poster": "https://i3.ytimg.com/vi/vAWgFhoaTrQ/hqdefault.jpg",
					"note": "🏜️ ПУТЕШЕСТВИЕ К УБЕЖИЩУ 15: ТОЛЬКО ПЫЛЬ, ЖАРА И СЛУЧАЙНАЯ ДЕРЕВНЯ 🏜️ Я – Люси Кошечка, бывший житель Убежища 13, а теперь –…"
				},
				{
					"title": "Когда пытаешься быть горячей в Fallout … Ой, нет 😭💥 #fallout #fallout2 #shorts #falloutlore #newreno",
					"href": "https://www.youtube.com/shorts/VOXX4NWSeT0",
					"poster": "https://i3.ytimg.com/vi/VOXX4NWSeT0/hqdefault.jpg",
					"note": "Когда пришла в Казино НЬЮ-РИНО и тебе сказали что ты можешь танцевать, а стул выглядит как подиум 🪑 Люси с ушками: 100% уверенности, 0%…"
				}
			]
		},
		{
			"name": "YouTube · Fallout 4",
			"href": "https://www.youtube.com/playlist?list=PLtGnEHCh_VGk7xJ3EpQywJ1I1ML4bRuFG",
			"videos": [
				{
					"title": "Fallout 4 | Люси идёт к Братству. Прошлое — прошлым, ушки — на месте 😼",
					"href": "https://www.youtube.com/watch?v=oygmTx9g2BA",
					"poster": "https://i4.ytimg.com/vi/oygmTx9g2BA/hqdefault.jpg",
					"note": "Минитмены — не её история. Престон Гарви хороший парень, но Люси не нанималась в курьеры по спасению поселений. Она солдат Братства.…"
				},
				{
					"title": "Fallout 4 | Люси идёт к Братству. Прошлое — прошлым, ушки — на месте 😼",
					"href": "https://www.youtube.com/watch?v=dDiXGe3B5vI",
					"poster": "https://i1.ytimg.com/vi/dDiXGe3B5vI/hqdefault.jpg",
					"note": "Минитмены — не её история. Престон Гарви хороший парень, но Люси не нанималась в курьеры по спасению поселений. Она солдат Братства.…"
				},
				{
					"title": "Fallout 4 | Люси идёт к Братству. Прошлое — прошлым, ушки — на месте 😼",
					"href": "https://www.youtube.com/watch?v=umERgbepJHw",
					"poster": "https://i2.ytimg.com/vi/umERgbepJHw/hqdefault.jpg",
					"note": "Минитмены — не её история. Престон Гарви хороший парень, но Люси не нанималась в курьеры по спасению поселений. Она солдат Братства.…"
				},
				{
					"title": "Я попробовала еду и выжила. Мои уши чуть не улетели 🚀  #fallout #falloutlore #fallout4 #shorts",
					"href": "https://www.youtube.com/shorts/kZ4ugDEIems",
					"poster": "https://i4.ytimg.com/vi/kZ4ugDEIems/hqdefault.jpg",
					"note": "🚀 Я ПОПРОБОВАЛА ЕДУ ИЗ ФОЛЛАУТА. МОИ УШИ ТОЖЕ УЧАСТВОВАЛИ. 🚀 В этом ролике я решила не сдерживать эмоции. Вы увидите, как мутафрукт…"
				},
				{
					"title": "Fallout 4 | Люси идёт к Братству. Прошлое — прошлым, ушки — на месте 😼",
					"href": "https://www.youtube.com/watch?v=WoyLzO-j_4A",
					"poster": "https://i4.ytimg.com/vi/WoyLzO-j_4A/hqdefault.jpg",
					"note": "Минитмены — не её история. Престон Гарви хороший парень, но Люси не нанималась в курьеры по спасению поселений. Она солдат Братства.…"
				},
				{
					"title": "Fallout 4 | Люси идёт к Братству. Прошлое — прошлым, ушки — на месте 😼",
					"href": "https://www.youtube.com/watch?v=7m_0dJx3_AU",
					"poster": "https://i4.ytimg.com/vi/7m_0dJx3_AU/hqdefault.jpg",
					"note": "Минитмены — не её история. Престон Гарви хороший парень, но Люси не нанималась в курьеры по спасению поселений. Она солдат Братства.…"
				},
				{
					"title": "Fallout 4 | Люси идёт к Братству. Прошлое — прошлым, ушки — на месте 😼",
					"href": "https://www.youtube.com/watch?v=P3NhOAlPvMk",
					"poster": "https://i1.ytimg.com/vi/P3NhOAlPvMk/hqdefault.jpg",
					"note": "Минитмены — не её история. Престон Гарви хороший парень, но Люси не нанималась в курьеры по спасению поселений. Она солдат Братства.…"
				},
				{
					"title": "Fallout 4 | Люси идёт к Братству. Прошлое — прошлым, ушки — на месте 😼",
					"href": "https://www.youtube.com/watch?v=3og0_QcIwxo",
					"poster": "https://i4.ytimg.com/vi/3og0_QcIwxo/hqdefault.jpg",
					"note": "Минитмены — не её история. Престон Гарви хороший парень, но Люси не нанималась в курьеры по спасению поселений. Она солдат Братства.…"
				}
			]
		},
		{
			"name": "YouTube · Tactics",
			"href": "https://www.youtube.com/playlist?list=PLtGnEHCh_VGl0kUkgsw3wksEmkoVebCmv",
			"videos": [
				{
					"title": "Fallout Tactics | Миссия 20: Убежище 0",
					"href": "https://www.youtube.com/watch?v=b8eTgAzBW6g",
					"poster": "https://i3.ytimg.com/vi/b8eTgAzBW6g/hqdefault.jpg",
					"note": "Краткий обзор — финал приближается Заголовок: Fallout Tactics | Люси в сердце тьмы. Убежище 0, три энергоузла и Калькулятор за углом 😼🏭⚡…"
				},
				{
					"title": "Я попыталась получить гражданство НКР  #falloutlore  #нейросеть  #юмор #shorts #fallout #ncr",
					"href": "https://www.youtube.com/shorts/BcMYR9SREgU",
					"poster": "https://i3.ytimg.com/vi/BcMYR9SREgU/hqdefault.jpg",
					"note": "Я ПОПЫТАЛАСЬ СТАТЬ ГРАЖДАНКОЙ НКР. СПОЙЛЕР: ВСЁ ПОШЛО НЕ ПО ПЛАНУ. Подписывайся, или Грег заставит тебя ждать 4 часа 👉 Думаете,…"
				},
				{
					"title": "Fallout Tactics | Миссия 19: Гора Шайенн",
					"href": "https://www.youtube.com/watch?v=8gWjzOE-DR4",
					"poster": "https://i1.ytimg.com/vi/8gWjzOE-DR4/hqdefault.jpg",
					"note": "Краткий обзор Заголовок: Fallout Tactics | Люси везёт ядерку к Калькулятору. Гора Шайенн, финал близко 😼💥🏔️ Что случилось: Скотт-Сити…"
				},
				{
					"title": "Fallout Tactics | Миссия 18: Скотт-Сити",
					"href": "https://www.youtube.com/watch?v=-pne-IUfcf8",
					"poster": "https://i2.ytimg.com/vi/-pne-IUfcf8/hqdefault.jpg",
					"note": "Краткий обзор (без прикрас) Что случилось: Буэна-Виста позади, реактор взорван, роботы лишились энергии. Но Калькулятор нанёс ответный…"
				},
				{
					"title": "Можно ли есть ТОШКУ из Fallout? 🤢→😋  #falloutlore #fallout #fallouttactics #юмор #shorts  #люси",
					"href": "https://www.youtube.com/shorts/5Q2_PMtvyxw",
					"poster": "https://i2.ytimg.com/vi/5Q2_PMtvyxw/hqdefault.jpg",
					"note": "🍅🥔 ЧТО ТАКОЕ ТОШКА И ПОЧЕМУ ПАЛАДИНЫ БРАТСТВА СТАЛИ ОТВОРАЧИВАЮТСЯ? 🥔🍅 Всем привет! С вами Люси Кошечка – ваш главный инфлюенсер…"
				},
				{
					"title": "Fallout Tactics | Миссия 17: Буэна-Виста",
					"href": "https://www.youtube.com/watch?v=MFk_lg-ZnII",
					"poster": "https://i2.ytimg.com/vi/MFk_lg-ZnII/hqdefault.jpg",
					"note": "Fallout Tactics | Люси выдёргивает штепсель Калькулятора. Буэна-Виста, реактор и армия роботов 😼🏭⚡ Что случилось: Каньон-сити позади. Мы…"
				},
				{
					"title": "Fallout Tactics | Миссия 16: Каньон-сити",
					"href": "https://www.youtube.com/watch?v=r0viyo_SRfM",
					"poster": "https://i3.ytimg.com/vi/r0viyo_SRfM/hqdefault.jpg",
					"note": "Fallout Tactics | Люси, танк и самоуничтожающиеся узлы. Каньон-сити, мы идём 😼🏭🔥 Что случилось: Ньютон позади. Мы вытащили четырёх…"
				},
				{
					"title": "Fallout Tactics | Люси спасает рейдеров. Ньютон, прототип EMP и танк в подарок 😼⚡🔥 | Миссия 15",
					"href": "https://www.youtube.com/watch?v=YvkDNfakhHs",
					"poster": "https://i2.ytimg.com/vi/YvkDNfakhHs/hqdefault.jpg",
					"note": "Что случилось: Грейт-Бенд позади. Роботов зачистили, патроны экономили, выживших нашли. Братство довольно. Но война с Калькулятором…"
				}
			]
		},
		{
			"name": "Rutube · Fallout 1",
			"href": "https://rutube.ru/plst/1495566/",
			"videos": [{
				"title": "Fallout | Люси - \"Сквозь время - часть первая\"",
				"href": "https://rutube.ru/video/08f04abaf2a61bc56aee345f99da4694/",
				"poster": "https://pic.rtbcdn.ru/video/2026-02-02/54/6c/546c5b7680c3b3b077f580973c616723.jpg",
				"note": "— исследуем атмосферу — погружаемся в диалоги и мир — смотрим, как игра ощущается сегодня — без спешки и без спойлеров Добро пожаловать"
			}, {
				"title": "Fallout | Люси - \"Сквозь время - часть первая\"",
				"href": "https://rutube.ru/video/24a93285564c534ce3c801814c9e7180/",
				"poster": "https://pic.rtbcdn.ru/video/2026-02-03/22/02/2202673de5267187b734735819082ebb.jpg",
				"note": "— исследуем атмосферу — погружаемся в диалоги и мир — смотрим, как игра ощущается сегодня — без спешки и без спойлеров Добро пожаловать"
			}]
		},
		{
			"name": "Rutube · Fallout 2",
			"href": "https://rutube.ru/plst/1495567/",
			"videos": [
				{
					"title": "Fallout 2 | Люси - \"Сквозь время - часть вторая\"",
					"href": "https://rutube.ru/video/18abbd60bbf91dd69a68157caff92ce7/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-04/af/3b/af3b108d92fb393a498dca40d0d25198.jpg",
					"note": "Проходим Фаллаут за девочку люси 18 лет, наивна, чиста, и благородна."
				},
				{
					"title": "Fallout 2 | Люси - \"Сквозь время - часть вторая\"",
					"href": "https://rutube.ru/video/1a640f76b5036cfa7c75f92931ab2cb7/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-07/82/48/82483e22ab0fdeac4169c52b90e0247d.jpg",
					"note": "Проходим Фаллаут за девочку люси 18 лет, наивна, чиста, и благородна."
				},
				{
					"title": "Fallout 2 | Люси - \"Сквозь время - часть вторая\"",
					"href": "https://rutube.ru/video/1f38de1b5d83216d375b0326f46cf11c/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-05/e4/ea/e4ea59443927f478ffcbf71c13a0c932.jpg",
					"note": "Проходим Фаллаут за девочку люси 18 лет, наивна, чиста, и благородна."
				},
				{
					"title": "Fallout 2 | Люси - \"Сквозь время - часть вторая\"",
					"href": "https://rutube.ru/video/2bcb6d5462ad36203f024ace26d689ac/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-07/72/a8/72a81464f01b04942b6fc8ce5781327b.jpg",
					"note": "Проходим Фаллаут за девочку люси 18 лет, наивна, чиста, и благородна."
				},
				{
					"title": "Fallout 2 | Люси - \"Сквозь время - часть вторая\"",
					"href": "https://rutube.ru/video/370ad8f71a0265aa251f4c9426d06cad/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-05/dc/b4/dcb4262f4ac4e01790e9a27aad9e81a3.jpg",
					"note": "Проходим Фаллаут за девочку люси 18 лет, наивна, чиста, и благородна."
				},
				{
					"title": "Fallout 2 | Люси - \"Сквозь время - часть вторая\"",
					"href": "https://rutube.ru/video/423944b3ea3e461c68f54855fe1a514a/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-03/f7/75/f775a5889be97b51ce8a88c6169986c4.jpg",
					"note": "Проходим Фаллаут за девочку люси 18 лет, наивна, чиста, и благородна."
				},
				{
					"title": "Fallout 2 | Люси - \"Сквозь время - часть вторая\"",
					"href": "https://rutube.ru/video/4385c13ec3f790b8c09aedd7138c55fe/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-13/3a/c8/3ac85ab205b15fde7fbf7ee3968cfe12.jpg",
					"note": "Проходим Фаллаут за девочку люси 18 лет, наивна, чиста, и благородна."
				},
				{
					"title": "Fallout 2 | Люси - \"Сквозь время - часть вторая\"",
					"href": "https://rutube.ru/video/5af6ec31f7b6dea7460237686a4724ae/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-12/3f/ec/3fec66efc63792c9d8ef3fbc2c20b76e.jpg",
					"note": "Проходим Фаллаут за девочку люси 18 лет, наивна, чиста, и благородна."
				}
			]
		},
		{
			"name": "Rutube · Tactics",
			"href": "https://rutube.ru/plst/1495569/",
			"videos": [
				{
					"title": "ПРЯМОЙ ЭФИР ПРЕРВАН... Последние кадры с пустошей 😱  #fallouttactics #shorts  #братствостали",
					"href": "https://rutube.ru/video/325c1450a0872cf0962bfa173499e760/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-26/72/5c/725c25451e6cc556be8b76c240ab6d53.jpg",
					"note": "Fallout Tactics | Миссия 8: Сент-Луис Супер-мутанты ждут 😼🔥 Текст анонса: После Мардина и битвы со зверомагами мы думали, что хуже уже…"
				},
				{
					"title": "ЛЮСИ СМОТРИТ STATE OF THE UNION В FALLOUT #games  #fallout #stateofpolitics #fallouttactics  #юмор",
					"href": "https://rutube.ru/video/6db0173acfb177d137a9f58d76e75fa5/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-28/dc/70/dc7017fbdf9b89ef1a0d6e3b0088d091.jpg",
					"note": "📺 ПОЛИТИЧЕСКИЙ ВЛОГ ИЗ ПУСТОШЕЙ | Люси смотрит обращение НКР Люси-Кошка нашла в бункере старый довоенный телевизор и случайно поймала…"
				},
				{
					"title": "Fallout Tactics | Миссия 2: «Фрипорт»",
					"href": "https://rutube.ru/video/75262ac5bbc1323be7b8ecf8d3d34f37/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-18/67/3c/673ca6dfeb0c67d9123cf64372bcbbfe.jpg",
					"note": "Fallout Tactics | Миссия 2: «Фрипорт» Люси выполнила приказ, но трибунал Братства усомнился в ней из-за потери Фарсайт и Ститча. А потом…"
				},
				{
					"title": "Fallout Tactics: Brotherhood of Steel | Люси - \"Сквозь время - Братство стали\"",
					"href": "https://rutube.ru/video/78d357fc535d165034d960a307b9acd6/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-16/41/3a/413a7667cdf9cfe5b94ca20538880851.jpg",
					"note": "Это стрим-знакомство: — исследуем атмосферу — погружаемся в диалоги и мир — смотрим, как игра ощущается сегодня — без спешки и без…"
				},
				{
					"title": "Fallout Tactics | Миссия 3: «Рок-Фолс. Билет в один конец»",
					"href": "https://rutube.ru/video/7ea86985c219fb55d345dc88c9860ca0/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-18/67/40/67407edf604098ae934d9a427d64dc1c.jpg",
					"note": "Фрипорт стал братской могилой. Отряд разделился — и больше не сошёлся. Люси спасла осведомителя, вызволила женщину из плена и…"
				},
				{
					"title": "🎵 ЛЮСИ ТАНЦУЕТ ТИКТОК, А КОГТИК В ШОКЕ | Музыка в пустошах меняет всё 🤣",
					"href": "https://rutube.ru/video/851bf352b752887cf09dbf786fbf5cee/",
					"poster": "https://pic.rtbcdn.ru/video/2026-03-02/e6/86/e68657dbb3c208d94a596dcaf3863fb4.jpg",
					"note": "🎵 Я НАШЛА МУЗЫКУ В ПУСТОШАХ (и теперь танцую тикток) Бродила по пустошам, наткнулась на странную довоенную штуку. Сначала думала —…"
				},
				{
					"title": "БРАТЬЯ В ТРУСАХ С МИНИГАНАМИ... И ЭТО Я ВИНОВАТА 🩲🔫  #fallouttactics #shorts  #falloutlore  #юмор",
					"href": "https://rutube.ru/video/8c8cfbb47c99a872671d67b3a7385dea/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-28/51/f6/51f6a99c686694ef56769cc96b493e47.jpg",
					"note": "Люси-Кошка отдыхает между миссиями и развлекается как может: 💣 Мина под одеяло 🐀 Крыса в суп 🦎 Коготь смерти по кличке Когтик (да, он…"
				},
				{
					"title": "Fallout Tactics: Brotherhood of Steel | Люси - \"Сквозь время - Братство стали\"",
					"href": "https://rutube.ru/video/8fe9da23de8fc8c5208fd1566183d76f/",
					"poster": "https://pic.rtbcdn.ru/video/2026-02-17/9c/6f/9c6f60ca8e824e2846d3bcc393e7bd66.jpg",
					"note": "Fallout Tactics | Люси: «Одиночка» Первая миссия Братства стала последней для моего отряда. Фарсайт и Ститч погибли в засаде. Теперь…"
				}
			]
		}
	],
	Кенши: [{
		"name": "YouTube · Кенши",
		"href": "https://www.youtube.com/playlist?list=PLB8J1X1WE4d4",
		"videos": [
			{
				"title": "ЛЮСИ В KENSHI: 106 ДНЕЙ — КАК КОШКА, УШЛА УМИРАТЬ... 😢 ( Финал ?)",
				"href": "https://www.youtube.com/watch?v=kRnVTqRjDwE",
				"poster": "https://i4.ytimg.com/vi/kRnVTqRjDwE/hqdefault.jpg",
				"note": "100 дней в Kenshi. Люси пробыла в этом мире 100 дней. Она собирала силы, училась выживать, сражаться и не бояться. Но теперь она…"
			},
			{
				"title": "ЛЮСИ В KENSHI: 100 ДНЕЙ — КАК КОШКА, УШЛА УМИРАТЬ... 😢 ( Финал ?)",
				"href": "https://www.youtube.com/watch?v=vztwmqLQEho",
				"poster": "https://i3.ytimg.com/vi/vztwmqLQEho/hqdefault.jpg",
				"note": "100 дней в Kenshi. Люси пробыла в этом мире 100 дней. Она собирала силы, училась выживать, сражаться и не бояться. Но теперь она…"
			},
			{
				"title": "ЛЮСИ В KENSHI: ДЕНЬ 85 — МЫ В ХЭНЕ, ЧТО ДАЛЬШЕ? 😼",
				"href": "https://www.youtube.com/watch?v=Byi7IKIAV14",
				"poster": "https://i3.ytimg.com/vi/Byi7IKIAV14/hqdefault.jpg",
				"note": "85 день в Kenshi. Люси и Рука добрались до Хэна (Heng) — одного из крупнейших городов Объединённых Городов. Это главный торговый город…"
			},
			{
				"title": "ЛЮСИ В KENSHI: 66 ДЕНЬ — АРБАЛЕТЫ MK1, НОВАЯ КРАЛИЯ И БОСС В КЛЕТКУ 😼",
				"href": "https://www.youtube.com/watch?v=5TBmkJ9HBQ0",
				"poster": "https://i2.ytimg.com/vi/5TBmkJ9HBQ0/hqdefault.jpg",
				"note": "66 день в Kenshi. Люси и Рука съездили в Чёрную Пустыню, к Городу Фракции Скелетов — и выжили. Они раздобыли арбалеты Mk1, пережили…"
			},
			{
				"title": "ЛЮСИ В KENSHI: 76 ДЕНЬ — ТУМАННЫЕ ЗЕМЛИ И ПЕРВАЯ ВСТРЕЧА С ТУМАННИКАМИ 😼",
				"href": "https://www.youtube.com/watch?v=X_IOIMA7fok",
				"poster": "https://i1.ytimg.com/vi/X_IOIMA7fok/hqdefault.jpg",
				"note": "Люси и Рука продолжили свой путь и наткнулись на огромные Туманные земли. Это место, где вечный туман скрывает то, что происходит…"
			},
			{
				"title": "ЛЮСИ В KENSHI: ВСТРЕТИЛА РУКУ — ТЕПЕРЬ МЫ АРБАЛЕТЧИЦЫ 55 ДЕНЬ",
				"href": "https://www.youtube.com/watch?v=GlmpYufIurA",
				"poster": "https://i4.ytimg.com/vi/GlmpYufIurA/hqdefault.jpg",
				"note": "Люси наконец‑то решилась выйти в пустошь. Сила, атлетика и скрытность прокачаны до 80. Она взяла арбалет и отправилась в путь. И в одном…"
			},
			{
				"title": "ЛЮСИ В KENSHI: 49 ДНЕЙ ПРОКАЧКИ — ВЫХОЖУ ЗА ВОРОТА 😼",
				"href": "https://www.youtube.com/watch?v=rAavufay8bY",
				"poster": "https://i3.ytimg.com/vi/rAavufay8bY/hqdefault.jpg",
				"note": "Сорок дней. Сорок дней ползания на корточках с бандитом на плечах и деревянным ящиком за спиной. Сорок дней бессонных ночей, сухого мяса…"
			},
			{
				"title": "ЛЮСИ В KENSHI: ДЕНЬ 30 — ЖИЗНЬ СТРАННИКА В ПУСТОШИ 😼",
				"href": "https://www.youtube.com/watch?v=XzbmFgBiEbk",
				"poster": "https://i1.ytimg.com/vi/XzbmFgBiEbk/hqdefault.jpg",
				"note": "Люси в Kenshi. Четыре дня назад она оказалась здесь. Четыре дня выживания в пустоши, где всё пытается её убить, съесть или продать в…"
			}
		]
	}],
	"Сектор Неизвестный": [{
		"name": "YouTube · Сектор",
		"href": "https://www.youtube.com/playlist?list=PLtGnEHCh_VGnRb_kFOIhx987_T7XBYdeZ",
		"videos": [
			{
				"title": "SECTOR UNKNOWN: ОТ ВОДЫ К ОГНЮ — ЭРЕМТЕРА, ХЕЛФИР",
				"href": "https://www.youtube.com/watch?v=D-Q8v2PjbDo",
				"poster": "https://i1.ytimg.com/vi/D-Q8v2PjbDo/hqdefault.jpg",
				"note": "Мы решили проблему на водной планете Сьо (Sjo). Но медсёстры всё ещё застряли на орбите без топлива. Теперь, чтобы помочь им, нам нужно…"
			},
			{
				"title": "SECTOR UNKNOWN: ОТ ВОДЫ К ОГНЮ — ЭРЕМТЕРА, ХЕЛФИР (Финал)",
				"href": "https://www.youtube.com/watch?v=MYyvh-_xW2o",
				"poster": "https://i2.ytimg.com/vi/MYyvh-_xW2o/hqdefault.jpg",
				"note": "Мы решили проблему на водной планете Сьо (Sjo). Но медсёстры всё ещё застряли на орбите без топлива. Теперь, чтобы помочь им, нам нужно…"
			},
			{
				"title": "SECTOR UNKNOWN: ОТ ВОДЫ К ОГНЮ — ЭРЕМТЕРА, ХЕЛФИР",
				"href": "https://www.youtube.com/watch?v=hen-7Q_ypMA",
				"poster": "https://i1.ytimg.com/vi/hen-7Q_ypMA/hqdefault.jpg",
				"note": "Мы решили проблему на водной планете Сьо (Sjo). Но медсёстры всё ещё застряли на орбите без топлива. Теперь, чтобы помочь им, нам нужно…"
			},
			{
				"title": "ЛЮСИ В SECTOR UNKNOWN ПРОТИВ ОКЕАНА: НОВАЯ ПЛАНЕТА, НОВЫЕ ПРОБЛЕМЫ",
				"href": "https://www.youtube.com/watch?v=WX2uhZkorHY",
				"poster": "https://i4.ytimg.com/vi/WX2uhZkorHY/hqdefault.jpg",
				"note": "Мы нашли водную планету. TX930 утверждает, что здесь есть ценные ресурсы и древние технологии. Но планета встречает нас штормами,…"
			},
			{
				"title": "ЛЮСИ В SECTOR UNKNOWN: ПЛАНЕТА СЬО — ШТОРМ, БУХЛО И МОКРЫЕ УШИ 😼 #shorts #shortvideo #стрим",
				"href": "https://www.youtube.com/shorts/XOFv_HLuYmE",
				"poster": "https://i1.ytimg.com/vi/XOFv_HLuYmE/hqdefault.jpg",
				"note": "Мы прибыли на планету Сьо — океанический мир, где Star Frontier добывает загадочное химическое соединение. Но местные рабочие, кажется,…"
			},
			{
				"title": "ЛЮСИ В SECTOR UNKNOWN ПРОТИВ ОКЕАНА: НОВАЯ ПЛАНЕТА, НОВЫЕ ПРОБЛЕМЫ",
				"href": "https://www.youtube.com/watch?v=wQ6ELnft3uA",
				"poster": "https://i4.ytimg.com/vi/wQ6ELnft3uA/hqdefault.jpg",
				"note": "Мы нашли водную планету. TX930 утверждает, что здесь есть ценные ресурсы и древние технологии. Но планета встречает нас штормами,…"
			},
			{
				"title": "ЛЮСИ В SECTOR UNKNOWN: МЫ НАШЛИ КОРАБЛЬ! TX930 ВЕДЁТ НАС В НЕИЗВЕДАННОЕ 😼",
				"href": "https://www.youtube.com/watch?v=R_MV0VPwDXg",
				"poster": "https://i3.ytimg.com/vi/R_MV0VPwDXg/hqdefault.jpg",
				"note": "Мы отыскали транспортный корабль. Вместе с бывшим голодным соседом и старым роботом мы отремонтировали шахту, обустроили базу… и нашли…"
			},
			{
				"title": "ЛЮСИ В SECTOR UNKNOWN: МЫ НАШЛИ КОРАБЛЬ! TX930 ВЕДЁТ НАС В НЕИЗВЕДАННОЕ 😼",
				"href": "https://www.youtube.com/watch?v=8K6JGDWHTws",
				"poster": "https://i1.ytimg.com/vi/8K6JGDWHTws/hqdefault.jpg",
				"note": "Мы отыскали транспортный корабль. Вместе с бывшим голодным соседом и старым роботом мы отремонтировали шахту, обустроили базу… и нашли…"
			}
		]
	}, {
		"name": "Rutube · Сектор",
		"href": "https://rutube.ru/plst/1686502/",
		"videos": [{
			"title": "SECTOR UNKNOWN: МЕНЯ ХОТЕЛИ СЪЕСТЬ В ПЕРВЫЕ 10 СЕКУНД! НУ ДОБРО ПОЖАЛОВАТЬ! #shorts #SectorUnknown",
			"href": "https://rutube.ru/video/d14055235c406a3d7c04d50fff238327/",
			"poster": "https://pic.rtbcdn.ru/video/2026-06-20/5a/02/5a028ad60d6040125c70ba11259d76f1.jpg",
			"note": "ЛЮСИ В SECTOR UNKNOWN: ПРОБУЖДЕНИЕ В ТЮРЬМЕ И НЕОЖИДАННЫЙ ЗАВТРАК 😼 (ПЕРВЫЙ ЧАС) Люси снова в новой вселенной. На этот раз она…"
		}, {
			"title": "SECTOR UNKNOWN: КОРАБЛЬ НАЙДЕН, TX930 ГОВОРИТ \"ПОЕХАЛИ\". КУДА? НЕ ЗНАЕМ.",
			"href": "https://rutube.ru/video/dbfd96d346f964cc2a230db606ab4e4a/",
			"poster": "https://pic.rtbcdn.ru/video/2026-06-23/38/96/3896ff4b239e3c62959323980f889f5c.jpg",
			"note": "Мы отыскали транспортный корабль. Вместе с бывшим голодным соседом и старым роботом мы отремонтировали шахту, обустроили базу… и нашли…"
		}]
	}],
	NOLF: [{
		"name": "YouTube · NOLF",
		"href": "https://www.youtube.com/playlist?list=PLAJZKbt_9B4U",
		"videos": [
			{
				"title": "LUCY IN NOLF: ОТДЫХ И РАССЛАБЛЕНИЕ — КАК ЛЮСИ ОТДЫХАЕТ (СПОЙЛЕР: ВЗРЫВНО)",
				"href": "https://www.youtube.com/watch?v=VGt1ReGPupo",
				"poster": "https://i3.ytimg.com/vi/VGt1ReGPupo/hqdefault.jpg",
				"note": "«Отдых и расслабление» (Rest and Relaxation) — бонусная миссия из Game of the Year Edition, которая начинается после титров основной…"
			},
			{
				"title": "LUCY IN NOLF: НИЗКАЯ ОРБИТА ЗЕМЛИ — ПРОТИВОЯДИЕ, МЕТЕОРИТЫ И КОСМИЧЕСКИЙ ХАОС 😼",
				"href": "https://www.youtube.com/watch?v=xjGGanlc5yc",
				"poster": "https://i1.ytimg.com/vi/xjGGanlc5yc/hqdefault.jpg",
				"note": "Люси на борту секретной космической станции H.A.R.M. Она долетела на ракете после тропической миссии. Теперь её цель — найти противоядие…"
			},
			{
				"title": "LUCY IN NOLF: АЛЬПИЙСКАЯ ИНТРИГА — СЛЕЖКА, СНЕГОХОДЫ И ШАЛЕ БАРОНЕССЫ 😼",
				"href": "https://www.youtube.com/watch?v=7Rort8nGe4A",
				"poster": "https://i4.ytimg.com/vi/7Rort8nGe4A/hqdefault.jpg",
				"note": "Финал начинается здесь. Это двенадцатая миссия игры и первая часть «Альпийского квартета» — грандиозного финала, который приведёт Люси к…"
			},
			{
				"title": "LUCY IN NOLF: ПРОБЛЕМА В ТРОПИКАХ — ДЖУНГЛИ, РАКЕТА И ПРОТИВОЯДИЕ 😼",
				"href": "https://www.youtube.com/watch?v=oSMrbh7dM0g",
				"poster": "https://i4.ytimg.com/vi/oSMrbh7dM0g/hqdefault.jpg",
				"note": "Люси отправляется в тропики. После миссии с доктором Шенкером и взрыва города, она получает новое задание: H.A.R.M. хранит противоядие…"
			},
			{
				"title": "LUCY IN NOLF: ПОПЫТКА СПАСЕНИЯ — ЕСЛИ ВЫЖИВЁШЬ В ЭТОЙ МИССИИ, ТЫ ВСЁ СМОЖЕШЬ",
				"href": "https://www.youtube.com/watch?v=aOq44Sa3T-U",
				"poster": "https://i2.ytimg.com/vi/aOq44Sa3T-U/hqdefault.jpg",
				"note": "Доктор Шенкер в руках H.A.R.M. Люси должна спасти его. Миссия начинается с поезда в штате Вашингтон. Нужно найти инженера, который…"
			},
			{
				"title": "ЛЮСИ В NOLF: ЛАЗЕРНАЯ АКРОБАТИКА — ГИБКАЯ, КАК КОШКА 😼  #Shorts #shortvideo #games  #игра",
				"href": "https://www.youtube.com/shorts/xLB_uNBluCs",
				"poster": "https://i1.ytimg.com/vi/xLB_uNBluCs/hqdefault.jpg",
				"note": "Люси проходит лазерную ловушку. Не сквозь, а между. Гибкость, точность и лёгкий сарказм. Ставь лайк 👍, если тоже умеешь огибать лазеры!…"
			},
			{
				"title": "LUCY IN NOLF: ВЗЛОМЩИК — САМАЯ ДЛИННАЯ МИССИЯ, СЕЙФ И ПЕРВАЯ ВСТРЕЧА С ВОЛКОВЫМ 😼",
				"href": "https://www.youtube.com/watch?v=0Rl0Zsz4jPw",
				"poster": "https://i1.ytimg.com/vi/0Rl0Zsz4jPw/hqdefault.jpg",
				"note": "Начинается самое долгое приключение! Люси проникает в небоскрёб Дюмаса, чтобы взломать сейф и найти улики, связывающие барона с H.A.R.M.…"
			},
			{
				"title": "LUCY IN NOLF: ВЛИЯТЕЛЬНЫЙ ЧЕЛОВЕК — ПЕРВАЯ ВСТРЕЧА С БАРОНОМ",
				"href": "https://www.youtube.com/watch?v=srHdxetDjBs",
				"poster": "https://i4.ytimg.com/vi/srHdxetDjBs/hqdefault.jpg",
				"note": "Берлин, сентябрь, утро. Люси получает новое задание — проникнуть в небоскрёб Dumas Industrial, который ещё строится. Ей нужно найти…"
			}
		]
	}, {
		"name": "Rutube · NOLF",
		"href": "https://rutube.ru/plst/1717672/",
		"videos": [
			{
				"title": "LUCY IN NOLF: РАНДЕВУ В ГАМБУРГЕ — НОЧНОЙ КЛУБ, ПАРТНЁР И ЖЕНСКИЙ ТУАЛЕТ 😼 часть 2",
				"href": "https://rutube.ru/video/02a330c507bdfe895bbc281bee0d088b/",
				"poster": "https://pic.rtbcdn.ru/video/2026-07-14/cd/b7/cdb7d98fca75009c2de2e9efcc7c09fe.jpg",
				"note": "Гамбург, ночной клуб «Das Einsame Valkyrie». Люси должна встретить нового напарника — Тома Гудмана из американского отделения UNITY.…"
			},
			{
				"title": "LUCY IN NOLF: ВЛИЯТЕЛЬНЫЙ ЧЕЛОВЕК — ПЕРВАЯ ВСТРЕЧА С БАРОНОМ",
				"href": "https://rutube.ru/video/05b3608d10e70d7c3f8af73ff93587ce/",
				"poster": "https://pic.rtbcdn.ru/video/2026-07-14/1f/40/1f4002e57d043baf3a5a19041dc17cc1.jpg",
				"note": "Берлин, сентябрь, утро. Люси получает новое задание — проникнуть в небоскрёб Dumas Industrial, который ещё строится. Ей нужно найти…"
			},
			{
				"title": "ЛЮСИ В NOLF:МИССИЯ ВТОРАЯ - РЕКВИЕМ ДЛЯ ШПИОНА — ПРОНИКНОВЕНИЕ В ЛОГОВО 😼",
				"href": "https://rutube.ru/video/11f5d136223d3ee04eef54bf4e2eaea2/",
				"poster": "https://pic.rtbcdn.ru/video/2026-07-13/f4/4a/f44a8b3b4ff78bdb85a8017c0cdf6834.jpg",
				"note": "Марокко осталось позади. Бруно мёртв, посол убит, Волков ушёл. Теперь у Люси не просто задание — личный счёт. Следы ведут в таинственный…"
			},
			{
				"title": "LUCY IN NOLF: ПОГРУЖЕНИЕ — ЗАТОНУВШИЙ КОРАБЛЬ, АКУЛЫ И ПОДВОДНАЯ ОХОТА 😼",
				"href": "https://rutube.ru/video/1e7ab59e83c44fc5e00dfa4b03ed7003/",
				"poster": "https://pic.rtbcdn.ru/video/2026-07-14/29/d3/29d3b96bb72c4775bc65355d1763ce56.jpg",
				"note": "Том Гудман — напарник, который взрывает корабли без предупреждения. Люси возвращается в отель, чтобы проверить, не оставил ли он…"
			},
			{
				"title": "LUCY IN NOLF: НИЗКАЯ ОРБИТА ЗЕМЛИ — ПРОТИВОЯДИЕ, МЕТЕОРИТЫ И КОСМИЧЕСКИЙ ХАОС 😼",
				"href": "https://rutube.ru/video/3503c8d52addb7cde685325253d8e9f5/",
				"poster": "https://pic.rtbcdn.ru/video/2026-07-17/f5/53/f55348a478ebecf24f6a1d24b1b8c5f3.jpg",
				"note": "Люси на борту секретной космической станции H.A.R.M. Она долетела на ракете после тропической миссии. Теперь её цель — найти противоядие…"
			},
			{
				"title": "LUCY IN NOLF: РАНДЕВУ В ГАМБУРГЕ — НОЧНОЙ КЛУБ, ПАРТНЁР И ЖЕНСКИЙ ТУАЛЕТ 😼",
				"href": "https://rutube.ru/video/3726ba47552f73a9b82a63635f38b46e/",
				"poster": "https://pic.rtbcdn.ru/video/2026-07-13/20/96/20962b751402c18891f54cd3ecaef838.jpg",
				"note": "Гамбург, ночной клуб «Das Einsame Valkyrie». Люси должна встретить нового напарника — Тома Гудмана из американского отделения UNITY.…"
			},
			{
				"title": "LUCY IN NOLF: ПОПЫТКА СПАСЕНИЯ — ЕСЛИ ВЫЖИВЁШЬ В ЭТОЙ МИССИИ, ТЫ ВСЁ СМОЖЕШЬ",
				"href": "https://rutube.ru/video/49bf1f62b6944b1179a01638cce392f9/",
				"poster": "https://pic.rtbcdn.ru/video/2026-07-14/5b/13/5b1352df63eaeb863933d0d0e83bca0f.jpg",
				"note": "Доктор Шенкер в руках H.A.R.M. Люси должна спасти его. Миссия начинается с поезда в штате Вашингтон. Нужно найти инженера, который…"
			},
			{
				"title": "ЛЮСИ В NOLF: ПЕРВАЯ МИССИЯ — СНАЙПЕР, МАРОККО И ШПИОНСКИЙ ШИК 😼",
				"href": "https://rutube.ru/video/50ec95024b5cedc14c28a2cab788a0de/",
				"poster": "https://pic.rtbcdn.ru/video/2026-07-13/ce/45/ce45091fda50e233c4eff36ef26d6c74.jpg",
				"note": "Люси в 1960-х. Она не знает, как сюда попала. Она не знает, кто такой Бруно. Она не знает, почему у неё в руках снайперская винтовка и…"
			}
		]
	}],
	Азерот: [
		{
			"name": "YouTube · WoW Circle",
			"href": "https://www.youtube.com/playlist?list=PLtGnEHCh_VGkOnx0D5iGHQJ-UKO734xSP",
			"videos": [
				{
					"title": "(Финал) ЛЮСИ: ХАРДКОРНОЕ ПУТЕШЕСТВИЕ С 56 ПО 80 УРОВЕНЬ | World of Warcraft 3.3.5",
					"href": "https://www.youtube.com/watch?v=BPm-mmFV-D0",
					"poster": "https://i3.ytimg.com/vi/BPm-mmFV-D0/hqdefault.jpg",
					"note": "Друзья, зрители, случайные прохожие! Люси (жрица, любительница крышек, профессиональный истребитель кобольдов и по совместительству…"
				},
				{
					"title": "ЛЮСИ: ХАРДКОРНОЕ ПУТЕШЕСТВИЕ С 54 ПО 80 УРОВЕНЬ | World of Warcraft 3.3.5",
					"href": "https://www.youtube.com/watch?v=lzZIeK2bzsQ",
					"poster": "https://i1.ytimg.com/vi/lzZIeK2bzsQ/hqdefault.jpg",
					"note": "Друзья, зрители, случайные прохожие! Люси (жрица, любительница крышек, профессиональный истребитель кобольдов и по совместительству…"
				},
				{
					"title": "ЛЮСИ: ХАРДКОРНОЕ ПУТЕШЕСТВИЕ С 54 ПО 80 УРОВЕНЬ | World of Warcraft 3.3.5",
					"href": "https://www.youtube.com/watch?v=xC5Xigcki9M",
					"poster": "https://i1.ytimg.com/vi/xC5Xigcki9M/hqdefault.jpg",
					"note": "Друзья, зрители, случайные прохожие! Люси (жрица, любительница крышек, профессиональный истребитель кобольдов и по совместительству…"
				},
				{
					"title": "🧵 +5 К БРОНЕ: ТРУСЫ ОТ ЛЮСИ НА РЫНКЕ #WoW #Shorts  #worldofwarcraft #песняклип #штормград #рынок",
					"href": "https://www.youtube.com/shorts/OV_3B7HHBQ8",
					"poster": "https://i4.ytimg.com/vi/OV_3B7HHBQ8/hqdefault.jpg",
					"note": "Рынок Штормграда шумит, все торгуют эпиком и драконьей чешуёй... а у Люси особый товар — геройские трусы ручной работы! 🩲✨ Льняная…"
				},
				{
					"title": "ЛЮСИ: ХАРДКОРНОЕ ПУТЕШЕСТВИЕ С 54 ПО 80 УРОВЕНЬ | World of Warcraft 3.3.5",
					"href": "https://www.youtube.com/watch?v=5diREywhAOs",
					"poster": "https://i2.ytimg.com/vi/5diREywhAOs/hqdefault.jpg",
					"note": "Друзья, зрители, случайные прохожие! Люси (жрица, любительница крышек, профессиональный истребитель кобольдов и по совместительству…"
				},
				{
					"title": "ЛЮСИ: ХАРДКОРНОЕ ПУТЕШЕСТВИЕ С 51 ПО 80 УРОВЕНЬ | World of Warcraft 3.3.5",
					"href": "https://www.youtube.com/watch?v=RL6a9SFWzb8",
					"poster": "https://i3.ytimg.com/vi/RL6a9SFWzb8/hqdefault.jpg",
					"note": "Друзья, зрители, случайные прохожие! Люси (жрица, любительница крышек, профессиональный истребитель кобольдов и по совместительству…"
				},
				{
					"title": "ЛЮСИ: ХАРДКОРНОЕ ПУТЕШЕСТВИЕ С 52 ПО 80 УРОВЕНЬ | World of Warcraft 3.3.5",
					"href": "https://www.youtube.com/watch?v=dMoOHN4r10g",
					"poster": "https://i1.ytimg.com/vi/dMoOHN4r10g/hqdefault.jpg",
					"note": "Друзья, зрители, случайные прохожие! Люси (жрица, любительница крышек, профессиональный истребитель кобольдов и по совместительству…"
				},
				{
					"title": "ЛЮСИ: ХАРДКОРНОЕ ПУТЕШЕСТВИЕ С 53 ПО 80 УРОВЕНЬ | World of Warcraft 3.3.5",
					"href": "https://www.youtube.com/watch?v=cuSeNXJ-IT8",
					"poster": "https://i4.ytimg.com/vi/cuSeNXJ-IT8/hqdefault.jpg",
					"note": "Друзья, зрители, случайные прохожие! Люси (жрица, любительница крышек, профессиональный истребитель кобольдов и по совместительству…"
				}
			]
		},
		{
			"name": "YouTube · Sirus",
			"href": "https://www.youtube.com/playlist?list=PLtGnEHCh_VGkfoqbQCEyvSFRSW5mxkGhA",
			"videos": [
				{
					"title": "Люси в WOW SIRUS 3.3.5, Neverest, Hardcore, Книга 2 - Часть 2",
					"href": "https://www.youtube.com/watch?v=FA8P15JU6NE",
					"poster": "https://i3.ytimg.com/vi/FA8P15JU6NE/hqdefault.jpg",
					"note": "Пещера стенаний оказалась дальше, чем хотелось, и ближе, чем нужно. Дорога из Штормграда вела на юг, через пыль и редкие деревья,…"
				},
				{
					"title": "Люси в WOW SIRUS 3.3.5, Neverest, Hardcore, Книга 2 - Часть 1,5",
					"href": "https://www.youtube.com/watch?v=5pvzrm7AKhg",
					"poster": "https://i2.ytimg.com/vi/5pvzrm7AKhg/hqdefault.jpg",
					"note": "Штормград встретил нас стенами выше деревьев и шумом, от которого уши сразу заложило. Портал выплюнул нас прямо на каменную площадь у…"
				},
				{
					"title": "Люси в WOW SIRUS 3.3.5, Neverest, Hardcore, Глава 3",
					"href": "https://www.youtube.com/watch?v=7xQgZDLIUdo",
					"poster": "https://i4.ytimg.com/vi/7xQgZDLIUdo/hqdefault.jpg",
					"note": "Получено задание: «Технологии ушедших». Осмотрите устройство и принесите его Майт'алу Певцу Преданий. Награда на выбор: Шляпа…"
				},
				{
					"title": "Люси в WOW SIRUS 3.3.5, Neverest, Hardcore, Часть 2",
					"href": "https://www.youtube.com/watch?v=_hKJk28hbqE",
					"poster": "https://i4.ytimg.com/vi/_hKJk28hbqE/hqdefault.jpg",
					"note": "Илнурия даже не стала убирать дневник. Просто посмотрела на меня так, будто уже решила, куда меня отправить дальше. — Должна признать,…"
				},
				{
					"title": "Люси в WOW SIRUS 3.3.5, Neverest, Hardcore, Часть 1",
					"href": "https://www.youtube.com/watch?v=cNEoB6XN8CY",
					"poster": "https://i4.ytimg.com/vi/cNEoB6XN8CY/hqdefault.jpg",
					"note": "Я открыла глаза. Сначала было только небо — высокое, бледное, с редкими рваными облаками. Потом — запах. Сухая трава, пыль и что-то…"
				},
				{
					"title": "🌊 Проходим Непроглядную Пучину в режиме хардкор на сервере Sirus! 🌊",
					"href": "https://www.youtube.com/watch?v=_KHuPiyTpcY",
					"poster": "https://i4.ytimg.com/vi/_KHuPiyTpcY/hqdefault.jpg",
					"note": "Добро пожаловать в очередное эпическое приключение! В этом видео мы погружаемся в тёмные воды Непроглядной Пучины — одного из самых…"
				},
				{
					"title": "Проходим Пещеру стенаний на хардкоре на сервере Sirus! | Ghostpot",
					"href": "https://www.youtube.com/watch?v=AwmUGwwpRX0",
					"poster": "https://i2.ytimg.com/vi/AwmUGwwpRX0/hqdefault.jpg",
					"note": "Привет, друзья! 🖐️ Это мой первый опыт стриминга, и я решил делиться своими похождениями! Стримлю для души, а теперь выкладываю видео на…"
				},
				{
					"title": "Огненная пропасть в хардкоре на Sirus — первое испытание! 🔥",
					"href": "https://www.youtube.com/watch?v=lljQL2zsaJM",
					"poster": "https://i1.ytimg.com/vi/lljQL2zsaJM/hqdefault.jpg",
					"note": "🔥 Проходим Огненную пропасть в режиме хардкор на сервере Sirus! 🔥 В этом видео вы увидите наше прохождение культового данжа Огненная…"
				}
			]
		},
		{
			"name": "Rutube · книга 1",
			"href": "https://rutube.ru/plst/759743/",
			"videos": [
				{
					"title": "World of Warcraft  Sirus - Нагие Откровения, Пролог, Прогулка.",
					"href": "https://rutube.ru/video/2702ad2287b2b46beee45851af7bf325/",
					"poster": "https://pic.rtbcdn.ru/video/2025-04-28/aa/00/aa00fff38876667c8575d920631c72ff.jpg",
					"note": ""
				},
				{
					"title": "Книга: Нагие Откровения Глава 1 - Стрим 1 - Начало.",
					"href": "https://rutube.ru/video/2a8fed8040a1231c3fe3dffb97ac0dc7/",
					"poster": "https://pic.rtbcdn.ru/video/2025-04-17/fd/9b/fd9b196fe318cd0c730f97f7226218ec.jpg",
					"note": "Глубины океана хранят множество тайн, но даже среди них судьба СвятогоНиколы выделяется особенно. Боевой жрец, фанатичный последователь…"
				},
				{
					"title": "Книга: Нагие Откровения Глава 1 - Стрим 2 - Изучаем мир Наг",
					"href": "https://rutube.ru/video/e77f87be71ac66cb99646563836487e7/",
					"poster": "https://pic.rtbcdn.ru/video/2025-04-18/bf/0b/bf0bcee5a811c264f62b4434c375d3a2.jpg",
					"note": "Глубины океана хранят множество тайн, но даже среди них судьба СвятогоНиколы выделяется особенно. Боевой жрец, фанатичный последователь…"
				}
			]
		},
		{
			"name": "Rutube · Калимдор",
			"href": "https://rutube.ru/plst/1133719/",
			"videos": [
				{
					"title": "Книга 2 - Нагие откровения: Глава : Пустоши 2",
					"href": "https://rutube.ru/video/0c3f2945f0d890fc0bcf888ab453fbf6/",
					"poster": "https://pic.rtbcdn.ru/video/2025-05-08/0a/1e/0a1e9ac615c5eb45bfb3cd5408385b38.jpg",
					"note": ""
				},
				{
					"title": "WOW Книга 2 - Нагие откровения: Глава: Глубины \\ Пик Черной горы",
					"href": "https://rutube.ru/video/1040ef91fc1447a0ffdb2508510baa59/",
					"poster": "https://pic.rtbcdn.ru/video/2025-05-24/ab/1e/ab1e33ec8d18c949ecc2a0a6c569bdfe.jpg",
					"note": ""
				},
				{
					"title": "WOW Книга 2 - Нагие откровения: Глава: Собираем зубы",
					"href": "https://rutube.ru/video/15352331202af2b2017fd341f2dc621e/",
					"poster": "https://pic.rtbcdn.ru/video/2025-05-26/7c/e2/7ce2a9891ea46c838f1ca3ab075268e3.jpg",
					"note": ""
				},
				{
					"title": "Книга 2 - Нагие откровения: Глава: Квесты перед Ульдаманом",
					"href": "https://rutube.ru/video/157e8a85a882e4189bf7a5e9fd7b473d/",
					"poster": "https://pic.rtbcdn.ru/video/2025-05-14/e6/18/e618586db7d3f2052d1f87943725bec5.jpg",
					"note": ""
				},
				{
					"title": "WOW Книга 2 - Нагие откровения: Глава: Собираем зубы",
					"href": "https://rutube.ru/video/3929b906d7503f271b5185de97a7a488/",
					"poster": "https://pic.rtbcdn.ru/video/2025-05-26/1d/29/1d294938d3496c68f83e5ab332cac81c.jpg",
					"note": ""
				},
				{
					"title": "Книга 2 - Нагие откровения: Глава: Танарис",
					"href": "https://rutube.ru/video/3d1f7c6acb89aab90addd58aad9d481f/",
					"poster": "https://pic.rtbcdn.ru/video/2025-05-16/66/a8/66a8c2ff619776c747386d47b3fd7e91.jpg",
					"note": ""
				},
				{
					"title": "Книга 2 - Нагие откровения: Глава : Гномреган",
					"href": "https://rutube.ru/video/3dc05e978743feb4019ae0c86adda942/",
					"poster": "https://pic.rtbcdn.ru/video/2025-05-05/78/19/78198ee4be563475c142d12ccf0a0c82.jpg",
					"note": "Гномреган - это город гномов, расположенный в западной части Дун Морога. Подземелье отличается наличием безопасной зоны внутри, где…"
				},
				{
					"title": "Книга 2 - Нагие откровения: Глава: Зульфарак",
					"href": "https://rutube.ru/video/47ed9563b869d295ac4989f55ed38844/",
					"poster": "https://pic.rtbcdn.ru/video/2025-05-17/4d/f8/4df8bd944e0429e88eda45a378b04e38.jpg",
					"note": ""
				}
			]
		}
	],
	"PROJECT ZOMBOID": [{
		"name": "YouTube · PROJECT ZOMBOID",
		"href": "https://www.youtube.com/playlist?list=PLHGl0TzDzHTs",
		"videos": [
			{
				"title": "Люси в Project Zomboid  - The Great Spiffo's Rat Race + A-live  Глава 8",
				"href": "https://www.youtube.com/watch?v=0AuFqTXI1rQ",
				"poster": "https://i1.ytimg.com/vi/0AuFqTXI1rQ/hqdefault.jpg",
				"note": "Палатки стояли так, будто люди ушли на минуту и не вернулись. Люси обошла их по кругу. Копьё в левой. Правая ещё болела под повязкой.…"
			},
			{
				"title": "Люси в Project Zomboid  - The Great Spiffo's Rat Race + A-live  Часть 7",
				"href": "https://www.youtube.com/watch?v=HTUx7XS4xPA",
				"poster": "https://i1.ytimg.com/vi/HTUx7XS4xPA/hqdefault.jpg",
				"note": "Глава 7. Правая рука Один притворился мёртвым. Люси уже не считала, сколько их было. Сотни. Опять. Она укладывала их копьём, пока рука…"
			},
			{
				"title": "Люси в Project Zomboid  - The Great Spiffo's Rat Race + A-live  Часть 6",
				"href": "https://www.youtube.com/watch?v=6_aTIZ0ArPQ",
				"poster": "https://i3.ytimg.com/vi/6_aTIZ0ArPQ/hqdefault.jpg",
				"note": "Пять месяцев и двадцать восемь дней. Люси стояла у двери и проверяла, что взяла. Копьё. Нож. Топор оставила. Для забора он нужнее.…"
			},
			{
				"title": "Люси в Project Zomboid  - The Great Spiffo's Rat Race + A-live  Часть 5",
				"href": "https://www.youtube.com/watch?v=P4-Q9ltBwpg",
				"poster": "https://i1.ytimg.com/vi/P4-Q9ltBwpg/hqdefault.jpg",
				"note": "Пять месяцев и двадцать три дня. Люси стояла у последнего пролёта и смотрела на забор. Почти замкнулся. Деревянный. Высокий. Вокруг дома…"
			},
			{
				"title": "Люси в Project Zomboid  - The Great Spiffo's Rat Race + A-live",
				"href": "https://www.youtube.com/watch?v=eSXzGdM3V28",
				"poster": "https://i2.ytimg.com/vi/eSXzGdM3V28/hqdefault.jpg",
				"note": ""
			},
			{
				"title": "Люси в Project Zomboid  - The Great Spiffo's Rat Race + A-live Часть 7",
				"href": "https://www.youtube.com/watch?v=TLkC_R7xVGI",
				"poster": "https://i1.ytimg.com/vi/TLkC_R7xVGI/hqdefault.jpg",
				"note": "Люси вышла к кемпингу на пятый день зимы. Дорога через лес была короче, чем вдоль реки. Она это знала. Знала и то, что короче не значит…"
			},
			{
				"title": "Люси в Project Zomboid  - The Great Spiffo's Rat Race + A-live Часть 6",
				"href": "https://www.youtube.com/watch?v=2EQqGE612Ao",
				"poster": "https://i3.ytimg.com/vi/2EQqGE612Ao/hqdefault.jpg",
				"note": "Люси вышла к кемпингу на пятый день зимы. Дорога через лес была короче, чем вдоль реки. Она это знала. Знала и то, что короче не значит…"
			},
			{
				"title": "Люси в Project Zomboid  - The Great Spiffo's Rat Race + A-live Часть 5,1. Дом лесника",
				"href": "https://www.youtube.com/watch?v=kzeoKASJEBE",
				"poster": "https://i4.ytimg.com/vi/kzeoKASJEBE/hqdefault.jpg",
				"note": "Четыре месяца и три дня. Снег лёг ночью. Не много. Достаточно, чтобы крыша побелела, а земля под ногами стала твёрже. Люси вышла из дома…"
			}
		]
	}]
};
var chapters = chapters_default;
var videos = videos_default;
function loadChapters() {
	return Promise.resolve(chapters);
}
function loadVideos() {
	return Promise.resolve(videos);
}
function platesOf(chapters) {
	const seen = /* @__PURE__ */ new Set();
	const list = [];
	for (const chapter of chapters) for (const plate of chapter.plates ?? []) {
		if (seen.has(plate.src)) continue;
		seen.add(plate.src);
		list.push({
			src: plate.src,
			alt: plate.alt
		});
	}
	return list;
}
var COPY = {
	screen: {
		kicker: "Экран",
		text: "Кадр — дверь в мир. Жми его. Точки внизу листают сеанс."
	},
	popcorn: {
		kicker: "Попкорн",
		text: "Это не еда. Попкорн здесь — донат на сеанс."
	},
	shards: {
		kicker: "Осколок",
		text: "Вещь из мира. Жми — откроется дом, откуда она её унесла."
	},
	pin: {
		kicker: "Значок",
		text: "В углу карточки осколок мира. Сама карточка открывает дом."
	},
	whisper: {
		kicker: "Люси",
		text: "Лицо в углу — она. Жми, если нужна короткая реплика."
	},
	"mode-book": {
		kicker: "Книга",
		text: "Музыка и глава — разные кнопки. Жми «Книга», если хочешь слушать, как она читает."
	},
	"tome-song": {
		kicker: "Песня тома",
		text: "Это музыка тома, не голос главы. Голос включается кнопкой «Книга» в плеере."
	},
	karaoke: {
		kicker: "Караоке",
		text: "Буквы загораются за её голосом. Жми, если хочешь следить. Выключается так же."
	},
	papers: {
		kicker: "Бумага",
		text: "Ночь, сепия, бумага, день — только цвет страницы. Глава та же."
	},
	size: {
		kicker: "Буквы",
		text: "А, Аа, Ааа — крупнее текст. Смысл не меняется."
	},
	host: {
		kicker: "Площадки",
		text: "Те же записи на разных полках. Если одна молчит, жми другую."
	},
	search: {
		kicker: "Поиск",
		text: "Ищет запись на выбранной площадке. Площадка — кнопки выше."
	},
	filters: {
		kicker: "Полки",
		text: "Миры, лица, шапка, книга — полки одной галереи, не разные сайты."
	},
	hat: {
		kicker: "Шапка",
		text: "Жми фото — следующее. Цифры под ним листают то же."
	},
	speech: {
		kicker: "Речь",
		text: "Сначала распакуй архив. Из самого zip программа не стартует."
	},
	pick: {
		kicker: "Список",
		text: "Длинная кнопка открывает альбом или главу. Это не «играть»."
	},
	collapse: {
		kicker: "Плеер",
		text: "Сел на текст. Стрелка вниз прячет его. Вернётся маленькой закладкой."
	}
};
var ORDER = [
	"screen",
	"popcorn",
	"shards",
	"pin",
	"whisper",
	"mode-book",
	"tome-song",
	"karaoke",
	"papers",
	"size",
	"host",
	"search",
	"filters",
	"hat",
	"speech",
	"pick",
	"collapse"
];
var VIEWS = {
	screen: ["home"],
	popcorn: ["home"],
	shards: ["home", "worlds"],
	pin: ["worlds"],
	whisper: ["home", "lucy"],
	"mode-book": ["book", "read"],
	"tome-song": ["book"],
	karaoke: ["read"],
	papers: ["read"],
	size: ["read"],
	host: ["world", "streams"],
	search: ["streams"],
	filters: ["gallery"],
	hat: ["shop"],
	speech: ["programs"],
	pick: ["music"]
};
var STORE = "ghostpot-led";
function readDone() {
	try {
		const raw = JSON.parse(localStorage.getItem(STORE) || "{}");
		return raw && typeof raw === "object" ? raw : {};
	} catch {
		return {};
	}
}
function writeDone(id) {
	const next = {
		...readDone(),
		[id]: true
	};
	localStorage.setItem(STORE, JSON.stringify(next));
	return next;
}
function targetOf(id) {
	return document.querySelector(`[data-led="${id}"]`);
}
function eligible(viewName, scrolled, done) {
	for (const id of ORDER) {
		if (done[id]) continue;
		const views = VIEWS[id];
		if (views && !views.includes(viewName)) continue;
		if (id === "collapse" && !scrolled) continue;
		const node = targetOf(id);
		if (!node) continue;
		if (id === "mode-book" && node.getAttribute("data-on") === "true") continue;
		if (id === "karaoke" && (node.getAttribute("aria-pressed") === "true" || node.getAttribute("data-on") === "true")) continue;
		return id;
	}
	return null;
}
function layout(rect) {
	const plateW = 248;
	const plateH = 136;
	const arrow = 46;
	const pad = 10;
	const vw = window.innerWidth;
	const vh = window.innerHeight;
	const clamp = (value, max) => Math.min(Math.max(value, pad), Math.max(pad, max));
	const center = rect.left + rect.width / 2 - plateW / 2;
	if (rect.top > 192) return {
		dir: "down",
		left: clamp(center, vw - plateW - pad),
		top: rect.top - plateH - arrow - 6
	};
	if (vh - rect.bottom > 192) return {
		dir: "up",
		left: clamp(center, vw - plateW - pad),
		top: rect.bottom + 8
	};
	if (rect.left > 304) return {
		dir: "right",
		left: rect.left - plateW - arrow - 6,
		top: clamp(rect.top + rect.height / 2 - plateH / 2, vh - plateH - pad)
	};
	return {
		dir: "left",
		left: rect.right + 8,
		top: clamp(rect.top + rect.height / 2 - plateH / 2, vh - plateH - pad)
	};
}
function LedHints({ viewName }) {
	const [done, setDone] = (0, import_react.useState)({});
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)(null);
	const activeRef = (0, import_react.useRef)(null);
	activeRef.current = active;
	const [box, setBox] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setDone(readDone());
	}, []);
	(0, import_react.useEffect)(() => {
		setScrolled(false);
	}, [viewName]);
	(0, import_react.useEffect)(() => {
		const onScroll = () => {
			if (window.scrollY > 160) setScrolled(true);
		};
		window.addEventListener("scroll", onScroll, { passive: true });
		onScroll();
		return () => window.removeEventListener("scroll", onScroll);
	}, [viewName]);
	(0, import_react.useEffect)(() => {
		let timer = 0;
		const finishIfUsed = () => {
			const current = readDone();
			["mode-book", "karaoke"].forEach((id) => {
				if (current[id]) return;
				const node = targetOf(id);
				if (!node) return;
				if (id === "karaoke" ? node.getAttribute("aria-pressed") === "true" || node.getAttribute("data-on") === "true" : node.getAttribute("data-on") === "true") current[id] = true;
			});
			if (JSON.stringify(current) !== JSON.stringify(readDone())) {
				localStorage.setItem(STORE, JSON.stringify(current));
				setDone({ ...current });
			}
		};
		const tick = () => {
			finishIfUsed();
			const next = eligible(viewName, scrolled, readDone());
			setActive((prev) => prev === next ? prev : next);
		};
		const onChange = (event) => {
			const id = (event.target instanceof Element ? event.target.closest("[data-led]") : null)?.getAttribute("data-led");
			if (id && id === activeRef.current && id in COPY) setDone(writeDone(id));
			tick();
			window.setTimeout(tick, 90);
		};
		timer = window.setTimeout(tick, 700);
		let wait = 0;
		const later = () => {
			window.clearTimeout(wait);
			wait = window.setTimeout(tick, 180);
		};
		const seen = new MutationObserver(later);
		seen.observe(document.body, {
			childList: true,
			subtree: true,
			attributes: true,
			attributeFilter: ["data-on", "aria-pressed"]
		});
		window.addEventListener("click", onChange);
		window.addEventListener("resize", onChange);
		return () => {
			window.clearTimeout(timer);
			window.clearTimeout(wait);
			seen.disconnect();
			window.removeEventListener("click", onChange);
			window.removeEventListener("resize", onChange);
		};
	}, [
		viewName,
		scrolled,
		done
	]);
	(0, import_react.useEffect)(() => {
		if (!active) {
			setBox(null);
			document.querySelectorAll("[data-led-hot]").forEach((node) => node.removeAttribute("data-led-hot"));
			return;
		}
		const place = () => {
			const node = targetOf(active);
			if (!node) {
				setBox(null);
				return;
			}
			node.setAttribute("data-led-hot", "1");
			document.querySelectorAll("[data-led-hot]").forEach((other) => {
				if (other !== node) other.removeAttribute("data-led-hot");
			});
			setBox(layout(node.getBoundingClientRect()));
		};
		place();
		window.addEventListener("scroll", place, { passive: true });
		window.addEventListener("resize", place);
		return () => {
			window.removeEventListener("scroll", place);
			window.removeEventListener("resize", place);
		};
	}, [active]);
	if (!active || !box) return null;
	const copy = COPY[active];
	const dismiss = () => setDone(writeDone(active));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "led-hint",
		"data-dir": box.dir,
		style: {
			left: box.left,
			top: box.top
		},
		role: "note",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "led-plate",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["Люси · ", copy.kicker] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: copy.text }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "led-x",
					"aria-label": "Скрыть подсказку",
					onClick: dismiss,
					children: "×"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "led-arrow",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { ["--i"]: 0 } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { ["--i"]: 1 } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { ["--i"]: 2 } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { ["--i"]: 3 } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { ["--i"]: 4 } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "led-chev" })
			]
		})]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getAir = createServerFn({ method: "GET" }).handler(createSsrRpc("ab605dd5c07433d3107966c80e996b46b6d9a0b5baae14cb8bb9d9c9a3369185"));
function when(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "";
	const now = /* @__PURE__ */ new Date();
	const clock = date.toLocaleTimeString("ru-RU", {
		hour: "2-digit",
		minute: "2-digit"
	});
	const day = new Date(now);
	day.setHours(0, 0, 0, 0);
	const that = new Date(date);
	that.setHours(0, 0, 0, 0);
	const diff = Math.round((day.getTime() - that.getTime()) / 864e5);
	if (diff === 0) return `сегодня · ${clock}`;
	if (diff === 1) return `вчера · ${clock}`;
	return `${date.toLocaleDateString("ru-RU", {
		day: "numeric",
		month: "short"
	})} · ${clock}`;
}
function AirFeed() {
	const [items, setItems] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		getAir().then((data) => {
			if (live) setItems(data);
		}).catch(() => {
			if (live) setItems([]);
		});
		return () => {
			live = false;
		};
	}, []);
	if (items === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "meta",
		children: "Смотрю свежие эфиры."
	});
	const cutoff = Date.now() - 2592e5;
	const recent = items.filter((item) => new Date(item.at).getTime() >= cutoff);
	const shown = (recent.length ? recent : items).slice(0, 6);
	if (!shown.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "air-row",
		children: nights.slice(0, 6).map((night) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "air-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: night.where }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "meta",
				children: night.when
			})]
		}, night.when))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "air-row",
		children: shown.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			className: "air-card",
			href: item.href,
			target: "_blank",
			rel: "noreferrer",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: item.thumb,
					alt: ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "meta",
					children: when(item.at)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: item.title })
			]
		}, item.id))
	});
}
var getLive = createServerFn({ method: "GET" }).handler(createSsrRpc("c4e1288f5a7df1bccf074f594b7d493a39d9dfd2850659cb73d37090b1ec91df"));
function LiveBadge() {
	const world = worlds.find((item) => item.mark === "Сейчас")?.name ?? "PROJECT ZOMBOID";
	const [report, setReport] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		const load = () => {
			if (document.hidden) return;
			getLive().then((data) => {
				if (live) setReport(data);
			}).catch(() => {
				if (live) setReport({ hits: [] });
			});
		};
		load();
		const timer = window.setInterval(load, 9e5);
		const onShow = () => {
			if (!document.hidden) load();
		};
		document.addEventListener("visibilitychange", onShow);
		return () => {
			live = false;
			window.clearInterval(timer);
			document.removeEventListener("visibilitychange", onShow);
		};
	}, []);
	const hits = report?.hits ?? [];
	const hit = hits[0];
	if (hit) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		className: "live is-on",
		href: hit.href,
		title: hit.title,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Сейчас в эфире · ", hits.map((item) => item.platform).join(", ")] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: hit.game || hit.title })] })]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		className: "live is-off",
		type: "button",
		onClick: () => {
			window.location.hash = `#world=${encodeURIComponent(world)}`;
			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: report ? "Эфир не идёт" : "Проверяю площадки" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["В мире: ", world] })] })]
	});
}
var shards = [
	{
		id: "gothic",
		world: "Готика",
		artifact: "Кусок руды",
		line: "Шесть часов с отмычкой. Замок не открылся. В карман положили это."
	},
	{
		id: "calradia",
		world: "Кальрадия",
		artifact: "Заклёпка щита",
		line: "Щит был шире стены. Заклёпка осталась, когда щит уже не держал."
	},
	{
		id: "pathfinder",
		world: "Pathfinder",
		artifact: "Угол карты",
		line: "Корону не просила. Унесла обгоревший угол карты, которой пишет летопись."
	},
	{
		id: "poe",
		world: "Path of Exile",
		artifact: "Щепка посоха",
		line: "Один день дворянкой. Пальцы до сих пор помнят посох лучше, чем то имя."
	},
	{
		id: "tomb",
		world: "Tomb Raider",
		artifact: "Ледяной наконечник",
		line: "Из долины, где был один путь наверх. Стрелу выпустила. Наконечник оставила."
	},
	{
		id: "fallout",
		world: "Fallout",
		artifact: "Крышка с пустоши",
		line: "Жестяная, без бренда. Значки на этом сайте она принесла отсюда: пустошный штамп, а в нём её уши."
	},
	{
		id: "kenshi",
		world: "Кенши",
		artifact: "Кольцо кандалов",
		line: "Железо сняла. Кольцо не выбросила: чтобы помнить, что город ещё надо построить."
	},
	{
		id: "pandora",
		world: "Пандора",
		artifact: "Тёплая гильза",
		line: "Жёлтая пыль в резьбе. Обещаниям на ящиках она не верит, гильзе верит."
	},
	{
		id: "quake",
		world: "Quake",
		artifact: "Кусок обшивки",
		line: "Металл ещё тёплый. Шутка там не спасала. До двери она дошла молча."
	},
	{
		id: "sector",
		world: "Сектор Неизвестный",
		artifact: "Черепок со звездой",
		line: "Звезду она рисовала на стенах станции. Один черепок забрала с собой."
	},
	{
		id: "nolf",
		world: "NOLF",
		artifact: "Ключ от двери",
		line: "Мартини не пила. Ушла с ключом. Платье помялось, миссия нет."
	},
	{
		id: "azeroth",
		world: "Азерот",
		artifact: "Катушка ниток",
		line: "Жрица, которая шьёт. Нитки из Штормграда. Танка так и не нашла."
	},
	{
		id: "zomboid",
		world: "PROJECT ZOMBOID",
		artifact: "Уголь из костра",
		line: "Завёрнут в тряпку. Хрупкий огонь. Пока тлеет, ночь ещё не съела её."
	}
];
function shardByWorld(world) {
	return shards.find((item) => item.world === world) ?? null;
}
function ShardMark({ id, size = 42 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		className: "shard-mark",
		src: `/brand/shards/${id}.webp`,
		width: size,
		height: size,
		alt: ""
	});
}
function ShardPin({ world }) {
	const shard = shardByWorld(world);
	if (!shard) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "shard-pin",
		"data-led": "pin",
		title: shard.artifact,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShardMark, {
			id: shard.id,
			size: 28
		})
	});
}
function Plate({ shard }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "shard-plate",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShardMark, {
			id: shard.id,
			size: 64
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "meta",
				children: ["Осколок памяти · ", shard.world]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: shard.artifact }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: shard.line })
		] })]
	});
}
function ShardPlate({ world }) {
	const shard = shardByWorld(world);
	if (!shard) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plate, { shard });
}
function ShardVault({ onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "section between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Межселенная"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Осколки памяти" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sub",
				children: "Из каждого Мира она унесла одну вещь."
			})
		] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shard-grid",
			"data-led": "shards",
			children: shards.map((shard) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "shard",
				type: "button",
				onClick: () => onOpen(shard.world),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShardMark, { id: shard.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: shard.artifact }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: shard.world })] })]
			}, shard.id))
		})]
	});
}
var NAV = [
	{
		id: "home",
		label: "Главная"
	},
	{
		id: "worlds",
		label: "Миры"
	},
	{
		id: "book",
		label: "Книга"
	},
	{
		id: "music",
		label: "Музыка"
	},
	{
		id: "gallery",
		label: "Галерея"
	},
	{
		id: "shop",
		label: "Шапка"
	},
	{
		id: "lucy",
		label: "Люси"
	},
	{
		id: "streams",
		label: "Эфиры"
	},
	{
		id: "programs",
		label: "Программы"
	},
	{
		id: "about",
		label: "Обо мне"
	}
];
function parseHash() {
	const raw = decodeURIComponent(window.location.hash.replace(/^#/, ""));
	if (!raw || raw === "home") return { name: "home" };
	if (raw.startsWith("world=")) return {
		name: "world",
		id: raw.slice(6)
	};
	if (raw.startsWith("read=")) return {
		name: "read",
		id: raw.slice(5)
	};
	const known = NAV.map((item) => item.id);
	if (raw === "law" || known.includes(raw)) return { name: raw };
	return { name: "home" };
}
function hrefFor(view) {
	if (view.name === "world") return `#world=${encodeURIComponent(view.id)}`;
	if (view.name === "read") return `#read=${encodeURIComponent(view.id)}`;
	if (view.name === "home") return "#home";
	return `#${view.name}`;
}
function readPlace() {
	try {
		const raw = localStorage.getItem("ghostpot-place");
		if (!raw) return null;
		const place = JSON.parse(raw);
		if (!place.id) return null;
		return {
			id: place.id,
			y: place.y ?? 0
		};
	} catch {
		return null;
	}
}
function savePlace(id, y) {
	localStorage.setItem("ghostpot-place", JSON.stringify({
		id,
		y
	}));
}
function Here() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
		className: "here",
		size: 14,
		"aria-label": "Здесь ты остановился"
	});
}
var leaveSite = null;
function openSite(hash) {
	const clean = hash.replace(/^#/, "");
	if (window.location.pathname !== "/" && leaveSite) {
		leaveSite(clean);
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
		return;
	}
	if (window.location.pathname !== "/") {
		window.location.assign(`/#${clean}`);
		return;
	}
	window.location.hash = `#${clean}`;
	window.scrollTo({
		top: 0,
		behavior: "smooth"
	});
}
function go(view) {
	openSite(hrefFor(view).replace(/^#/, ""));
}
function Shell({ view, guides = false, children }) {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		leaveSite = (hash) => {
			router.navigate({
				to: "/",
				hash
			});
		};
		return () => {
			leaveSite = null;
		};
	}, [router]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedHints, { viewName: view.name }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "embers",
				"aria-hidden": "true",
				children: Array.from({ length: 14 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ember",
					style: {
						left: `${index * 7.3 % 100}%`,
						animationDuration: `${11 + index % 6 * 2.2}s`,
						animationDelay: `${index * .7}s`,
						opacity: .25 + index % 4 * .1
					}
				}, index))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "topbar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "brand",
					type: "button",
					onClick: () => go({ name: "home" }),
					"aria-label": "Ghostpot, на главную",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/brand/ghostpot-word.webp",
						alt: "Ghostpot",
						width: "1280",
						height: "401"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "nav",
					"aria-label": "Разделы сайта",
					children: [NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"data-on": view.name === item.id || item.id === "worlds" && view.name === "world" || item.id === "book" && view.name === "read",
						onClick: () => go({ name: item.id }),
						children: item.label
					}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/guides",
						"data-on": guides ? "true" : void 0,
						children: "Гайды"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "stage",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "view",
					children
				}, view.name === "read" ? `read-${"id" in view ? view.id : ""}` : view.name === "world" ? view.id : view.name)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "foot",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "foot-brand",
						type: "button",
						onClick: () => go({ name: "home" }),
						"aria-label": "Ghostpot, на главную",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/brand/ghostpot-word.webp",
							alt: "Ghostpot",
							width: "1280",
							height: "401"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "18+ · игровые эфиры. Ghostpot · хостинг в Российской Федерации." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => go({ name: "law" }),
							children: "Политика, соглашение, cookie"
						}),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/guides",
							children: "Гайды"
						}),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: links.mail,
							children: links.email
						}),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: links.telegram,
							children: "Telegram"
						}),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: links.max,
							children: "MAX"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Персональные данные россиян на сайт не собираются. Место в книге и громкость остаются в браузере." })
				]
			})
		]
	});
}
function WorldCard({ world, featured = false }) {
	const songs = world.tracks.filter((track) => track.src).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		className: `world-card ${featured ? "feature" : ""}`,
		type: "button",
		onClick: () => go({
			name: "world",
			id: world.name
		}),
		onPointerEnter: () => void loadVideos(),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-media",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
					src: world.cover,
					alt: ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "badge",
					"data-hot": markHot(world.mark),
					children: world.mark
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShardPin, { world: world.name })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-body",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "album",
					children: world.album
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: world.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: featured ? "" : "clamp",
					children: world.game
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "clamp",
					children: world.lived
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "meta",
					children: [
						songs ? `${songs} ${songs === 1 ? "песня" : songs < 5 ? "песни" : "песен"}` : "песни ещё в пути",
						" · ",
						videoCount(world.name),
						" записей"
					]
				})
			]
		})]
	});
}
var ARRIVALS = [
	"В зал вошли двое и сели ближе к проходу.",
	"Кто-то встал и вышел за попкорном.",
	"В третьем ряду освободилось место.",
	"Ещё один зритель сел на этот сеанс.",
	"Из фойе вернулись. Свет уже гаснет."
];
var SLIDES = [
	{
		src: "/brand/slides/gothic.webp",
		world: "Готика",
		line: "Колония под куполом. Она только очнулась."
	},
	{
		src: "/brand/slides/calradia.webp",
		world: "Кальрадия",
		line: "Степь, щит и чужие знамёна."
	},
	{
		src: "/brand/slides/azeroth.webp",
		world: "Азерот",
		line: "Жрица. Эльфийские уши только здесь."
	},
	{
		src: "/brand/slides/zomboid.webp",
		world: "PROJECT ZOMBOID",
		line: "Ночь без сейва. Копьё у костра."
	},
	{
		src: "/brand/slides/kenshi.webp",
		world: "Кенши",
		line: "Кандалы сняты. За барханом — дом."
	},
	{
		src: "/brand/slides/fallout.webp",
		world: "Fallout",
		line: "Одна пустошь. Пустая миска."
	}
];
function HomeView() {
	const play = usePlayer((s) => s.play);
	const featured = worlds.filter((world) => world.live);
	const rest = worlds.filter((world) => !world.live);
	const [beat, setBeat] = (0, import_react.useState)(0);
	const [slide, setSlide] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setBeat((value) => (value + 1) % ARRIVALS.length), 4600);
		return () => window.clearInterval(timer);
	}, []);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setSlide((value) => (value + 1) % SLIDES.length), 6500);
		return () => window.clearInterval(timer);
	}, []);
	const frame = SLIDES[slide];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "hall",
			"aria-label": "Кинозал Ghostpot",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "theater",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						className: "theater-bg",
						src: "/brand/slides/hall.webp",
						alt: "",
						fetchPriority: "high",
						decoding: "async"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "theater-screen",
						"data-led": "screen",
						"aria-roledescription": "карусель",
						"aria-label": "Эпизоды Люси",
						children: [
							SLIDES.map((item, index) => {
								const last = (slide + SLIDES.length - 1) % SLIDES.length;
								const next = (slide + 1) % SLIDES.length;
								const visible = index === slide || index === next || slide !== 0 && index === last;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "theater-frame",
									type: "button",
									"data-on": index === slide,
									onClick: () => go({
										name: "world",
										id: item.world
									}),
									"aria-label": `${item.world}. ${item.line}`,
									children: visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: item.src,
										alt: "",
										decoding: "async",
										fetchPriority: index === slide ? "high" : "low"
									}) : null
								}, item.world);
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "screen-card",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "screen-kicker",
										children: "Сейчас на экране"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "screen-film",
										children: frame.world
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "screen-line",
										children: frame.line
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "theater-dots",
								children: SLIDES.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"data-on": index === slide,
									"aria-label": item.world,
									onClick: () => setSlide(index)
								}, item.world))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "arrival",
						"aria-live": "polite",
						children: ARRIVALS[beat]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "popcorn",
						"data-led": "popcorn",
						href: links.boosty,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "bucket",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Купить попкорн", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "донат на сеанс" })] })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "bill",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "bill-side",
					children: "13 игр · одна героиня"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Кино и игра"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Игра" }), " стала сеансом"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "below",
						children: "Ниже: миры, книга, музыка"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lead",
						children: "Люси живёт внутри игр. Фэнтези, техника и магия для неё не партия, а дом: ест, поёт, снимает блог, убивает, любит. Мир отпускает, только когда миссия закрыта. В следующем она начинает с нуля. У неё одно лицо, рысьи уши и рост 172."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lead",
						children: "Ты сидишь на этом стриме. Ghostpot — эфиры Николая Чичкань."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "roles",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Играет" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "миры, в которых она жила" })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Читает" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "книгу пути между играми" })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "В зале" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "стрим, пока сеанс идёт" })] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "actions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "solid",
								href: links.twitch,
								children: "Смотреть стрим"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "ghost",
								type: "button",
								onClick: () => go({ name: "worlds" }),
								children: "Миры"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "ghost",
								type: "button",
								onClick: () => go({ name: "book" }),
								onPointerEnter: () => void loadChapters(),
								children: "Читать книгу"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "ghost",
								href: links.alerts,
								children: "Ещё на чай"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveBadge, {})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						style: { marginTop: "0.9rem" },
						children: "Подписаться"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "subs",
						children: channels.map((channel) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: channel.href,
							rel: "noreferrer",
							children: channel.name
						}, channel.href))
					})
				] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Миры Люси" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "sub",
					children: "Картины одного героя. Карточка — дом. Значок в углу — осколок, который она оттуда унесла."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ghost",
					type: "button",
					onClick: () => go({ name: "worlds" }),
					children: "Все миры"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid-2",
					style: { marginTop: "1rem" },
					children: featured.map((world) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldCard, {
						world,
						featured: true
					}, world.name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "world-grid",
					style: { marginTop: "0.9rem" },
					children: rest.map((world) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldCard, { world }, world.name))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShardVault, { onOpen: (id) => go({
			name: "world",
			id
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Гайды по пройденным мирам" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sub",
				children: "Картинки миров и шорты с эфира. Электроника пустоши, Кентукки, колония."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				className: "ghost",
				to: "/guides",
				children: "Все гайды"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "guide-list",
				children: guides.map((guide) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					className: "guide-card",
					to: "/guides/$slug",
					params: { slug: guide.slug },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: guide.cover,
						alt: ""
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "guide-copy",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "meta",
							children: guide.game
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: guide.h1 })]
					})]
				}, guide.slug))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section grid-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Музыка"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Песни, плейлисты, атмосфера." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "cover",
						style: {
							margin: "1rem 0",
							maxWidth: 280
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
							src: "/chronicle/music/gothic.jpg",
							alt: "Обложка колонии"
						})
					}),
					catalog.slice(0, 5).map((track, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "track",
						type: "button",
						onClick: () => play(track, catalog),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "idx",
								children: index + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: track.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: track.world })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "time",
								children: track.length
							})
						]
					}, track.src)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ghost",
						type: "button",
						onClick: () => go({ name: "music" }),
						children: "Слушать песни"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Книга"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Моя история. От первого мира до сейчас." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "cover",
						style: {
							margin: "1rem 0",
							maxWidth: 220
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
							src: "/brand/book.webp",
							alt: "Люси. Обложка тома."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Это не просто книга. Это моя жизнь. Мои миры. Мои ошибки и победы." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "meta",
						children: [chapterIndex.length, " глав · пролог и три тома, от холода на камнях до партии у портала."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "solid",
						type: "button",
						onClick: () => go({
							name: "read",
							id: "prolog"
						}),
						onPointerEnter: () => void loadChapters(),
						children: "Читать книгу"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Последние ночи" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "quiet",
				type: "button",
				onClick: () => go({ name: "streams" }),
				children: "Все записи"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AirFeed, {})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "disc",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
								src: "/brand/nikolay.webp",
								alt: "Николай, Ghostpot."
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Николай" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "script",
							style: { fontSize: "1.4rem" },
							children: "40 уровень"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Класс: ночной эфир. Люси на экране, он за клавиатурой." }),
					skills.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "skill",
						style: { marginBottom: "0.4rem" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: skill.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "meta",
							children: skill.note
						})]
					}, skill.name)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "ghost",
							type: "button",
							onClick: () => go({ name: "about" }),
							children: "Обо мне"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "ghost",
							href: links.mail,
							children: "Написать"
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section panel",
			style: {
				display: "grid",
				gap: "0.8rem"
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid-2",
				style: { alignItems: "center" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "still",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
						src: "/brand/hungry.webp",
						alt: "Люси с пустой миской."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", { children: "Кадр · пустая миска" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Поддержать Ghostpot" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "script",
						style: {
							fontSize: "1.55rem",
							marginTop: "0.6rem"
						},
						children: "Отец родной, добавь на чай. На меня ты не серчай: я тут собрал всё для тебя. Бесплатно, может, и нехотя. Если можешь — поддержи. Сюда."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "solid",
							href: links.boosty,
							children: "Boosty"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "ghost",
							href: links.alerts,
							children: "DonationAlerts"
						})]
					})
				] })]
			})
		})
	] });
}
function WorldsView() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: "Репертуар зала"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "script",
			style: {
				fontSize: "clamp(3rem, 8vw, 5.5rem)",
				color: "var(--color-parchment)"
			},
			children: "Все миры"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "lead",
			children: "Она входит в хардкорный мир с миссией. Мир принимает её как свою: не гостья — будто она всегда тут жила. То же лицо. Те же уши. Новое тело. Когда миссия закрыта или тело больше не держит — душа уходит. Следующий мир. Снова «своя с рождения»."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShardVault, { onOpen: (id) => go({
			name: "world",
			id
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "world-grid",
			style: { marginTop: "1.2rem" },
			children: worlds.map((world) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldCard, { world }, world.name))
		})
	] });
}
function mirrorOf(href) {
	const host = href.toLowerCase();
	if (host.includes("rutube.ru")) return "rutube";
	if (host.includes("vk.com") || host.includes("vkvideo") || host.includes("vk.ru")) return "vk";
	if (host.includes("youtube.com") || host.includes("youtu.be")) return "youtube";
	return null;
}
function embedOf(href) {
	let url;
	try {
		url = new URL(href);
	} catch {
		return null;
	}
	const host = mirrorOf(href);
	if (host === "youtube") {
		let id = url.searchParams.get("v");
		if (url.hostname.endsWith("youtu.be")) id = url.pathname.split("/").filter(Boolean)[0] ?? null;
		const shorts = url.pathname.match(/\/shorts\/([^/?]+)/);
		if (shorts) id = shorts[1];
		return id ? `https://www.youtube-nocookie.com/embed/${id}` : null;
	}
	if (host === "rutube") {
		const parts = url.pathname.split("/").filter(Boolean);
		const id = parts[0] === "video" ? parts[1] : null;
		return id ? `https://rutube.ru/play/embed/${id}` : null;
	}
	if (host === "vk") {
		const match = href.match(/video(-?\d+)_(\d+)/);
		if (!match) return null;
		return `https://vk.com/video_ext.php?oid=${match[1]}&id=${match[2]}&hd=2`;
	}
	return null;
}
function listsOn(lists, host) {
	return lists.map((list) => ({
		...list,
		videos: list.videos.filter((video) => mirrorOf(video.href) === host)
	})).filter((list) => list.videos.length);
}
function useVideos() {
	const [data, setData] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		loadVideos().then((lists) => {
			if (live) setData(lists);
		});
		return () => {
			live = false;
		};
	}, []);
	return data;
}
function WorldView({ id }) {
	const world = worlds.find((item) => item.name === id) ?? worlds[0];
	const videos = useVideos();
	const lists = videos?.[world.name] ?? [];
	const [open, setOpen] = (0, import_react.useState)(false);
	const [host, setHost] = (0, import_react.useState)("youtube");
	const [clip, setClip] = (0, import_react.useState)(null);
	const play = usePlayer((s) => s.play);
	const songs = world.tracks.filter((track) => track.src).map((track) => ({
		title: track.title,
		world: world.name,
		src: track.src,
		cover: world.cover,
		length: track.length,
		note: track.note ?? ""
	}));
	const shelf = listsOn(lists, host);
	const shown = open ? shelf : shelf.map((list) => ({
		...list,
		videos: list.videos.slice(0, 3)
	}));
	const more = shelf.some((list) => list.videos.length > 3);
	(0, import_react.useEffect)(() => {
		setHost("youtube");
		setClip(null);
		setOpen(false);
	}, [id]);
	function choose(next) {
		setHost(next);
		setOpen(false);
		const first = lists.flatMap((list) => list.videos).find((video) => mirrorOf(video.href) === next);
		setClip(first ? embedOf(first.href) : null);
	}
	function watch(video) {
		setClip(embedOf(video.href));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "quiet",
			type: "button",
			onClick: () => go({ name: "worlds" }),
			children: "← Все миры"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid-2",
			style: {
				marginTop: "0.8rem",
				alignItems: "start"
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "cover",
				style: { maxWidth: 460 },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
					src: world.cover,
					alt: world.name
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "kicker",
					children: [
						world.mark,
						" · ",
						world.album
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					style: { fontSize: "clamp(3rem, 7vw, 5.2rem)" },
					children: world.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "lead",
					children: world.text
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShardPlate, { world: world.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "actions",
					children: [
						songs[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "solid",
							type: "button",
							onClick: () => play(songs[0], songs),
							children: "Слушать альбом"
						}) : null,
						guideForWorld(world.name) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "ghost",
							to: "/guides/$slug",
							params: { slug: guideForWorld(world.name).slug },
							children: "Гайд по миру"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "ghost",
							href: links.twitch,
							children: "Смотреть стрим"
						})
					]
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section grid-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Какой это мир" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: world.game })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Как там жила Люси" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: world.lived })]
			})]
		}),
		songs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section album-compact",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [
				"Альбом «",
				world.album,
				"»"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "meta",
				children: [
					songs.length,
					" ",
					songs.length === 1 ? "песня" : songs.length < 5 ? "песни" : "песен"
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "track-list",
				children: songs.map((track, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "track slim",
					type: "button",
					onClick: () => play(track, songs),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "idx",
							children: index + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: track.title }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "time",
							children: track.length
						})
					]
				}, track.src))
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "section meta",
			children: "Песни этого заезда ещё не выложены. Записи эфиров — ниже."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Записи" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "actions",
					"data-led": "host",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "ghost",
							type: "button",
							"data-on": host === "youtube",
							onClick: () => choose("youtube"),
							children: "YouTube"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "ghost",
							type: "button",
							"data-on": host === "rutube",
							onClick: () => choose("rutube"),
							children: "RuTube"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "ghost",
							type: "button",
							"data-on": host === "vk",
							onClick: () => choose("vk"),
							children: "VK Видео"
						})
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "meta",
					children: "Та же полка на странице. RuTube и VK Видео — зеркала, если YouTube не открывается."
				}),
				clip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "reel",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
						src: clip,
						title: "Запись",
						allow: "autoplay; fullscreen; picture-in-picture; encrypted-media",
						allowFullScreen: true
					})
				}) : null,
				videos === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "meta",
					children: "Записи открываются."
				}) : null,
				videos && shelf.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "meta",
					children: "На этой площадке записей мира на странице пока нет. Кнопка никуда не уводит."
				}) : null,
				shown.map((list) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: { marginTop: "1rem" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: list.name.replace(/^YouTube · |^Rutube · |^RuTube · /, "") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "video-grid",
						style: { marginTop: "0.6rem" },
						children: list.videos.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "video",
							type: "button",
							"data-on": clip === embedOf(video.href),
							onClick: () => watch(video),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
									src: video.poster,
									alt: ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: video.title }),
								video.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: video.note }) : null
							]
						}, video.href))
					})]
				}, list.name)),
				more ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ghost",
					type: "button",
					style: { marginTop: "0.8rem" },
					onClick: () => setOpen((value) => !value),
					children: open ? "Свернуть" : "Показать все записи мира"
				}) : null
			]
		})
	] });
}
function MusicView() {
	const play = usePlayer((s) => s.play);
	const index = usePlayer((s) => s.index);
	const queue = usePlayer((s) => s.queue);
	const playing = usePlayer((s) => s.playing);
	const current = index >= 0 ? queue[index] : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: "Плеер"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			style: { fontSize: "clamp(3rem, 8vw, 5.4rem)" },
			children: "Музыка"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "lead",
			children: "Песни, которые выросли из ночей. Альбомы миров и её собственные. Плеер остаётся внизу, куда бы ты ни ушёл."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "albums",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "album-row",
				"data-on": lucySongs.some((track) => track.src === current?.src),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
					className: `album-face ${lucySongs.some((track) => track.src === current?.src) && playing ? "is-on" : ""}`,
					src: "/chronicle/music/sleeves/lucy.jpg",
					alt: "Люси"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Люси" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "meta",
						children: "её песни"
					})]
				}), lucySongs.map((track, songIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "track",
					type: "button",
					"data-on": current?.src === track.src,
					onClick: () => play(track, lucySongs),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "idx",
							children: songIndex + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: track.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: track.note })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "time",
							children: track.length
						})
					]
				}, track.src))] })]
			}), worlds.map((world) => {
				const songs = catalog.filter((track) => track.world === world.name);
				if (!songs.length) return null;
				const on = songs.some((track) => track.src === current?.src);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "album-row",
					"data-on": on,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
						className: `album-face ${on && playing ? "is-on" : ""}`,
						src: world.sleeve || world.cover,
						alt: world.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: world.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "meta",
							children: world.album
						})]
					}), songs.map((track, songIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "track",
						type: "button",
						"data-on": current?.src === track.src,
						onClick: () => play(track, songs),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "idx",
								children: songIndex + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: track.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: track.note })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "time",
								children: track.length
							})
						]
					}, track.src))] })]
				}, world.name);
			})]
		})
	] });
}
function BookView() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [placeId, setPlaceId] = (0, import_react.useState)(null);
	const play = usePlayer((s) => s.play);
	const index = usePlayer((s) => s.index);
	const queue = usePlayer((s) => s.queue);
	const current = index >= 0 ? queue[index] : void 0;
	const tomeSong = catalog.find((track) => track.src.endsWith("/schit.mp3"));
	(0, import_react.useEffect)(() => {
		setPlaceId(readPlace()?.id ?? null);
	}, []);
	const groups = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return volumes().map((volume) => ({
			...volume,
			chapters: volume.chapters.filter((chapter) => {
				if (!needle) return true;
				return `${chapter.title} ${chapter.kicker} ${chapter.dek} ${chapter.numeral}`.toLowerCase().includes(needle);
			})
		})).filter((volume) => volume.chapters.length);
	}, [query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "toc",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Полка"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				style: { fontSize: "clamp(3rem, 8vw, 5.4rem)" },
				children: "Книги"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "lead",
				children: "Пока это первый том. Дальше их будет больше."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shelf",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "tome",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/brand/book.webp",
						alt: "Обложка тома «Моя история»"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "Том I"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Моя история" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "От первого мира до сейчас. Это не просто книга. Это моя жизнь. Мои миры. Мои ошибки и победы." }),
						tomeSong ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "track tome-song",
							"data-led": "tome-song",
							type: "button",
							"data-on": current?.src === tomeSong.src,
							onClick: () => play(tomeSong, [tomeSong]),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "idx",
									children: "♪"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: tomeSong.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Песня этого тома" })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "time",
									children: tomeSong.length
								})
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "solid",
								type: "button",
								onClick: () => go({
									name: "read",
									id: placeId || "prolog"
								}),
								onPointerEnter: () => void loadChapters(),
								children: placeId ? "Продолжить" : "Читать"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "ghost",
								type: "button",
								onClick: () => setOpen((value) => !value),
								children: open ? "Скрыть главы" : "Оглавление"
							})]
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "tome is-soon",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Том II" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ещё пишется" })]
				})]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "search",
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "Найти главу",
				"aria-label": "Найти главу"
			}), groups.map((volume) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: volume.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid-2",
				children: volume.chapters.map((chapter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "chapter-link",
					type: "button",
					onClick: () => go({
						name: "read",
						id: chapter.id
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "meta",
							children: [
								chapter.numeral,
								" · ",
								chapter.count,
								" абзацев"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [chapter.title === chapter.kicker ? chapter.title : `${chapter.kicker}. ${chapter.title}`, placeId === chapter.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Here, {}) : null] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: chapter.dek.slice(0, 180) })
					]
				}, chapter.id))
			})] }, volume.name))] }) : null
		]
	});
}
var PAPERS = [
	{
		id: "night",
		label: "Ночь"
	},
	{
		id: "sepia",
		label: "Сепия"
	},
	{
		id: "paper",
		label: "Бумага"
	},
	{
		id: "day",
		label: "День"
	}
];
function ReadView({ id }) {
	const [pack, setPack] = (0, import_react.useState)(null);
	const [size, setSize] = (0, import_react.useState)("m");
	const [toc, setToc] = (0, import_react.useState)(false);
	const [paper, setPaper] = (0, import_react.useState)("night");
	const [placeId, setPlaceId] = (0, import_react.useState)(null);
	const [karaoke, setKaraoke] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("ghostpot-paper");
		if (saved === "night" || saved === "sepia" || saved === "paper" || saved === "day") setPaper(saved);
		setKaraoke(localStorage.getItem("ghostpot-karaoke") === "1");
	}, []);
	(0, import_react.useEffect)(() => {
		let live = true;
		loadChapters().then((chapters) => {
			if (live) setPack(chapters);
		});
		return () => {
			live = false;
		};
	}, [id]);
	const chapters = pack ?? [];
	const index = Math.max(0, chapters.findIndex((chapter) => chapter.id === id));
	const chapter = chapters[index];
	(0, import_react.useEffect)(() => {
		setPlaceId(readPlace()?.id ?? null);
	}, [id]);
	(0, import_react.useEffect)(() => {
		if (!chapter) return;
		setPlaceId(chapter.id);
		if (karaoke && useBookAudio.getState().playing) return;
		const place = readPlace();
		if (place?.id === chapter.id && place.y > 40) window.scrollTo({ top: place.y });
		else savePlace(chapter.id, window.scrollY);
	}, [chapter, karaoke]);
	(0, import_react.useEffect)(() => {
		if (!chapter) return;
		const onScroll = () => savePlace(chapter.id, window.scrollY);
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => {
			savePlace(chapter.id, window.scrollY);
			window.removeEventListener("scroll", onScroll);
		};
	}, [chapter]);
	if (!chapter) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "reader",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: "Книга"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Открываю главу" })]
	});
	const prev = chapters[index - 1];
	const next = chapters[index + 1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "read-layout",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: toc ? "reader-toc is-open" : "reader-toc",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "ghost toc-toggle",
				type: "button",
				onClick: () => setToc((value) => !value),
				children: toc ? "Скрыть главы" : "Главы"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "toc-list",
				children: volumes().map((volume) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: volume.name }), volume.chapters.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "chapter-link",
					type: "button",
					"data-on": item.id === chapter.id,
					onClick: () => go({
						name: "read",
						id: item.id
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [item.title === item.kicker ? item.title : `${item.numeral}. ${item.title}`, placeId === item.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Here, {}) : null] })
				}, item.id))] }, volume.name))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "reader",
			"data-paper": paper,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "quiet",
					type: "button",
					onClick: () => go({ name: "book" }),
					children: "← Оглавление"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "kicker",
					style: { marginTop: "0.8rem" },
					children: [
						chapter.kicker,
						" · ",
						index + 1,
						" / ",
						chapters.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: chapter.title }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "dek",
					children: chapter.dek
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "paper-row",
					"data-led": "papers",
					"aria-label": "Фон страницы",
					children: PAPERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "paper",
						type: "button",
						"data-paper": item.id,
						"data-on": paper === item.id,
						onClick: () => {
							setPaper(item.id);
							localStorage.setItem("ghostpot-paper", item.id);
						},
						children: item.label
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "actions",
					"data-led": "size",
					"aria-label": "Размер шрифта",
					children: [[
						"s",
						"m",
						"l"
					].map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ghost",
						type: "button",
						"data-on": size === step,
						onClick: () => setSize(step),
						children: step === "s" ? "А" : step === "m" ? "Аа" : "Ааа"
					}, step)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ghost",
						type: "button",
						"data-on": karaoke,
						"aria-pressed": karaoke,
						"data-led": "karaoke",
						title: "Закрашивать буквы за голосом",
						onClick: () => {
							const next = !karaoke;
							setKaraoke(next);
							localStorage.setItem("ghostpot-karaoke", next ? "1" : "0");
						},
						children: "Караоке"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookProse, {
					chapterId: chapter.id,
					chapters,
					paragraphs: chapter.paragraphs,
					plates: chapter.plates,
					size,
					karaoke,
					onFollow: (nextId) => {
						if (nextId !== chapter.id) go({
							name: "read",
							id: nextId
						});
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "pager",
					"aria-label": "Соседние главы",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ghost",
						type: "button",
						disabled: !prev,
						onClick: () => prev && go({
							name: "read",
							id: prev.id
						}),
						children: "Назад"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "solid",
						type: "button",
						onClick: () => next ? go({
							name: "read",
							id: next.id
						}) : go({ name: "book" }),
						children: next ? "Дальше" : "К оглавлению"
					})]
				})
			]
		})]
	});
}
function GalleryView() {
	const [filter, setFilter] = (0, import_react.useState)("миры");
	const [open, setOpen] = (0, import_react.useState)(null);
	const [plates, setPlates] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (filter !== "книга" || plates.length) return;
		let live = true;
		loadChapters().then((chapters) => {
			if (live) setPlates(platesOf(chapters));
		});
		return () => {
			live = false;
		};
	}, [filter, plates.length]);
	const items = filter === "миры" ? worlds.map((world) => ({
		src: world.cover,
		alt: `${world.name}. ${world.album}`
	})) : filter === "шапка" ? hatShots : filter === "лица" ? [
		{
			src: "/brand/hero-photo.webp",
			alt: "Люси"
		},
		{
			src: "/brand/book.webp",
			alt: "Люси. Обложка тома."
		},
		{
			src: "/brand/hungry.webp",
			alt: "Люси с пустой миской."
		},
		{
			src: "/brand/nikolay.webp",
			alt: "Николай, Ghostpot."
		}
	] : plates;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: "Галерея"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			style: { fontSize: "clamp(3rem, 8vw, 5rem)" },
			children: "Скриншоты, арты, обои"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "chips",
			"data-led": "filters",
			style: { margin: "1rem 0" },
			children: [
				"миры",
				"лица",
				"шапка",
				"книга"
			].map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "ghost",
				type: "button",
				"data-on": filter === name,
				onClick: () => setFilter(name),
				children: name === "книга" ? plates.length ? `Из книги · ${plates.length}` : "Из книги" : name
			}, name))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shot-grid",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "shot",
				type: "button",
				onClick: () => setOpen(item),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
					src: item.src,
					alt: item.alt
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", { children: item.alt })]
			}, item.src + item.alt))
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "lightbox",
			role: "dialog",
			"aria-label": open.alt,
			onClick: () => setOpen(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
				src: open.src,
				alt: open.alt
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: open.alt })] })
		}) : null
	] });
}
function ShopView() {
	const [shot, setShot] = (0, import_react.useState)(0);
	const photo = hatShots[shot] ?? hatShots[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: "Шапка"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "shot",
				type: "button",
				onClick: () => setShot((shot + 1) % hatShots.length),
				"aria-label": "Следующее фото шапки",
				"data-led": "hat",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
					src: photo.src,
					alt: photo.alt
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "chips",
				style: { marginTop: "0.6rem" },
				children: hatShots.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ghost",
					type: "button",
					"data-on": index === shot,
					onClick: () => setShot(index),
					children: index + 1
				}, item.src))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hat",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Банная шапка из альпаки, мериноса, конопли и хлопка" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "script",
						children: "2 500 ₽"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "meta",
						children: "«Двойная природа» · вяжу на заказ · новое · универсальный размер"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "fibers",
						children: [
							"Альпака 50%",
							"Меринос 50%",
							"Хлопок 70%",
							"Конопля 30%"
						].map((fiber) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fiber }, fiber))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Снаружи альпака и меринос, внутри хлопок и конопля. Голова дышит, влага уходит, в парной можно стоять дольше. В подарок льняной или хлопковый мешочек." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hat-order",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Заказать" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Напиши в группу. Telegram, MAX или спроси на стриме. Назови цвет и обхват головы, если нужен свой размер." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "actions",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "solid",
										href: links.telegram,
										children: "Telegram"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "ghost",
										href: links.max,
										children: "MAX"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "ghost",
										href: links.twitch,
										children: "На стриме"
									})
								]
							})
						]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section hat-story",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Банная шапка «Двойная природа»: как устроена" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Вяжу её сам, вручную, в Новосибирске. Это не войлочный колпак, а сэндвич из четырёх натуральных волокон. Внешние слои: 50% альпака и 50% меринос. Они мягко касаются кожи, сразу уводят влагу и не сушат волосы. Внутренняя прослойка: 70% хлопок и 30% конопля. Конопля работает как натуральный антисептик, хлопок забирает пот без эффекта парника. Вес около 150 граммов, после долгого парения шапка не давит." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "В парной голова дышит, влага уходит, перегрева нет. За счёт этого в жаре обычно стоят на 20–30% дольше и не ловят мокрую макушку. Размер универсальный, можно связать под обхват головы. Цвета: чёрный, белый, серый, коричневый, бежевый, зелёный, золотистый. Другой оттенок спрашивайте. К заказу идёт мешочек для хранения и упаковка для пересылки." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Чем она лучше обычной банной шапки" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Не акрил: не парит, не колется, не скатывается и не впитывает запах парной." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Не джут: не натирает кожу, не плесневеет и не теряет форму." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Не мех и не кожа: голова не преет, шапка не тяжелеет от влаги и быстро сохнет." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Гипоаллергенная. Подходит, если обычная шерсть зудит или есть реакция на синтетику." })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Кому подойдёт и как заказать" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Для тех, кто хочет дольше оставаться в русской бане, хаммаме и на коротком заходе в сауну. Для парильщиков, кому важен аксессуар на каждый день. Для подарка, который не выглядит как колпак из магазина у дома." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Самовывоз у меня: Новосибирский район, посёлок Элитный, микрорайон Фламинго. Доставка через Озон в пункт выдачи. На сайте оплату не беру. Напишите мне в Telegram или MAX, какой цвет нужен, или спросите на моём стриме. Стирка ручная, в прохладной воде. При таком уходе шапка служит годами." })
			]
		})
	] });
}
function LucyView() {
	const play = usePlayer((s) => s.play);
	const index = usePlayer((s) => s.index);
	const queue = usePlayer((s) => s.queue);
	const playing = usePlayer((s) => s.playing);
	const current = index >= 0 ? queue[index] : void 0;
	const on = lucySongs.some((track) => track.src === current?.src);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: "В главной роли"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
				className: "portrait sheet",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
					src: "/chronicle/party/lucy-ref.jpg?v=2",
					alt: "Люси. Crafted by ghostpot."
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					style: { fontSize: "clamp(3.4rem, 8vw, 6rem)" },
					children: "Люси"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "lead",
					children: "Один человек на много игр. Мир меняет правила, одежду и то, чем её можно убить. Паспорт остаётся. Для местных она не гостья: будто всегда здесь жила."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "quote",
					children: "«Я не знаю, куда откроется следующий мир. Но уши и сарказм всегда со мной.»"
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "passport",
			children: passport.map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: key }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: value })] }, key))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Кто она" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Люси — двадцать пять. Человек с рысьими ушами, шрамом на скуле и мозолью от рукояти. Не «милая девочка с ушками». Она уже умирала в других мирах, поэтому в новом не несётся сломя голову. Сначала смотрит, потом говорит. Если очень страшно — шутит суше." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Как живёт в игре" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Начинает с нуля: ни меча, ни сумки, часто босая. Система, или кто там открывает двери, любит это. Дальше она играет по правилам мира. В колонии носит воду. В степи держит щит. В пустоши считает патроны. В Азероте шьёт и хилит, потому что танка всё равно нет." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Зачем она на эфире" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Эфир и есть её жизнь в этом заезде. Сказанное слово может стать строчкой книги или припевом. Николай за клавиатурой не переписывает вечер задним числом. Если Люси умерла, значит умерла. Паспорт от этого не рвётся. Открывается следующий мир." })]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Альбом Люси" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "meta",
				children: "её песни"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "album-row",
				"data-on": on,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
					className: `album-face ${on && playing ? "is-on" : ""}`,
					src: "/chronicle/music/sleeves/lucy.jpg",
					alt: "Люси"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: lucySongs.map((track, songIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "track",
					type: "button",
					"data-on": current?.src === track.src,
					onClick: () => play(track, lucySongs),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "idx",
							children: songIndex + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: track.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: track.note })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "time",
							children: track.length
						})
					]
				}, track.src)) })]
			})]
		})
	] });
}
function AboutView() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: "За клавиатурой"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "portrait person",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
					src: "/brand/nikolay.webp",
					alt: "Николай, Ghostpot."
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					style: { fontSize: "clamp(3rem, 8vw, 5.5rem)" },
					children: "Николай"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "script",
					children: "40 уровень. Класс: ночной эфир."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "lead",
					children: "Люси на экране, он за клавиатурой. Николай Чичкань. Стример, автор книги и песен, которые остаются после ночи."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "solid",
						href: links.mail,
						children: "Написать"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "ghost",
						href: links.telegram,
						children: "Telegram"
					})]
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid-3",
			style: { marginTop: "1rem" },
			children: skills.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "skill",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: skill.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: skill.note })]
			}, skill.name))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section panel",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Каналы" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid-2",
				style: { marginTop: "0.7rem" },
				children: channels.map((channel) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "night",
					href: channel.href,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: channel.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: channel.note })]
				}, channel.href))
			})]
		})
	] });
}
function StreamsView() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [host, setHost] = (0, import_react.useState)("youtube");
	const [clip, setClip] = (0, import_react.useState)(null);
	const videos = useVideos();
	const needle = query.trim().toLowerCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: "Эфиры"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			style: { fontSize: "clamp(3rem, 8vw, 5rem)" },
			children: "Ночи и записи"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "lead",
			children: "Стримы — она живёт здесь и сейчас. Шорты: миссия, урок, критический момент. Длинные записи: дневник текущей жизни."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AirFeed, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "actions",
			"data-led": "host",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "solid",
					href: links.twitch,
					children: "Twitch"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ghost",
					type: "button",
					"data-on": host === "youtube",
					onClick: () => {
						setHost("youtube");
						setClip(null);
					},
					children: "YouTube"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ghost",
					type: "button",
					"data-on": host === "rutube",
					onClick: () => {
						setHost("rutube");
						setClip(null);
					},
					children: "RuTube"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ghost",
					type: "button",
					"data-on": host === "vk",
					onClick: () => {
						setHost("vk");
						setClip(null);
					},
					children: "VK Видео"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "search",
			style: { marginTop: "1.2rem" },
			value: query,
			placeholder: "Найти запись",
			"data-led": "search",
			"aria-label": "Найти запись",
			onChange: (event) => setQuery(event.target.value)
		}),
		clip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "reel",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				src: clip,
				title: "Запись",
				allow: "autoplay; fullscreen; picture-in-picture; encrypted-media",
				allowFullScreen: true
			})
		}) : null,
		videos === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "meta",
			style: { marginTop: "1rem" },
			children: "Записи открываются."
		}) : null,
		worlds.map((world) => {
			const lists = listsOn(videos?.[world.name] ?? [], host).map((list) => ({
				...list,
				videos: list.videos.filter((video) => !needle || `${video.title} ${video.note} ${world.name}`.toLowerCase().includes(needle))
			})).filter((list) => list.videos.length);
			if (!lists.length) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: world.name }), lists.map((list) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "video-grid",
					style: { marginTop: "0.55rem" },
					children: list.videos.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "video",
						type: "button",
						"data-on": clip === embedOf(video.href),
						onClick: () => setClip(embedOf(video.href)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
							src: video.poster,
							alt: ""
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: video.title })]
					}, video.href))
				}) }, list.name))]
			}, world.name);
		})
	] });
}
function ProgramsView() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: "Программы"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			style: { fontSize: "clamp(3rem, 8vw, 5.5rem)" },
			children: "Речь"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "script",
			children: "Чат в эфир. Игра — вслух."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "lead",
			children: "Программа для Windows. Собирает чат площадок в одну ленту, показывает его в OBS и читает разными голосами, по-русски и по-английски. В игре обводит кусок экрана и переводит. Сама не говорит: чтобы прозвучало, нужна клавиша."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "actions",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "solid",
				"data-led": "speech",
				href: "/programs/rech.zip?v=2",
				download: true,
				children: "Скачать Речь"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "meta",
				children: "Windows 10 или 11, 64-bit · без установки · около 70 МБ"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "video-grid",
			style: { marginTop: "1.2rem" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "video program-shot",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/programs/efir.webp",
							alt: "Лента чата и голос в окне Речи",
							width: "1280",
							height: "800"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Эфир" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Несколько площадок в одной ленте. Окно можно отдать в OBS." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "video program-shot",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/programs/igra.webp",
							alt: "Список обведённого текста из игры",
							width: "1280",
							height: "800"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Игра" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Обведённый кусок экрана. Английский переводится и читается." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "video program-shot",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/programs/ramka.webp",
							alt: "Рамка перевода поверх игры",
							width: "1280",
							height: "800"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Рамка" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Перевод в окне. Или вставить свой текст и озвучить его." })
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid-3",
			style: { marginTop: "1rem" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "skill",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Экран" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Ctrl+Ё или «Обвести сейчас». Рамка тащится за верхнюю строку. «Говорить» — по клавише, не сама. Можно оставить только перевод, без голоса." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "skill",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Чат" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Twitch, YouTube, VK Видео, GoodGame, Rutube, Steam. Новые сообщения читает в очередь, не перебивая себя. Галка «Не читать ругань» оставляет мат на экране, но не произносит его. Пауза голоса — F8." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "skill",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Голоса" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Ксения, Ксюша, Бая, Айдар, Евгений. Свой язык — своим голосом. Один раз «Скачать голос», дальше интернет для фразы не нужен. Чужой текст вставляется в рамку." })]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section panel",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Как запустить" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hat-story",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Распакуй архив в обычную папку. Из самого архива программа не стартует." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Запусти RECH.exe. Если Windows пишет «система защитила компьютер» — «Подробнее», затем «Выполнить в любом случае»." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Слева площадка и канал, кнопка «Подключить». Справа включи «Озвучивать новые сообщения» и проверь голос." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Ссылку из блока OBS вставь в источник «Браузер». Это отдельный чат для эфира, не то окно, которое на столе." })
				] })
			})]
		})
	] });
}
function LawView() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "reader",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Правила дома"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Политика, соглашение, cookie" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "prose",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Сайт про ночные игровые эфиры, книгу и песни. Контент 18+. Это не магазин с оплатой на странице: шапку и поддержку оформляют напрямую, в Telegram, MAX, Boosty или DonationAlerts." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Персональные данные россиян на сайт не собираются. Форм с паспортом, телефоном и адресом нет. Письмо уходит на nikolay@whitebunny.ru только если написать самому." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "На устройстве запоминаются только выбор cookie, место в книге и громкость плеера. На сервер это не уходит." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Чужие площадки — Twitch, YouTube, Rutube, VK, GoodGame, W.TV, Yappy, Boosty, DonationAlerts, MAX — живут по своим правилам. Ссылки ведут туда как есть." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Тексты, песни и образ Люси принадлежат Николаю Чичкань. Игровые миры принадлежат своим правообладателям. Картинки миров — иллюстрации к хронике, не официальные обложки студий." })
				]
			})
		]
	});
}
var LINES = [
	"Спрашивай. Только коротко. Я занята тем, что пытаюсь не умереть.",
	"Новые миры. Те же вопросы. Кто я?",
	"То же лицо. Те же уши. Новое тело.",
	"Я не знаю, куда откроется следующий мир. Но уши и сарказм всегда со мной.",
	"Если мир молчит, песня поёт. Не орёшь на пустую миску.",
	"Осколки. По одному из мира. Этот сайт — комната, где я их держу."
];
function Whisper() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [line, setLine] = (0, import_react.useState)(LINES[0]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "whisper",
		children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "whisper-card",
			role: "dialog",
			"aria-label": "Люси",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Люси, не поднимая глаз"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: line }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "whisper-asks",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setLine(LINES[1]),
							children: "Ты здесь?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setLine(LINES[3]),
							children: "Кто ты?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setLine(LINES[5]),
							children: "Что в руках?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOpen(false),
							children: "Поняла, спрячься"
						})
					]
				})
			]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "whisper-face",
			type: "button",
			"aria-label": "Помощник Люси",
			"data-led": "whisper",
			onClick: () => setOpen((value) => !value),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shot, {
				src: "/brand/hungry.webp",
				alt: ""
			})
		})]
	});
}
function CookieNote() {
	const [ok, setOk] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		setOk(localStorage.getItem("ghostpot-cookies") === "1");
	}, []);
	if (ok) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "cookie",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			style: { margin: 0 },
			children: "На устройстве запоминаются только выбор cookie, место в книге и громкость. На сервер это не уходит."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "solid",
			type: "button",
			onClick: () => {
				localStorage.setItem("ghostpot-cookies", "1");
				setOk(true);
			},
			children: "Понятно"
		})]
	});
}
//#endregion
export { openSite as _, HomeView as a, MusicView as c, Shell as d, ShopView as f, WorldsView as g, WorldView as h, GalleryView as i, ProgramsView as l, Whisper as m, BookView as n, LawView as o, StreamsView as p, CookieNote as r, LucyView as s, AboutView as t, ReadView as u, parseHash as v };
